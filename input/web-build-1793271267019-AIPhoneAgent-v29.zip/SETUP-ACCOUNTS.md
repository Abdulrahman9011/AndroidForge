# تشغيل الحسابات على السيرفر (Supabase)

بتعملها مرة وحدة بس، وبتاخد شي 10 دقايق. بعدها إنشاء الحساب وتسجيل الدخول وGoogle بيشتغلوا فعلياً، والاسم والصورة بينحفظوا على السيرفر.

## 1) اعمل مشروع Supabase
1. ادخل على https://supabase.com واعمل حساب مجاني، وبعدين **New project**.
2. لما يجهز المشروع، اضغط زر **Connect** فوق، أو روح على **Project Settings ← API Keys**، وانسخ شغلتين:
   - **Project URL** (متل `https://abcd1234.supabase.co`)
   - **Publishable key** (بيبلّش بـ `sb_publishable_`)، أو الـ **anon** القديم (بيبلّش بـ `eyJ`) من تبويب Legacy. الاتنين بيشتغلوا.

## 2) جهّز قاعدة البيانات
1. بـ Supabase روح على **SQL Editor ← New query**.
2. الصق كل محتوى الملف `supabase/setup.sql` واضغط **Run**.
   هاد بيعمل:
   - جدول `profiles` للاسم والصورة، ومكان تخزين الصور `avatars`
   - جدول `chats` للمحادثات، ومكان خاص `chat-files` للصور والملفات يلي بتنبعت بالمحادثات
   - زر حذف الحساب

   وكل مستخدم بيقدر يشوف ويعدّل بياناته هو بس.
   (إذا كنت شغّلت الملف من قبل، شغّله مرة تانية: آمن ينعاد، وبيضيف الأقسام الجديدة بس.)

## 3) إعدادات الإيميل
بـ **Authentication ← Sign In / Providers ← Email**:
- خلّي **Enable Email provider** شغّال.
- **Confirm email**: إذا شغّال، كل حساب جديد لازم يأكد بريده من رسالة الإيميل قبل ما يسجّل دخول. إذا بدك تجرّب بسرعة فيك تطفيه.

بـ **Authentication ← Emails ← Reset Password** (أو Email Templates): غيّر نص الرسالة وحط فيه الكود:
```
كود تغيير كلمة المرور: {{ .Token }}
```
التطبيق بيطلب هالكود من 6 أرقام، لأنو ما في موقع يفتح عليه رابط الإيميل.

> ملاحظة: Supabase المجاني بيبعت عدد قليل من الإيميلات بالساعة. إذا بدك تبعت أكتر، ضيف خدمة SMTP من **Project Settings ← Authentication ← SMTP**.

## 4) تسجيل الدخول بـ Google
بـ **Google Cloud Console** (https://console.cloud.google.com ← APIs & Services ← Credentials):
1. اعمل **OAuth client ID** من نوع **Web application**، وانسخ الـ Client ID تبعه. هاد هو `GOOGLE_WEB_CLIENT_ID`.
2. اعمل كمان **OAuth client ID** من نوع **Android**:
   - Package name: `com.aiphoneagent`
   - SHA-1 (تبع مفتاح التوقيع يلي جاي مع المشروع `app/debug.keystore`):
     `87:6A:E4:C2:65:F4:9A:B9:DE:F3:FE:BD:DA:B4:5B:BF:CD:5A:A1:AD`
3. بـ Supabase روح على **Authentication ← Sign In / Providers ← Google**، شغّله، وحط الـ **Web Client ID** بخانة **Client IDs** (وفيك تحط الـ Client Secret تبع الـ Web client كمان). خلّي **Skip nonce check** مطفي.

## 5) حط المفاتيح بالتطبيق
**إذا عم تبني على GitHub Actions:** بالمستودع روح على **Settings ← Secrets and variables ← Actions ← New repository secret** وضيف:
| الاسم | القيمة |
|---|---|
| `SUPABASE_URL` | الـ Project URL |
| `SUPABASE_ANON_KEY` | الـ anon public key |
| `GOOGLE_WEB_CLIENT_ID` | الـ Web Client ID |

**إذا عم تبني على جهازك:** حطهم بملف `ai.properties`:
```
SUPABASE_URL=https://abcd1234.supabase.co
SUPABASE_ANON_KEY=eyJ...
GOOGLE_WEB_CLIENT_ID=1234-xxxx.apps.googleusercontent.com
```

بعدها ابنِ التطبيق من جديد. الـ anon key مسموح يكون جوّا التطبيق، لأنو قواعد الحماية (RLS) يلي بـ setup.sql هي يلي بتمنع أي حدا يوصل لبيانات غيره. **أبداً ما تحط الـ service_role key بالتطبيق.**

## شو بيصير بالتطبيق
- **إنشاء حساب**: الحساب بينعمل على السيرفر، وإذا تأكيد الإيميل شغّال بتوصلك رسالة تأكيد.
- **تسجيل الدخول**: بيتأكد من كلمة المرور على السيرفر. الهاتف بيحفظ بس توكن الجلسة، مشفّر بالـ Keystore، وبيتجدد لحاله.
- **Google**: بيطلع حساب Google من الهاتف، وSupabase بيتحقق منه.
- **الاسم والصورة**: بينحفظوا على السيرفر، وبيبيّنوا على أي هاتف بتسجّل منه.
- **المحادثات**: كل محادثة بتنحفظ على حسابك تلقائياً بعد كم ثانية، مع الصور والملفات (لحد 20 MB للملف). بتطلع على أي هاتف بتسجّل منه، وإذا حذفت محادثة بتنحذف من كل مكان. المحادثات يلي عملتها كضيف بتنضاف لحسابك أول ما تسجّل دخول. وإذا سجّلت خروج، بتنشال محادثات الحساب من الهاتف وبتضل محفوظة على السيرفر.
- **نسيت كلمة المرور**: بيوصلك كود عالإيميل، بتكتبه بالتطبيق مع كلمة المرور الجديدة.
- **حذف الحساب**: بيحذف الحساب والصورة من السيرفر نهائياً.

الحسابات القديمة يلي كانت محفوظة على الهاتف بس ما بتنتقل للسيرفر، فلازم تعمل حساب جديد.
