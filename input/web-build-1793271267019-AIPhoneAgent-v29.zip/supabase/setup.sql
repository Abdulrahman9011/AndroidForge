-- AI Phone Agent: accounts server setup.
-- Paste ALL of this into Supabase > SQL Editor > New query, then press Run (once).

-- 1) Profiles: one row per user, readable/writable only by that user.
create table if not exists public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  email       text,
  full_name   text,
  avatar_url  text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists "profiles: read own"   on public.profiles;
drop policy if exists "profiles: insert own" on public.profiles;
drop policy if exists "profiles: update own" on public.profiles;
create policy "profiles: read own"   on public.profiles for select using (auth.uid() = id);
create policy "profiles: insert own" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles: update own" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

-- 2) Create the profile automatically when someone signs up (e-mail or Google).
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name'))
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- 3) "Delete my account" button: removes the user (and, by cascade, the profile). The app deletes the photo through the Storage API first.
create or replace function public.delete_my_account()
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  delete from auth.users where id = auth.uid();
end $$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- 4) Profile photos: public bucket "avatars", each user may only write inside their own folder <uid>/.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 2097152, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set public = true;

drop policy if exists "avatars: read"        on storage.objects;
drop policy if exists "avatars: insert own"  on storage.objects;
drop policy if exists "avatars: update own"  on storage.objects;
drop policy if exists "avatars: delete own"  on storage.objects;
create policy "avatars: read"       on storage.objects for select using (bucket_id = 'avatars');
create policy "avatars: insert own" on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatars: update own" on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatars: delete own" on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

-- 5) Conversations: one row per chat (messages as JSON), only visible to their owner.
create table if not exists public.chats (
  id          text primary key,
  user_id     uuid not null default auth.uid() references auth.users (id) on delete cascade,
  title       text,
  auto        boolean not null default true,
  messages    jsonb not null default '[]'::jsonb,
  updated_at  bigint not null default 0,
  created_at  timestamptz not null default now()
);
create index if not exists chats_user_updated on public.chats (user_id, updated_at desc);

alter table public.chats enable row level security;

drop policy if exists "chats: read own"   on public.chats;
drop policy if exists "chats: insert own" on public.chats;
drop policy if exists "chats: update own" on public.chats;
drop policy if exists "chats: delete own" on public.chats;
create policy "chats: read own"   on public.chats for select using (auth.uid() = user_id);
create policy "chats: insert own" on public.chats for insert with check (auth.uid() = user_id);
create policy "chats: update own" on public.chats for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "chats: delete own" on public.chats for delete using (auth.uid() = user_id);

-- 6) Files sent in conversations (photos, videos, documents): PRIVATE bucket, each user only inside their own folder <uid>/.
insert into storage.buckets (id, name, public, file_size_limit)
values ('chat-files', 'chat-files', false, 20971520)
on conflict (id) do update set public = false;

drop policy if exists "chat-files: read own"   on storage.objects;
drop policy if exists "chat-files: insert own" on storage.objects;
drop policy if exists "chat-files: update own" on storage.objects;
drop policy if exists "chat-files: delete own" on storage.objects;
create policy "chat-files: read own"   on storage.objects for select to authenticated
  using (bucket_id = 'chat-files' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "chat-files: insert own" on storage.objects for insert to authenticated
  with check (bucket_id = 'chat-files' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "chat-files: update own" on storage.objects for update to authenticated
  using (bucket_id = 'chat-files' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "chat-files: delete own" on storage.objects for delete to authenticated
  using (bucket_id = 'chat-files' and (storage.foldername(name))[1] = auth.uid()::text);
