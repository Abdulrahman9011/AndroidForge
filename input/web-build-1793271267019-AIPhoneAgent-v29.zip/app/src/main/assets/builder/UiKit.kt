package @@PKG@@

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Shapes
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * Ready-made design system for this app (written by the builder, do not rewrite it).
 * Use these instead of re-styling Material components in every screen.
 */

object AppColors {
    val Background = Color(0xFF101114)
    val Surface = Color(0xFF181A1F)
    val SurfaceHigh = Color(0xFF22252C)
    val Primary = Color(0xFF7C9CFF)
    val OnPrimary = Color(0xFF0B1230)
    val Secondary = Color(0xFF5ED6B4)
    val Text = Color(0xFFECEDEF)
    val TextDim = Color(0xFF9CA1AB)
    val Outline = Color(0xFF2E323A)
    val Error = Color(0xFFFF7A7A)
    val Success = Color(0xFF6BD69A)
    val Warning = Color(0xFFFFC266)
}

private val AppColorScheme = darkColorScheme(
    primary = AppColors.Primary, onPrimary = AppColors.OnPrimary,
    secondary = AppColors.Secondary, onSecondary = Color(0xFF00281E),
    background = AppColors.Background, onBackground = AppColors.Text,
    surface = AppColors.Surface, onSurface = AppColors.Text,
    surfaceVariant = AppColors.SurfaceHigh, onSurfaceVariant = AppColors.TextDim,
    surfaceContainer = AppColors.Surface, surfaceContainerHigh = AppColors.SurfaceHigh,
    outline = AppColors.Outline, outlineVariant = AppColors.Outline,
    error = AppColors.Error, onError = Color(0xFF3A0000)
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold, lineHeight = 32.sp),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold, lineHeight = 26.sp),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium, lineHeight = 16.sp)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp), medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(22.dp)
)

/** Wrap the whole app in this (inside setContent). */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AppColorScheme, typography = AppTypography, shapes = AppShapes, content = content)
}

/** A full screen with a centered top bar. [onBack] null = no back arrow. [content] gets the inner padding to apply. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreen(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
    bottomBar: @Composable () -> Unit = {},
    floatingButton: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        containerColor = AppColors.Background,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null) }
                },
                actions = actions,
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = AppColors.Background, titleContentColor = AppColors.Text)
            )
        },
        bottomBar = bottomBar,
        floatingActionButton = floatingButton,
        content = content
    )
}

/** Rounded card with an optional title; put rows/fields inside. */
@Composable
fun SectionCard(title: String? = null, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
        border = BorderStroke(1.dp, AppColors.Outline)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (title != null) Text(title, style = MaterialTheme.typography.titleMedium, color = AppColors.Text)
            content()
        }
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, icon: ImageVector? = null) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier.height(52.dp), shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = AppColors.Primary, contentColor = AppColors.OnPrimary)
    ) {
        if (icon != null) { Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun SecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, icon: ImageVector? = null) {
    OutlinedButton(
        onClick = onClick, enabled = enabled, modifier = modifier.height(52.dp), shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, AppColors.Outline)
    ) {
        if (icon != null) { Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp), tint = AppColors.Text); Spacer(Modifier.width(8.dp)) }
        Text(text, style = MaterialTheme.typography.labelLarge, color = AppColors.Text)
    }
}

@Composable
fun AppTextField(value: String, onValueChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, singleLine: Boolean = true, leadingIcon: ImageVector? = null) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange, modifier = modifier.fillMaxWidth(), singleLine = singleLine,
        label = { Text(label) }, shape = RoundedCornerShape(14.dp),
        leadingIcon = if (leadingIcon != null) ({ Icon(leadingIcon, contentDescription = null) }) else null,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AppColors.Primary, unfocusedBorderColor = AppColors.Outline,
            focusedContainerColor = AppColors.Surface, unfocusedContainerColor = AppColors.Surface
        )
    )
}

@Composable
fun SearchField(query: String, onQueryChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier) {
    AppTextField(query, onQueryChange, placeholder, modifier, leadingIcon = Icons.Filled.Search)
}

/** A tappable list row: round icon, title, optional subtitle, optional trailing content. */
@Composable
fun InfoRow(title: String, subtitle: String? = null, icon: ImageVector? = null, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    Row(
        modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Box(Modifier.size(42.dp).background(AppColors.SurfaceHigh, CircleShape), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = AppColors.Primary, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = AppColors.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = AppColors.TextDim, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        trailing()
    }
}

/** Big number tile for dashboards. */
@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier, icon: ImageVector? = null) {
    Column(
        modifier.background(AppColors.Surface, RoundedCornerShape(18.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (icon != null) Icon(icon, contentDescription = null, tint = AppColors.Secondary, modifier = Modifier.size(22.dp))
        Text(value, style = MaterialTheme.typography.headlineMedium, color = AppColors.Text, maxLines = 1)
        Text(label, style = MaterialTheme.typography.labelMedium, color = AppColors.TextDim, maxLines = 1)
    }
}

/** Centered placeholder when a list is empty. */
@Composable
fun EmptyState(icon: ImageVector, title: String, message: String, modifier: Modifier = Modifier, actionText: String? = null, onAction: (() -> Unit)? = null) {
    Column(modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(72.dp).background(AppColors.SurfaceHigh, CircleShape), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = AppColors.Primary, modifier = Modifier.size(34.dp))
        }
        Text(title, style = MaterialTheme.typography.titleMedium, color = AppColors.Text, textAlign = TextAlign.Center)
        Text(message, style = MaterialTheme.typography.bodyMedium, color = AppColors.TextDim, textAlign = TextAlign.Center)
        if (actionText != null && onAction != null) { Spacer(Modifier.height(6.dp)); PrimaryButton(actionText, onAction) }
    }
}

@Composable
fun LoadingState(text: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        CircularProgressIndicator(color = AppColors.Primary)
        Spacer(Modifier.height(14.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = AppColors.TextDim)
    }
}

@Composable
fun ErrorState(message: String, onRetry: (() -> Unit)?, modifier: Modifier = Modifier, retryText: String = "Retry") {
    Column(modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(Icons.Filled.WarningAmber, contentDescription = null, tint = AppColors.Error, modifier = Modifier.size(40.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = AppColors.Text, textAlign = TextAlign.Center)
        if (onRetry != null) SecondaryButton(retryText, onRetry, icon = Icons.Filled.Refresh)
    }
}

/** Bottom tab bar. [items] = (label, icon) per tab. */
@Composable
fun BottomTabs(items: List<Pair<String, ImageVector>>, selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = AppColors.Surface) {
        items.forEachIndexed { i, (label, icon) ->
            NavigationBarItem(
                selected = i == selected, onClick = { onSelect(i) },
                icon = { Icon(icon, contentDescription = label) }, label = { Text(label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = AppColors.OnPrimary, indicatorColor = AppColors.Primary,
                    selectedTextColor = AppColors.Text, unselectedIconColor = AppColors.TextDim, unselectedTextColor = AppColors.TextDim
                )
            )
        }
    }
}

/** Small colored label (status, category). */
@Composable
fun Pill(text: String, color: Color = AppColors.Primary) {
    Text(
        text, color = color, style = MaterialTheme.typography.labelMedium,
        modifier = Modifier.background(color.copy(alpha = 0.15f), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp)
    )
}
