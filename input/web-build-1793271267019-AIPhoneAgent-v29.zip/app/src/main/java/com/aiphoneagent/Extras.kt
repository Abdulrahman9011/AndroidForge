package com.aiphoneagent

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Project(val id: String, val name: String, val instructions: String, val files: List<Pair<String, String>>)
data class Skill(val id: String, val name: String, val text: String, val builtin: Boolean = false)
class Connector(val id: String, val title: String, val desc: String)

/** Everything behind the rows of the "+" sheet: projects, permission mode, connectors, skills, memory. */
object Extras {
    private lateinit var sp: SharedPreferences
    /** Bumped on any change so Compose recomposes. */
    var ver by mutableIntStateOf(0)
    val memory = mutableStateListOf<String>()
    val projects = mutableStateListOf<Project>()
    val customSkills = mutableStateListOf<Skill>()
    private var chatProj = JSONObject()

    val builtinSkills = listOf(
        Skill("coder", "مبرمج خبير", "عند أي سؤال برمجي اكتب كوداً كاملاً وجاهزاً للتشغيل بدون اختصار ولا \"باقي الكود\"، مع سطرين عن طريقة التشغيل.", true),
        Skill("tutor", "معلّم مبسّط", "اشرح أي موضوع بخطوات بسيطة مرتّبة مع مثال واحد على الأقل، وتحقق من فهم المستخدم بسؤال قصير بالنهاية.", true),
        Skill("translator", "مترجم", "إذا كتب المستخدم نصاً بلغة غير العربية ترجمه للعربية، وإذا كتب بالعربية ترجمه للإنجليزية، إلا إذا حدد لغة ثانية.", true),
        Skill("short", "إيجاز", "اختصر الأجوبة لأقصى حد: جملة إلى ثلاث إلا إذا طُلب التفصيل.", true),
        Skill("writer", "كاتب محتوى", "اكتب نصوصاً تسويقية وإبداعية بأسلوب جذّاب ومنظّم، وقدّم نسختين مختلفتين عند الطلب.", true)
    )

    val connectors = listOf(
        Connector("qaf", "Qaf — الأسئلة الدينية", "أي سؤال ديني (حكم، حديث، تفسير، دعاء) يُرسل إلى QafAI (qafai.net) مع تعليمات للإجابة بمنهج شرعي وذكر المصادر."),
        Connector("prayer", "مواقيت الصلاة", "اكتب: مواقيت الصلاة في دمشق، فيجيب من خدمة Aladhan بأوقات حقيقية."),
        Connector("weather", "الطقس", "اكتب: كيف الطقس في إسطنبول، فيجيب من Open-Meteo بالأرقام الحالية."),
        Connector("wiki", "ويكيبيديا", "اكتب: ويكيبيديا + الموضوع، فيجلب الملخص الحقيقي ويجيب منه.")
    )

    const val DEFAULT_QAF_URL = "https://qafai.net"

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.applicationContext.getSharedPreferences("extras", Context.MODE_PRIVATE)
        runCatching { JSONArray(sp.getString("memory", "[]")).let { a -> for (i in 0 until a.length()) memory.add(a.getString(i)) } }
        runCatching {
            JSONArray(sp.getString("projects", "[]")).let { a ->
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val fa = o.optJSONArray("files")
                    val files = if (fa == null) emptyList() else (0 until fa.length()).map { fa.getJSONObject(it).let { f -> f.optString("n") to f.optString("t") } }
                    projects.add(Project(o.getString("id"), o.optString("name"), o.optString("ins"), files))
                }
            }
        }
        runCatching {
            JSONArray(sp.getString("skills", "[]")).let { a ->
                for (i in 0 until a.length()) a.getJSONObject(i).let { customSkills.add(Skill(it.getString("id"), it.optString("name"), it.optString("text"))) }
            }
        }
        chatProj = runCatching { JSONObject(sp.getString("chatproj", "{}")) }.getOrDefault(JSONObject())
    }

    // ---------------------------------------------------------------- permission
    /** false = Manual: every sensitive phone action asks first. true = Auto: only payments / deletions / transfers still ask. */
    var permissionAuto: Boolean
        get() = ::sp.isInitialized && sp.getBoolean("permauto", false)
        set(v) { sp.edit().putBoolean("permauto", v).apply(); ver++ }

    // ---------------------------------------------------------------- memory
    var memoryOn: Boolean
        get() = ::sp.isInitialized && sp.getBoolean("memon", true)
        set(v) { sp.edit().putBoolean("memon", v).apply(); ver++ }
    private fun saveMemory() { sp.edit().putString("memory", JSONArray(memory.toList()).toString()).apply(); ver++ }
    fun addMemory(t: String) { val x = t.trim().take(300); if (x.isNotEmpty() && x !in memory) { memory.add(x); while (memory.size > 40) memory.removeAt(0); saveMemory() } }
    fun removeMemory(i: Int) { if (i in memory.indices) { memory.removeAt(i); saveMemory() } }
    fun clearMemory() { memory.clear(); saveMemory() }

    private val REMEMBER = Regex("^\\s*(?:من فضلك\\s+)?(?:تذكّ?ر|احفظ|خلّ?يك تذكر|remember)(?:\\s+(?:إن|أن|ان|اني|إني|أني|that))?\\s+(.{3,})$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    /** "تذكر أن اسمي أحمد" -> saved. Returns the saved sentence or null. Only explicit requests are stored. */
    fun captureMemory(text: String): String? {
        if (!memoryOn) return null
        val m = REMEMBER.find(text.trim()) ?: return null
        val s = m.groupValues[1].trim()
        addMemory(s); return s
    }

    // ---------------------------------------------------------------- skills
    fun skills(): List<Skill> = builtinSkills + customSkills
    fun skillOn(id: String) = ::sp.isInitialized && (sp.getStringSet("skillson", emptySet()) ?: emptySet()).contains(id)
    fun setSkill(id: String, on: Boolean) {
        val s = (sp.getStringSet("skillson", emptySet()) ?: emptySet()).toMutableSet()
        if (on) s.add(id) else s.remove(id)
        sp.edit().putStringSet("skillson", s).apply(); ver++
    }
    private fun saveSkills() {
        val a = JSONArray(); customSkills.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("text", it.text)) }
        sp.edit().putString("skills", a.toString()).apply(); ver++
    }
    fun addSkill(name: String, text: String) { if (name.isBlank() || text.isBlank()) return; val s = Skill(java.util.UUID.randomUUID().toString(), name.trim().take(40), text.trim().take(1500)); customSkills.add(s); saveSkills(); setSkill(s.id, true) }
    fun removeSkill(id: String) { customSkills.removeAll { it.id == id }; setSkill(id, false); saveSkills() }

    // ---------------------------------------------------------------- projects
    private fun saveProjects() {
        val a = JSONArray()
        projects.forEach { p ->
            a.put(JSONObject().put("id", p.id).put("name", p.name).put("ins", p.instructions)
                .put("files", JSONArray(p.files.map { JSONObject().put("n", it.first).put("t", it.second) })))
        }
        sp.edit().putString("projects", a.toString()).apply(); ver++
    }
    fun addProject(name: String, ins: String): Project? {
        if (name.isBlank()) return null
        val p = Project(java.util.UUID.randomUUID().toString(), name.trim().take(40), ins.trim().take(4000), emptyList())
        projects.add(p); saveProjects(); return p
    }
    fun updateProject(id: String, name: String, ins: String) {
        val i = projects.indexOfFirst { it.id == id }; if (i < 0 || name.isBlank()) return
        projects[i] = projects[i].copy(name = name.trim().take(40), instructions = ins.trim().take(4000)); saveProjects()
    }
    fun removeProject(id: String) {
        projects.removeAll { it.id == id }
        val keys = chatProj.keys().asSequence().toList(); keys.forEach { if (chatProj.optString(it) == id) chatProj.remove(it) }
        sp.edit().putString("chatproj", chatProj.toString()).apply(); saveProjects()
    }
    /** Reads a text file (txt, md, code, csv, json…) into the project's knowledge. Returns false for binary files. */
    fun addProjectFile(c: Context, projectId: String, uri: Uri, name: String): Boolean {
        val i = projects.indexOfFirst { it.id == projectId }; if (i < 0) return false
        val bytes = runCatching { c.contentResolver.openInputStream(uri)!!.use { it.readBytes() } }.getOrNull() ?: return false
        if (bytes.take(2000).count { it.toInt() == 0 } > 0) return false
        val text = String(bytes, Charsets.UTF_8).take(20_000)
        val p = projects[i]
        projects[i] = p.copy(files = (p.files + (name to text)).takeLast(8)); saveProjects(); return true
    }
    fun removeProjectFile(projectId: String, idx: Int) {
        val i = projects.indexOfFirst { it.id == projectId }; if (i < 0) return
        val p = projects[i]; projects[i] = p.copy(files = p.files.filterIndexed { j, _ -> j != idx }); saveProjects()
    }
    fun projectOf(chatId: String): Project? = chatProj.optString(chatId).takeIf { it.isNotBlank() }?.let { id -> projects.firstOrNull { it.id == id } }
    fun setChatProject(chatId: String, projectId: String?) {
        if (projectId == null) chatProj.remove(chatId) else chatProj.put(chatId, projectId)
        sp.edit().putString("chatproj", chatProj.toString()).apply(); ver++
    }

    // ---------------------------------------------------------------- connectors
    fun connectorOn(id: String) = ::sp.isInitialized && sp.getBoolean("conn_$id", true)
    fun setConnector(id: String, v: Boolean) { sp.edit().putBoolean("conn_$id", v).apply(); ver++ }

    // ---------------------------------------------------------------- prompt context
    /** Text added to the system prompt: the chat's project, enabled skills and saved memory. */
    fun promptContext(chatId: String): String {
        val parts = mutableListOf<String>()
        projectOf(chatId)?.let { p ->
            val sb = StringBuilder("المشروع الحالي «${p.name}». اتبع تعليماته دائماً.")
            if (p.instructions.isNotBlank()) sb.append("\nتعليمات المشروع:\n").append(p.instructions)
            var budget = 14_000
            p.files.forEach { (n, t) -> if (budget > 0) { val x = t.take(minOf(6000, budget)); budget -= x.length; sb.append("\n=== ملف المشروع: $n ===\n").append(x) } }
            parts += sb.toString()
        }
        val sk = skills().filter { skillOn(it.id) }
        if (sk.isNotEmpty()) parts += "مهارات مفعّلة (طبّقها):\n" + sk.joinToString("\n") { "- ${it.name}: ${it.text}" }
        if (memoryOn && memory.isNotEmpty()) parts += "حقائق طلب المستخدم نفسه أن تتذكرها عنه (استخدمها فقط إذا ارتبطت بالسؤال):\n" + memory.takeLast(30).joinToString("\n") { "- $it" }
        return parts.joinToString("\n\n")
    }

    // ---------------------------------------------------------------- Qaf
    var qafUrl: String
        get() = (if (::sp.isInitialized) sp.getString("qafurl", null) else null)?.trim()?.takeIf { it.startsWith("https://qafai.net") } ?: DEFAULT_QAF_URL
        set(v) { sp.edit().putString("qafurl", v.trim()).apply(); ver++ }
    var qafKey: String
        get() = Secure.decrypt(if (::sp.isInitialized) sp.getString("qafkey", "").orEmpty() else "").ifBlank { BuildConfig.QAF_API_KEY }
        set(v) { sp.edit().putString("qafkey", Secure.encrypt(v.trim())).apply(); ver++ }

    private val STRONG = Regex("حكم|حلال|حرام|فتو[ىي]|يجوز|جائز|شرعا|شرعاً|تفسير|حديث|وضوء|تيمم|زكا[ةه]|كفار[ةه]|ربا|طلاق|عقيق[ةه]|أضحي[ةه]|fatwa|halal|haram|hadith|tafsir", RegexOption.IGNORE_CASE)
    private val TERMS = Regex("صلا[ةه]|صيام|صوم|حج|عمر[ةه]|رمضان|دعاء|أذكار|اذكار|إسلام|اسلام|الإسلام|القرآن|القران|نبي|رسول|صحاب[ةه]|الجن[ةه]|النار|القبر|توب[ةه]|الله|ذنب|islam|prayer|salah|quran|ramadan|allah", RegexOption.IGNORE_CASE)
    private val QUESTION = Regex("هل |ما |ماذا|كيف|لماذا|ليش|لشو|شو |ايش|إيش|متى|كم |أين|وين|؟|\\?|what|how|why|is it|can i|should i", RegexOption.IGNORE_CASE)
    fun isReligious(t: String): Boolean {
        val s = t.trim()
        if (s.startsWith("/") || s.length < 4) return false
        return STRONG.containsMatchIn(s) || (TERMS.containsMatchIn(s) && QUESTION.containsMatchIn(s))
    }

    private const val QAF_SYSTEM = "أنت مساعد إسلامي موثوق. أجب عن السؤال الديني بالعربية الفصحى المبسطة وبشكل منظم ومختصر. اعتمد على القرآن والسنة الصحيحة وأقوال العلماء المعتبرين، واذكر مصدر الاستدلال (اسم السورة ورقم الآية، أو الكتاب وراوي الحديث ودرجته). لا تكتب نص آية أو حديث من ذاكرتك إلا إذا كنت متأكداً منه حرفياً، وإلا اذكر رقم الآية أو اسم الحديث فقط. إذا اختلف العلماء فاذكر الأقوال بإيجاز. في الأحوال الشخصية الخاصة انصح بمراجعة عالم أو دار إفتاء. بدون سخرية ولا ألفاظ نابية أبداً."

    /** Asks QafAI (https://qafai.net, POST /api/inference, Bearer key, SSE reply). The key is only ever sent to qafai.net. */
    suspend fun askQaf(question: String, history: List<Pair<Boolean, String>> = emptyList()): String = withContext(Dispatchers.IO) {
        val key = qafKey
        require(key.isNotBlank()) { "ما في مفتاح Qaf" }
        val endpoint = qafUrl.trim().trimEnd('/').removeSuffix("/api/inference") + "/api/inference"
        require(endpoint.startsWith("https://qafai.net/")) { "عنوان Qaf لازم يكون https://qafai.net" }
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", QAF_SYSTEM))
        val turns = history.takeLast(6).filter { it.second.isNotBlank() }
        turns.forEach { (fromUser, t) -> msgs.put(JSONObject().put("role", if (fromUser) "user" else "assistant").put("content", t.take(1500))) }
        if (turns.isEmpty() || turns.last().second != question) msgs.put(JSONObject().put("role", "user").put("content", question))
        val body = JSONObject().put("messages", msgs).put("model", "qaf:chat").put("temperature", 0.3).put("max_tokens", 1500)
        val c = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15_000; readTimeout = 120_000; doOutput = true
            setRequestProperty("Content-Type", "application/json"); setRequestProperty("Accept", "text/event-stream")
            setRequestProperty("Authorization", "Bearer $key")
        }
        try {
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code !in 200..299) {
                val t = c.errorStream?.bufferedReader()?.readText().orEmpty()
                val d = runCatching { JSONObject(t).optString("detail") }.getOrDefault("").ifBlank { t.take(160) }
                error(when (code) { 401 -> "مفتاح Qaf غير صحيح أو ناقص (401)"; 402 -> "رصيد Qaf غير كاف (402)"; 429 -> "تجاوزت حد الطلبات، انتظر دقيقة (429)"; else -> "HTTP $code $d" })
            }
            val out = StringBuilder(); val raw = StringBuilder()
            c.inputStream.bufferedReader().useLines { lines ->
                for (line in lines) {
                    if (!line.startsWith("data:")) { if (raw.length < 4000) raw.append(line); continue }
                    val j = runCatching { JSONObject(line.removePrefix("data:").trim()) }.getOrNull() ?: continue
                    if (j.has("error")) error("Qaf: " + j.optString("error").take(200))
                    if (j.has("chunk")) out.append(j.optString("chunk"))
                    if (j.optBoolean("done")) break
                }
            }
            val ans = out.toString().trim().ifBlank { qafAnswer(raw.toString()) }
            if (ans.isBlank()) error("رد فارغ من Qaf")
            ans
        } finally { c.disconnect() }
    }

    private fun qafAnswer(raw: String): String {
        val j = runCatching { JSONObject(raw) }.getOrNull() ?: return raw.trim()
        j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")?.takeIf { it.isNotBlank() }?.let { return it.trim() }
        for (k in listOf("answer", "response", "text", "output", "result", "message", "content")) {
            val v = j.opt(k)
            if (v is String && v.isNotBlank()) return v.trim()
            if (v is JSONObject) listOf("answer", "text", "content").forEach { kk -> v.optString(kk).takeIf { it.isNotBlank() }?.let { return it.trim() } }
        }
        j.optJSONObject("data")?.let { d -> listOf("answer", "response", "text", "content").forEach { kk -> d.optString(kk).takeIf { it.isNotBlank() }?.let { return it.trim() } } }
        return ""
    }

    // ---------------------------------------------------------------- data connectors (real public APIs, no key)
    private fun get(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout = 10_000; readTimeout = 15_000; setRequestProperty("User-Agent", "AIPhoneAgent/1.0") }
        try {
            val code = c.responseCode
            val t = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
            if (code !in 200..299) error("HTTP $code")
            return t
        } finally { c.disconnect() }
    }
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private val CITY = Regex("(?:في|فى|بـ?|ب|in|at)\\s+([\\p{L}][\\p{L} ]{1,28})", RegexOption.IGNORE_CASE)
    private fun cityOf(t: String): String? = CITY.findAll(t).lastOrNull()?.groupValues?.get(1)?.trim()?.replace(Regex("\\s+(اليوم|الآن|الان|بكرة|غدا|غداً|لو سمحت|please)$"), "")?.takeIf { it.length >= 2 }

    private val PRAYER = Regex("(?:مواقيت|اوقات|أوقات|موعد|مواعيد)\\s*(?:ال)?صلا[ةه]|prayer times|وقت\\s+(?:صلاة\\s+)?(?:ال)?(?:فجر|ظهر|عصر|مغرب|عشاء)", RegexOption.IGNORE_CASE)
    private val WEATHER = Regex("(?:ال)?(?:طقس|جو)\\b|weather|درجة الحرارة|درجات الحرارة", RegexOption.IGNORE_CASE)
    private val WIKI = Regex("ويكيبيديا|wikipedia|نبذة عن|معلومات عن|مين هو|مين هي|من هو|من هي|who is|what is", RegexOption.IGNORE_CASE)

    /** Result of a connector: [direct] = ready answer to show as is; [context] = real data handed to the model to answer from. */
    class ConnResult(val direct: String? = null, val context: String? = null)

    suspend fun connectorFor(text: String): ConnResult? = withContext(Dispatchers.IO) {
        val t = text.trim()
        if (t.startsWith("/")) return@withContext null
        try {
            when {
                connectorOn("prayer") && PRAYER.containsMatchIn(t) -> {
                    val city = cityOf(t) ?: return@withContext ConnResult(direct = "في أي مدينة؟ اكتب مثلاً: مواقيت الصلاة في دمشق")
                    val d = JSONObject(get("https://api.aladhan.com/v1/timingsByAddress?address=${enc(city)}")).getJSONObject("data")
                    val tm = d.getJSONObject("timings"); val date = d.getJSONObject("date").optString("readable")
                    val tz = d.optJSONObject("meta")?.optString("timezone").orEmpty()
                    fun x(k: String) = tm.optString(k).substringBefore(' ')
                    ConnResult(direct = "مواقيت الصلاة في $city ($date، $tz):\nالفجر: ${x("Fajr")}\nالشروق: ${x("Sunrise")}\nالظهر: ${x("Dhuhr")}\nالعصر: ${x("Asr")}\nالمغرب: ${x("Maghrib")}\nالعشاء: ${x("Isha")}")
                }
                connectorOn("weather") && WEATHER.containsMatchIn(t) -> {
                    val city = cityOf(t) ?: return@withContext ConnResult(direct = "طقس أي مدينة؟ اكتب مثلاً: كيف الطقس في إسطنبول")
                    val g = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=${enc(city)}&count=1&language=ar")).optJSONArray("results")?.optJSONObject(0)
                        ?: return@withContext ConnResult(direct = "ما لقيت مدينة اسمها «$city».")
                    val w = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=${g.getDouble("latitude")}&longitude=${g.getDouble("longitude")}" +
                        "&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto"))
                    val cur = w.getJSONObject("current"); val dl = w.getJSONObject("daily")
                    ConnResult(direct = "الطقس الآن في ${g.optString("name", city)}: ${wmo(cur.optInt("weather_code"))}\nالحرارة ${cur.optDouble("temperature_2m")}° (تحس كأنها ${cur.optDouble("apparent_temperature")}°)\nالرطوبة ${cur.optInt("relative_humidity_2m")}% · الرياح ${cur.optDouble("wind_speed_10m")} كم/س\nاليوم: عظمى ${dl.getJSONArray("temperature_2m_max").optDouble(0)}° / صغرى ${dl.getJSONArray("temperature_2m_min").optDouble(0)}°")
                }
                connectorOn("wiki") && WIKI.containsMatchIn(t) -> {
                    val q = t.replace(WIKI, " ").replace(Regex("[؟?]"), " ").replace(Regex("\\s+"), " ").trim()
                    if (q.length < 2) return@withContext null
                    val lang = if (q.any { it in '\u0600'..'\u06FF' }) "ar" else "en"
                    val title = JSONObject(get("https://$lang.wikipedia.org/w/api.php?action=query&list=search&srsearch=${enc(q)}&format=json&srlimit=1"))
                        .getJSONObject("query").getJSONArray("search").optJSONObject(0)?.optString("title") ?: return@withContext null
                    val s = JSONObject(get("https://$lang.wikipedia.org/api/rest_v1/page/summary/${enc(title).replace("+", "%20")}"))
                    val ex = s.optString("extract")
                    if (ex.isBlank()) null else ConnResult(context = "بيانات حقيقية من ويكيبيديا عن «$title»: $ex\nأجب المستخدم اعتماداً على هذا النص فقط وبكلامك، ولا تضف معلومات من عندك.")
                }
                else -> null
            }
        } catch (e: Exception) { null }
    }

    private fun wmo(c: Int) = when (c) {
        0 -> "صافي"; 1, 2 -> "غائم جزئياً"; 3 -> "غائم"; 45, 48 -> "ضباب"; in 51..57 -> "رذاذ"; in 61..67 -> "مطر"; in 71..77 -> "ثلج"; in 80..82 -> "زخات مطر"; in 95..99 -> "عاصفة رعدية"; else -> "—"
    }

    // ---------------------------------------------------------------- export the chat as a Markdown file
    private val MONTHS = listOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")

    fun chatMarkdown(title: String, msgs: List<ChatMsg>): String {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US)
        val sb = StringBuilder("# ").append(title.ifBlank { "محادثة" }).append("\n\n> تم التصدير من AI Phone Agent بتاريخ ").append(fmt.format(java.util.Date())).append("\n")
        for (m in msgs) {
            if (m.thinking || (m.text.isBlank() && m.atts.isEmpty())) continue
            sb.append("\n---\n\n### ").append(if (m.fromUser) "أنت" else "المساعد").append(" · ").append(fmt.format(java.util.Date(m.time))).append("\n\n")
            if (m.text.isNotBlank()) sb.append(m.text.trim()).append("\n")
            m.atts.forEach { sb.append("\n📎 ").append(it.name).append("\n") }
        }
        return sb.toString()
    }

    /** Writes the whole conversation to a .md file and opens the share sheet. Returns false if there is nothing to export. */
    fun shareChat(c: Context, title: String, msgs: List<ChatMsg>): Boolean {
        if (msgs.none { !it.thinking && (it.text.isNotBlank() || it.atts.isNotEmpty()) }) return false
        val dir = File(c.cacheDir, "export").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
        val safe = title.replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim().replace(' ', '_').take(40).ifBlank { "chat" }
        val f = File(dir, "$safe.md")
        f.writeText(chatMarkdown(title, msgs), Charsets.UTF_8)
        val uri = FileProvider.getUriForFile(c, c.packageName + ".files", f)
        val send = Intent(Intent.ACTION_SEND).setType("text/markdown").putExtra(Intent.EXTRA_STREAM, uri).putExtra(Intent.EXTRA_SUBJECT, title)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(Intent.createChooser(send, "مشاركة المحادثة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }
}

/** The text without fenced code blocks, for reading a reply aloud. */
fun String.withoutCode(): String = replace(Regex("```[\\s\\S]*?(```|$)"), " (كود) ")
