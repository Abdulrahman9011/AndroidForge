package com.aiphoneagent

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Patterns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom

/** Result of an account action: [error] = failed (shown in red; "" = cancelled by the user, show nothing), [info] = done but something to tell the user (shown in green). */
class AuthRes(val error: String? = null, val info: String? = null) { val ok get() = error == null }

/**
 * The signed-in user, stored on a real server (Supabase):
 *  - Auth: e-mail + password (with e-mail confirmation and password reset) and Google (Credential Manager ID token -> Supabase).
 *  - Profile: table public.profiles (id, full_name, avatar_url), protected by row-level security (each user sees only their row).
 *  - Photo: storage bucket "avatars" at <uid>/avatar.jpg.
 * The phone keeps only the session tokens (encrypted with the Keystore) and a cached copy of the photo.
 * Server setup: supabase/setup.sql + SUPABASE_URL / SUPABASE_ANON_KEY at build time (see SETUP-ACCOUNTS.md).
 */
object UserProfile {
    private lateinit var sp: SharedPreferences
    private lateinit var appCtx: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val refreshLock = Mutex()

    var name by mutableStateOf("ضيف")
    var email by mutableStateOf("")
    /** "email" | "google" | "" (guest) */
    var provider by mutableStateOf("")
    /** Bumped when the photo changes, so the avatar reloads. */
    var photoVersion by mutableIntStateOf(0)
    /** True while a background sync with the server runs (profile screen shows it). */
    var syncing by mutableStateOf(false)
    var uid = ""
        private set
    private var avatarUrl = ""
    private var firstLoad = true
    /** Called on the main thread when someone signs in (true, uid) or out (false, uid of the account that left). Conversations sync hangs on it. */
    var onAuthChanged: ((Boolean, String) -> Unit)? = null

    val signedIn get() = email.isNotBlank()
    val subtitle get() = if (signedIn) email else "سجّل الدخول لحفظ حسابك على السيرفر"

    private val base get() = BuildConfig.SUPABASE_URL.trimEnd('/')
    private val anon get() = BuildConfig.SUPABASE_ANON_KEY.trim()
    val configured get() = base.startsWith("https://") && anon.length > 20
    private const val NOT_CONFIGURED = "السيرفر غير مضبوط بهالنسخة: لازم تحط SUPABASE_URL و SUPABASE_ANON_KEY (شوف ملف SETUP-ACCOUNTS.md)."

    // ---------------------------------------------------------------- session

    private var access: String
        get() = Secure.decrypt(sp.getString("at", "").orEmpty())
        set(v) { sp.edit().putString("at", Secure.encrypt(v)).apply() }
    private var refresh: String
        get() = Secure.decrypt(sp.getString("rt", "").orEmpty())
        set(v) { sp.edit().putString("rt", Secure.encrypt(v)).apply() }
    private var expiresAt: Long
        get() = sp.getLong("exp", 0L)
        set(v) { sp.edit().putLong("exp", v).apply() }

    fun load(c: Context) {
        if (!::sp.isInitialized) {
            appCtx = c.applicationContext
            sp = appCtx.getSharedPreferences("accounts_v2", Context.MODE_PRIVATE)
        }
        uid = sp.getString("uid", "").orEmpty()
        if (uid.isNotBlank() && refresh.isNotBlank()) {
            email = sp.getString("email", "").orEmpty()
            name = sp.getString("name", "").orEmpty().ifBlank { email.substringBefore('@') }
            provider = sp.getString("provider", "email").orEmpty()
            avatarUrl = sp.getString("avatar", "").orEmpty()
            // Pull the latest name/photo from the server (another phone may have changed them).
            if (firstLoad) { scope.launch { syncProfile() }; onAuthChanged?.invoke(true, uid) }
        }
        firstLoad = false
    }

    /** The auth screen is shown once at first launch; "continue as guest" also counts as seen. */
    var authSeen: Boolean
        get() = ::sp.isInitialized && sp.getBoolean("authSeen", false)
        set(v) { if (::sp.isInitialized) sp.edit().putBoolean("authSeen", v).apply() }

    private fun saveSession(j: JSONObject, prov: String) {
        val prevUid = uid
        val user = j.optJSONObject("user") ?: JSONObject()
        access = j.optString("access_token")
        refresh = j.optString("refresh_token")
        val exp = j.optLong("expires_at", 0L).takeIf { it > 0 } ?: (System.currentTimeMillis() / 1000 + j.optLong("expires_in", 3600))
        expiresAt = exp
        uid = user.optString("id")
        val mail = user.optString("email").lowercase()
        val meta = user.optJSONObject("user_metadata") ?: JSONObject()
        val n = meta.optString("full_name").ifBlank { meta.optString("name") }.ifBlank { mail.substringBefore('@') }
        sp.edit().putString("uid", uid).putString("email", mail).putString("provider", prov).putString("name", n).apply()
        email = mail; provider = prov; name = n
        photoVersion++
        if (uid.isNotBlank() && uid != prevUid) onAuthChanged?.invoke(true, uid)
    }

    private fun clearSession() {
        val old = uid
        if (::sp.isInitialized) sp.edit().remove("at").remove("rt").remove("exp").remove("uid").remove("email").remove("name").remove("provider").remove("avatar").apply()
        uid = ""; email = ""; name = "ضيف"; provider = ""; avatarUrl = ""; photoVersion++
        if (old.isNotBlank()) onAuthChanged?.invoke(false, old)
    }

    /** A valid access token, refreshed when it is about to expire. Null = signed out (or the session was revoked). */
    internal suspend fun token(): String? {
        refreshLock.withLock {
            if (uid.isBlank()) return null
            if (System.currentTimeMillis() / 1000 < expiresAt - 90 && access.isNotBlank()) return access
            val r = call("POST", "/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", refresh), auth = null)
            return when {
                r.code in 200..299 -> { withContext(Dispatchers.Main) { saveSession(JSONObject(r.body), provider.ifBlank { "email" }) }; access }
                r.code in 400..499 -> { withContext(Dispatchers.Main) { clearSession() }; null }   // refresh token revoked/expired
                else -> null                                                                          // offline: keep the session, try later
            }
        }
    }

    // ---------------------------------------------------------------- HTTP

    internal class Http(val code: Int, val body: String)

    internal suspend fun call(
        method: String, path: String, json: Any? = null, auth: String? = "",
        raw: ByteArray? = null, contentType: String? = null, headers: Map<String, String> = emptyMap()
    ): Http = withContext(Dispatchers.IO) {
        try {
            val c = URL(base + path).openConnection() as HttpURLConnection
            c.requestMethod = method
            c.connectTimeout = 12_000; c.readTimeout = 30_000
            c.setRequestProperty("apikey", anon)
            // New "publishable" keys (sb_publishable_...) are not JWTs: they go only in the apikey header.
            // The old anon key (eyJ...) is a JWT and may also be sent as the bearer when no user is signed in.
            val bearer = when (auth) { null -> null; "" -> access.ifBlank { null }; else -> auth } ?: anon.takeIf { it.startsWith("eyJ") }
            if (bearer != null) c.setRequestProperty("Authorization", "Bearer $bearer")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            val bytes = raw ?: json?.toString()?.toByteArray()
            if (bytes != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", contentType ?: "application/json")
                c.setFixedLengthStreamingMode(bytes.size)
                c.outputStream.use { it.write(bytes) }
            }
            val code = c.responseCode
            val body = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            c.disconnect()
            Http(code, body)
        } catch (e: java.net.UnknownHostException) { Http(-1, "offline")
        } catch (e: java.io.IOException) { Http(-1, e.message ?: "network") }
    }

    private fun errMsg(r: Http): String {
        if (r.code == -1) return "ما في اتصال بالسيرفر. تأكد من الإنترنت."
        val j = runCatching { JSONObject(r.body) }.getOrNull()
        val m = (j?.optString("msg")?.ifBlank { null } ?: j?.optString("error_description")?.ifBlank { null } ?: j?.optString("message")?.ifBlank { null }
            ?: j?.optString("error")?.ifBlank { null } ?: r.body.take(120)).orEmpty()
        val code = j?.optString("error_code").orEmpty()
        return when {
            code == "invalid_credentials" || m.contains("Invalid login credentials", true) -> "البريد أو كلمة المرور غلط."
            code == "email_not_confirmed" || m.contains("not confirmed", true) -> "لازم تأكد بريدك أولاً: افتح رسالة التأكيد يلي وصلتك."
            code == "user_already_exists" || m.contains("already registered", true) -> "هذا البريد مسجّل مسبقاً، سجّل الدخول."
            code == "weak_password" || m.contains("Password should", true) -> "كلمة المرور ضعيفة: 8 أحرف على الأقل مع أحرف وأرقام."
            code == "over_email_send_rate_limit" || r.code == 429 -> "محاولات كثيرة، استنى شوي وجرّب مرة ثانية."
            code == "provider_disabled" || m.contains("provider is not enabled", true) -> "تسجيل Google غير مفعّل بالسيرفر (Supabase > Authentication > Providers > Google)."
            m.contains("audience", true) || m.contains("Unacceptable audience", true) -> "معرّف Google غير مضاف بالسيرفر: حط Web Client ID بخانة Client IDs بإعدادات Google في Supabase."
            m.contains("nonce", true) -> "فشل التحقق من Google (nonce). جرّب مرة ثانية."
            else -> "خطأ من السيرفر (${r.code}): $m"
        }
    }

    // ---------------------------------------------------------------- e-mail + password

    private fun passwordError(p: String): String? = when {
        p.length < 8 -> "كلمة المرور لازم تكون 8 أحرف على الأقل"
        p.none { it.isDigit() } || p.none { it.isLetter() } -> "كلمة المرور لازم تحتوي أحرف وأرقام"
        else -> null
    }

    suspend fun register(c: Context, fullName: String, mail0: String, pass: String, confirm: String): AuthRes {
        load(c)
        if (!configured) return AuthRes(NOT_CONFIGURED)
        val mail = mail0.trim().lowercase()
        if (fullName.isBlank()) return AuthRes("اكتب اسمك")
        if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()) return AuthRes("البريد الإلكتروني غير صحيح")
        passwordError(pass)?.let { return AuthRes(it) }
        if (pass != confirm) return AuthRes("كلمتا المرور غير متطابقتين")
        val r = call("POST", "/auth/v1/signup", JSONObject().put("email", mail).put("password", pass)
            .put("data", JSONObject().put("full_name", fullName.trim())), auth = null)
        if (r.code !in 200..299) return AuthRes(errMsg(r))
        val j = JSONObject(r.body)
        if (j.optString("access_token").isNotBlank()) {
            withContext(Dispatchers.Main) { saveSession(j, "email") }
            upsertProfile(JSONObject().put("full_name", fullName.trim()).put("email", mail))
            return AuthRes()
        }
        // Supabase returns a user without a session when e-mail confirmation is on.
        // An existing address also comes back like this (with no identities) so nobody can probe which e-mails are registered.
        val ids = j.optJSONArray("identities") ?: j.optJSONObject("user")?.optJSONArray("identities")
        if (ids != null && ids.length() == 0) return AuthRes("هذا البريد مسجّل مسبقاً، سجّل الدخول.")
        return AuthRes(info = "تم إنشاء الحساب ✓ بعتنالك رسالة تأكيد على $mail. افتحها واضغط الرابط، وبعدين سجّل الدخول.")
    }

    suspend fun login(c: Context, mail0: String, pass: String): AuthRes {
        load(c)
        if (!configured) return AuthRes(NOT_CONFIGURED)
        val mail = mail0.trim().lowercase()
        if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()) return AuthRes("البريد الإلكتروني غير صحيح")
        if (pass.isBlank()) return AuthRes("اكتب كلمة المرور")
        val r = call("POST", "/auth/v1/token?grant_type=password", JSONObject().put("email", mail).put("password", pass), auth = null)
        if (r.code !in 200..299) return AuthRes(errMsg(r))
        withContext(Dispatchers.Main) { saveSession(JSONObject(r.body), "email") }
        syncProfile()
        return AuthRes()
    }

    suspend fun resendConfirmation(mail0: String): AuthRes {
        if (!configured) return AuthRes(NOT_CONFIGURED)
        val mail = mail0.trim().lowercase()
        if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()) return AuthRes("اكتب بريدك أولاً")
        val r = call("POST", "/auth/v1/resend", JSONObject().put("type", "signup").put("email", mail), auth = null)
        return if (r.code in 200..299) AuthRes(info = "بعتنا رسالة التأكيد من جديد على $mail.") else AuthRes(errMsg(r))
    }

    suspend fun resetPassword(mail0: String): AuthRes {
        if (!configured) return AuthRes(NOT_CONFIGURED)
        val mail = mail0.trim().lowercase()
        if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()) return AuthRes("اكتب بريدك بخانة البريد أولاً")
        val r = call("POST", "/auth/v1/recover", JSONObject().put("email", mail), auth = null)
        return if (r.code in 200..299) AuthRes(info = "إذا كان في حساب بهالبريد، رح يوصلك كود من 6 أرقام. اكتبه تحت مع كلمة المرور الجديدة.") else AuthRes(errMsg(r))
    }

    /** Second half of "forgot password": the 6-digit code from the e-mail ({{ .Token }} in the Reset Password template) + the new password. */
    suspend fun completeReset(c: Context, mail0: String, code: String, new: String, confirm: String): AuthRes {
        load(c)
        if (!configured) return AuthRes(NOT_CONFIGURED)
        val mail = mail0.trim().lowercase()
        val otp = code.filter { it.isDigit() }
        if (otp.length < 6) return AuthRes("اكتب الكود يلي وصلك بالإيميل (6 أرقام)")
        passwordError(new)?.let { return AuthRes(it) }
        if (new != confirm) return AuthRes("كلمتا المرور غير متطابقتين")
        val v = call("POST", "/auth/v1/verify", JSONObject().put("type", "recovery").put("email", mail).put("token", otp), auth = null)
        if (v.code !in 200..299) return AuthRes(if (v.code == -1) errMsg(v) else "الكود غلط أو انتهت صلاحيته. اطلب كود جديد.")
        withContext(Dispatchers.Main) { saveSession(JSONObject(v.body), "email") }
        val r = call("PUT", "/auth/v1/user", JSONObject().put("password", new))
        if (r.code !in 200..299) return AuthRes(errMsg(r))
        syncProfile()
        return AuthRes()
    }

    suspend fun changePassword(c: Context, old: String, new: String, confirm: String): AuthRes {
        load(c)
        if (!signedIn) return AuthRes("سجّل الدخول أولاً")
        if (provider == "google") return AuthRes("كلمة مرور حساب Google تُدار من Google")
        passwordError(new)?.let { return AuthRes(it) }
        if (new != confirm) return AuthRes("كلمتا المرور الجديدتان غير متطابقتين")
        // The server checks the current password: sign in with it first.
        val chk = call("POST", "/auth/v1/token?grant_type=password", JSONObject().put("email", email).put("password", old), auth = null)
        if (chk.code !in 200..299) return AuthRes(if (chk.code == -1) errMsg(chk) else "كلمة المرور الحالية غير صحيحة")
        withContext(Dispatchers.Main) { saveSession(JSONObject(chk.body), "email") }
        val r = call("PUT", "/auth/v1/user", JSONObject().put("password", new))
        return if (r.code in 200..299) AuthRes() else AuthRes(errMsg(r))
    }

    fun signOut(c: Context) {
        load(c)
        val t = access
        if (t.isNotBlank() && configured) {
            CloudChats.flushBeforeSignOut(uid, t)            // last upload of this account's chats, before they leave the phone
            scope.launch { CloudChats.lastFlush?.join(); call("POST", "/auth/v1/logout", JSONObject(), auth = t) }
        }
        photoFile(appCtx)?.delete()
        clearSession()
    }

    /** Deletes the account and all its data on the server (SQL function public.delete_my_account in setup.sql). */
    suspend fun deleteAccount(c: Context): AuthRes {
        load(c)
        val t = token() ?: return AuthRes("سجّل الدخول أولاً")
        runCatching { call("DELETE", "/storage/v1/object/avatars/$uid/avatar.jpg", auth = t) }
        val r = call("POST", "/rest/v1/rpc/delete_my_account", JSONObject(), auth = t)
        if (r.code !in 200..299) return AuthRes(errMsg(r))
        withContext(Dispatchers.Main) { photoFile(appCtx)?.delete(); clearSession() }
        return AuthRes()
    }

    // ---------------------------------------------------------------- Google

    private fun sha256Hex(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    /** Google account picker -> verified ID token -> Supabase session. */
    suspend fun googleSignIn(act: Activity): AuthRes {
        load(act)
        if (!configured) return AuthRes(NOT_CONFIGURED)
        val clientId = BuildConfig.GOOGLE_WEB_CLIENT_ID
        if (clientId.isBlank()) return AuthRes("تسجيل Google غير مضبوط بهالنسخة: لازم تحط GOOGLE_WEB_CLIENT_ID (شوف SETUP-ACCOUNTS.md).")
        val rawNonce = ByteArray(24).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        val hashed = sha256Hex(rawNonce)
        val cm = CredentialManager.create(act)
        val cred = try {
            val opt = GetGoogleIdOption.Builder().setFilterByAuthorizedAccounts(false).setServerClientId(clientId).setNonce(hashed).setAutoSelectEnabled(false).build()
            cm.getCredential(act, GetCredentialRequest.Builder().addCredentialOption(opt).build()).credential
        } catch (e: GetCredentialCancellationException) { return AuthRes(error = "")
        } catch (e: NoCredentialException) {
            // No Google account offered by the bottom sheet: the full "Sign in with Google" dialog lets the user add one.
            try {
                val opt = GetSignInWithGoogleOption.Builder(clientId).setNonce(hashed).build()
                cm.getCredential(act, GetCredentialRequest.Builder().addCredentialOption(opt).build()).credential
            } catch (e2: GetCredentialCancellationException) { return AuthRes(error = "")
            } catch (e2: Exception) { return AuthRes("ما لقيت حساب Google على الهاتف: ${e2.message?.take(100)}") }
        } catch (e: Exception) { return AuthRes("فشل تسجيل الدخول بـ Google: ${e.message?.take(140)}") }
        if (!(cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL)) return AuthRes("تعذّر تسجيل الدخول بحساب Google")
        val g = GoogleIdTokenCredential.createFrom(cred.data)
        val r = call("POST", "/auth/v1/token?grant_type=id_token",
            JSONObject().put("provider", "google").put("id_token", g.idToken).put("nonce", rawNonce), auth = null)
        if (r.code !in 200..299) return AuthRes(errMsg(r))
        withContext(Dispatchers.Main) { saveSession(JSONObject(r.body), "google") }
        // First Google sign-in: create the profile with the Google name/photo; later ones keep what the user edited.
        val existing = fetchProfile()
        if (existing == null) {
            upsertProfile(JSONObject().put("full_name", g.displayName ?: name).put("email", email))
            g.profilePictureUri?.let { importRemotePhoto(it.toString()) }
        }
        syncProfile()
        return AuthRes()
    }

    // ---------------------------------------------------------------- profile (table public.profiles)

    private suspend fun fetchProfile(): JSONObject? {
        val t = token() ?: return null
        val r = call("GET", "/rest/v1/profiles?id=eq.${URLEncoder.encode(uid, "UTF-8")}&select=*", auth = t)
        if (r.code !in 200..299) return null
        return runCatching { JSONArray(r.body).optJSONObject(0) }.getOrNull()
    }

    private suspend fun upsertProfile(fields: JSONObject): Boolean {
        val t = token() ?: return false
        fields.put("id", uid).put("updated_at", java.time.Instant.now().toString())
        val r = call("POST", "/rest/v1/profiles", JSONArray().put(fields), auth = t,
            headers = mapOf("Prefer" to "resolution=merge-duplicates,return=minimal"))
        return r.code in 200..299
    }

    /** Pulls name + photo from the server into the UI (and the photo into the local cache). */
    suspend fun syncProfile() {
        if (!configured || uid.isBlank()) return
        syncing = true
        try {
            val p = fetchProfile() ?: return
            val n = p.optString("full_name").takeIf { it.isNotBlank() && it != "null" }
            val av = p.optString("avatar_url").takeIf { it.isNotBlank() && it != "null" }.orEmpty()
            withContext(Dispatchers.Main) {
                if (n != null) { name = n; sp.edit().putString("name", n).apply() }
            }
            if (av != avatarUrl || (av.isNotBlank() && photo(appCtx) == null)) {
                if (av.isBlank()) photoFile(appCtx)?.delete() else downloadTo(av, photoFile(appCtx))
                avatarUrl = av; sp.edit().putString("avatar", av).apply()
                withContext(Dispatchers.Main) { photoVersion++ }
            }
        } finally { syncing = false }
    }

    suspend fun updateName(c: Context, n: String): AuthRes {
        load(c)
        if (!signedIn) return AuthRes("سجّل الدخول أولاً")
        if (n.isBlank()) return AuthRes("الاسم فاضي")
        if (!upsertProfile(JSONObject().put("full_name", n.trim()))) return AuthRes("ما قدرت احفظ الاسم على السيرفر. تأكد من الإنترنت.")
        call("PUT", "/auth/v1/user", JSONObject().put("data", JSONObject().put("full_name", n.trim())))
        withContext(Dispatchers.Main) { name = n.trim(); sp.edit().putString("name", name).apply() }
        return AuthRes()
    }

    // ---------------------------------------------------------------- photo (storage bucket "avatars")

    private fun photoFile(c: Context): File? {
        if (uid.isBlank()) return null
        return File(File(c.filesDir, "profile").apply { mkdirs() }, uid.take(16) + ".jpg")
    }
    fun photo(c: Context): File? = photoFile(c)?.takeIf { it.exists() && it.length() > 0 }

    private suspend fun downloadTo(url: String, f: File?) = withContext(Dispatchers.IO) {
        if (f == null) return@withContext
        runCatching {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 12_000; c.readTimeout = 30_000
            if (c.responseCode == 200) { val b = c.inputStream.use { it.readBytes() }; if (b.size > 100) f.writeBytes(b) }
            c.disconnect()
        }
    }

    private fun squareJpeg(bytes: ByteArray): ByteArray? = runCatching {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var ss = 1
        while (minOf(o.outWidth, o.outHeight) / ss > 768 && ss < 64) ss *= 2
        val src = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = ss })!!
        val side = minOf(src.width, src.height)
        val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        val out = java.io.ByteArrayOutputStream()
        sq.compress(Bitmap.CompressFormat.JPEG, 86, out)
        out.toByteArray()
    }.getOrNull()

    private suspend fun uploadPhoto(jpeg: ByteArray): AuthRes {
        val t = token() ?: return AuthRes("سجّل الدخول أولاً")
        val r = call("POST", "/storage/v1/object/avatars/$uid/avatar.jpg", raw = jpeg, contentType = "image/jpeg", auth = t,
            headers = mapOf("x-upsert" to "true", "cache-control" to "3600"))
        if (r.code !in 200..299) return AuthRes(if (r.code == -1) errMsg(r) else "فشل رفع الصورة للسيرفر (${r.code}). تأكد أنك شغّلت setup.sql.")
        val url = "$base/storage/v1/object/public/avatars/$uid/avatar.jpg?v=${System.currentTimeMillis()}"
        if (!upsertProfile(JSONObject().put("avatar_url", url))) return AuthRes("انرفعت الصورة بس ما انحفظ رابطها. جرّب مرة ثانية.")
        withContext(Dispatchers.IO) { photoFile(appCtx)?.writeBytes(jpeg) }
        avatarUrl = url; sp.edit().putString("avatar", url).apply()
        withContext(Dispatchers.Main) { photoVersion++ }
        return AuthRes()
    }

    suspend fun setPhoto(c: Context, uri: Uri): AuthRes {
        load(c)
        if (!signedIn) return AuthRes("سجّل الدخول أولاً")
        val bytes = withContext(Dispatchers.IO) { runCatching { c.contentResolver.openInputStream(uri)!!.use { it.readBytes() } }.getOrNull() }
            ?: return AuthRes("تعذّر فتح الصورة")
        val jpeg = withContext(Dispatchers.Default) { squareJpeg(bytes) } ?: return AuthRes("تعذّر استخدام هذه الصورة")
        return uploadPhoto(jpeg)
    }

    private suspend fun importRemotePhoto(url: String) {
        val bytes = withContext(Dispatchers.IO) {
            runCatching { val c = URL(url.replace("=s96-c", "=s512-c")).openConnection() as HttpURLConnection; c.connectTimeout = 10_000; c.inputStream.use { it.readBytes() } }.getOrNull()
        } ?: return
        squareJpeg(bytes)?.let { uploadPhoto(it) }
    }

    suspend fun removePhoto(c: Context): AuthRes {
        load(c)
        val t = token() ?: return AuthRes("سجّل الدخول أولاً")
        call("DELETE", "/storage/v1/object/avatars/$uid/avatar.jpg", auth = t)
        upsertProfile(JSONObject().put("avatar_url", JSONObject.NULL))
        photoFile(appCtx)?.delete(); avatarUrl = ""; sp.edit().remove("avatar").apply()
        withContext(Dispatchers.Main) { photoVersion++ }
        return AuthRes()
    }
}
