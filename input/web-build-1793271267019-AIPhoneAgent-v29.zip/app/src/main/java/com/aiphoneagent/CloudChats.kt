package com.aiphoneagent

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

/**
 * Conversations on the server (Supabase table public.chats + private storage bucket "chat-files").
 * The phone stays the working copy (fast, works offline); every change is queued and uploaded in the background,
 * and a sync on sign-in / app start pulls conversations made on other phones. Last write wins (by "updated").
 */
object CloudChats {
    private lateinit var sp: SharedPreferences
    private lateinit var appCtx: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Mutex()
    private var pushJob: Job? = null
    /** The upload started at sign-out (the phone copy of the account's chats is deleted only after it). */
    var lastFlush: Job? = null
        private set

    var syncing by mutableStateOf(false)
        private set
    var lastError by mutableStateOf("")
        private set
    var lastSyncAt by mutableStateOf(0L)
        private set

    private const val MAX_FILE = 20L * 1024 * 1024

    fun init(c: Context) {
        if (::sp.isInitialized) return
        appCtx = c.applicationContext
        sp = appCtx.getSharedPreferences("cloudchats", Context.MODE_PRIVATE)
    }

    private val base get() = BuildConfig.SUPABASE_URL.trimEnd('/')
    private fun active() = ::sp.isInitialized && UserProfile.configured && UserProfile.signedIn && UserProfile.uid.isNotBlank()

    // ---------------------------------------------------------------- queues (per account)

    private fun getSet(k: String): MutableSet<String> = HashSet(sp.getStringSet(k, emptySet()) ?: emptySet())
    private fun putSet(k: String, v: Set<String>) { sp.edit().putStringSet(k, HashSet(v)).apply() }
    @Synchronized private fun addTo(k: String, id: String) { putSet(k, getSet(k) + id) }
    @Synchronized private fun removeFrom(k: String, id: String) { putSet(k, getSet(k) - id) }

    /** Local path -> storage path of attachments already uploaded (so a file is uploaded once). */
    private fun upMap(): JSONObject = runCatching { JSONObject(sp.getString("upmap", "{}").orEmpty()) }.getOrDefault(JSONObject())
    @Synchronized private fun putUp(local: String, remote: String) { val m = upMap(); m.put(local, remote); sp.edit().putString("upmap", m.toString()).apply() }

    /** The conversation changed on this phone: upload it soon. */
    fun markDirty(id: String) {
        if (!active()) return
        val u = UserProfile.uid
        removeFrom("gone_$u", id); addTo("dirty_$u", id)
        schedule()
    }

    /** The conversation was deleted on this phone: delete it on the server too. */
    fun markDeleted(id: String) {
        if (!active()) return
        val u = UserProfile.uid
        removeFrom("dirty_$u", id); addTo("gone_$u", id)
        schedule()
    }

    private fun schedule() {
        pushJob?.cancel()
        pushJob = scope.launch { delay(2500); runCatching { flush(UserProfile.uid, null) } }
    }

    /** Last upload before signing out, with the token of the account that is leaving. */
    fun flushBeforeSignOut(uid: String, token: String) {
        if (!::sp.isInitialized || uid.isBlank() || token.isBlank()) return
        pushJob?.cancel()
        val snapshot = ChatStore.loadIndex().associateBy { it.id }      // the list is emptied right after this; keep its entries for the upload
        lastFlush = scope.launch { runCatching { flush(uid, token, snapshot) } }
    }

    // ---------------------------------------------------------------- upload

    private suspend fun tok(override: String?): String? = override ?: UserProfile.token()

    private fun sha(s: String) = MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }.take(16)
    private fun safeName(n: String) = n.replace(Regex("[^A-Za-z0-9._-]"), "_").takeLast(60).ifBlank { "file" }

    /** Uploads every queued conversation and deletion. Returns false if something is still pending (offline etc.). */
    suspend fun flush(uid: String, tokenOverride: String?, metas: Map<String, ChatMeta>? = null): Boolean = lock.withLock {
        if (uid.isBlank()) return@withLock true
        val t = tok(tokenOverride) ?: return@withLock false
        var ok = true
        for (id in getSet("gone_$uid")) {
            val r = UserProfile.call("DELETE", "/rest/v1/chats?id=eq.${enc(id)}", auth = t)
            if (r.code in 200..299 || r.code == 404) removeFrom("gone_$uid", id) else ok = false
        }
        for (id in getSet("dirty_$uid")) {
            val done = try { upload(uid, id, t, metas) } catch (e: CancellationException) { throw e } catch (e: Exception) { lastError = e.message.orEmpty().take(120); false }
            if (done) removeFrom("dirty_$uid", id) else ok = false
        }
        if (ok) lastError = ""
        ok
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private suspend fun upload(uid: String, id: String, t: String, metas: Map<String, ChatMeta>?): Boolean {
        val arr = withContext(Dispatchers.IO) { ChatStore.load(id) } ?: return true          // nothing on the phone any more
        val meta = metas?.get(id) ?: ChatStore.loadIndex().firstOrNull { it.id == id } ?: return true
        if (meta.owner.isNotBlank() && meta.owner != uid) return true                           // belongs to another account
        val ups = upMap()
        for (i in 0 until arr.length()) {
            val at = arr.optJSONObject(i)?.optJSONArray("at") ?: continue
            for (j in 0 until at.length()) {
                val a = at.optJSONObject(j) ?: continue
                if (a.optString("r").isNotBlank()) continue
                val path = a.optString("p")
                val known = ups.optString(path)
                if (known.isNotBlank()) { a.put("r", known); continue }
                val f = File(path)
                if (!f.isFile || f.length() > MAX_FILE) continue                                // too big / gone: the text is still saved
                val remote = "$uid/$id/${sha(path)}-${safeName(a.optString("n"))}"
                val bytes = withContext(Dispatchers.IO) { f.readBytes() }
                val r = UserProfile.call("POST", "/storage/v1/object/chat-files/$remote", raw = bytes,
                    contentType = a.optString("m").ifBlank { "application/octet-stream" }, auth = t, headers = mapOf("x-upsert" to "true"))
                if (r.code !in 200..299) { lastError = "رفع ملف (${r.code})"; return false }
                a.put("r", remote); putUp(path, remote)
            }
        }
        val row = JSONObject().put("id", id).put("title", meta.title).put("auto", meta.auto).put("messages", arr).put("updated_at", meta.updated)
        val r = UserProfile.call("POST", "/rest/v1/chats", JSONArray().put(row), auth = t,
            headers = mapOf("Prefer" to "resolution=merge-duplicates,return=minimal"))
        if (r.code !in 200..299) { lastError = "حفظ المحادثة (${r.code}) ${r.body.take(80)}"; return false }
        return true
    }

    // ---------------------------------------------------------------- download

    class SyncResult(val changed: List<ChatMeta>, val removed: List<String>)

    /**
     * Full sync for the signed-in account: upload what is pending, then bring the phone in line with the server.
     * Returns null when it could not reach the server.
     */
    suspend fun sync(uid: String): SyncResult? {
        if (!active() || uid.isBlank()) return null
        syncing = true
        try {
            flush(uid, null)
            val t = UserProfile.token() ?: return null
            val r = UserProfile.call("GET", "/rest/v1/chats?select=id,title,auto,updated_at&order=updated_at.desc&limit=1000", auth = t)
            if (r.code !in 200..299) { lastError = if (r.code == -1) "ما في إنترنت" else "مزامنة (${r.code}) ${r.body.take(80)}"; return null }
            val remote = JSONArray(r.body)
            val local = ChatStore.loadIndex().associateBy { it.id }
            val dirty = getSet("dirty_$uid"); val gone = getSet("gone_$uid")
            val changed = ArrayList<ChatMeta>()
            val seen = HashSet<String>()
            for (i in 0 until remote.length()) {
                val o = remote.getJSONObject(i)
                val id = o.getString("id"); seen += id
                if (id in gone) continue
                val upd = o.optLong("updated_at")
                val l = local[id]
                if (l != null && (l.updated >= upd || id in dirty)) continue                    // the phone copy is as new or newer
                val m = UserProfile.call("GET", "/rest/v1/chats?id=eq.${enc(id)}&select=messages", auth = t)
                if (m.code !in 200..299) continue
                val arr = JSONArray(m.body).optJSONObject(0)?.optJSONArray("messages") ?: continue
                fetchFiles(id, arr, t)
                withContext(Dispatchers.IO) { ChatStore.save(id, arr) }
                changed += ChatMeta(id, o.optString("title").ifBlank { "محادثة" }, upd, o.optBoolean("auto", false), uid)
            }
            // Conversations of this account deleted on another phone.
            val removed = if (remote.length() >= 1000) emptyList()                                // list was cut: never guess deletions
                else local.values.filter { it.owner == uid && it.id !in seen && it.id !in getSet("dirty_$uid") }.map { it.id }
            lastSyncAt = System.currentTimeMillis(); lastError = ""
            return SyncResult(changed, removed)
        } catch (e: CancellationException) { throw e
        } catch (e: Exception) { lastError = e.message.orEmpty().take(120); return null
        } finally { syncing = false }
    }

    /** Downloads the attachments of a conversation coming from the server and points the messages at the local copies. */
    private suspend fun fetchFiles(id: String, arr: JSONArray, t: String) = withContext(Dispatchers.IO) {
        val dir = File(appCtx.filesDir, "media/cloud/$id")
        for (i in 0 until arr.length()) {
            val at = arr.optJSONObject(i)?.optJSONArray("at") ?: continue
            for (j in 0 until at.length()) {
                val a = at.optJSONObject(j) ?: continue
                val remote = a.optString("r").takeIf { it.isNotBlank() } ?: continue
                if (File(a.optString("p")).isFile) continue
                val f = File(dir, remote.substringAfterLast('/'))
                if (!f.isFile) runCatching {
                    dir.mkdirs()
                    val c = URL("$base/storage/v1/object/authenticated/chat-files/$remote").openConnection() as HttpURLConnection
                    c.connectTimeout = 12_000; c.readTimeout = 60_000
                    c.setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY.trim())
                    c.setRequestProperty("Authorization", "Bearer $t")
                    if (c.responseCode == 200) c.inputStream.use { inp -> f.outputStream().use { inp.copyTo(it) } }
                    c.disconnect()
                }
                if (f.isFile) { a.put("p", f.absolutePath); putUp(f.absolutePath, remote) }
            }
        }
    }
}
