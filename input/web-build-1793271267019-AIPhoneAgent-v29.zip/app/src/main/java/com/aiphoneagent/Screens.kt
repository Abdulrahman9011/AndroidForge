package com.aiphoneagent

import android.app.Activity
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDirection
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ======================================================================= drag the sheet down to close it

/** Makes a bottom sheet follow the finger downwards; releasing past ~110 dp (or a quick fling) closes it, otherwise it springs back. */
@Composable
internal fun Modifier.swipeDown(onDismiss: () -> Unit): Modifier {
    val off = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val th = with(LocalDensity.current) { 110.dp.toPx() }
    val cb by rememberUpdatedState(onDismiss)
    return this.offset { IntOffset(0, off.value.roundToInt()) }.pointerInput(Unit) {
        var last = 0f
        detectVerticalDragGestures(
            onDragStart = { last = 0f },
            onDragEnd = { scope.launch { if (off.value > th || last > 18f) cb() else off.animateTo(0f, tween(180)) } },
            onDragCancel = { scope.launch { off.animateTo(0f, tween(180)) } },
            onVerticalDrag = { c, dy -> c.consume(); last = dy; scope.launch { off.snapTo((off.value + dy).coerceAtLeast(0f)) } }
        )
    }
}

// ======================================================================= message text with copyable code blocks

private class Seg(val code: Boolean, val lang: String, val text: String)

private val FENCE = Regex("```([\\w+#.\\-]*)[ \\t]*\\n?([\\s\\S]*?)(```|$)")

private fun segments(t: String): List<Seg> {
    val out = ArrayList<Seg>()
    var pos = 0
    for (m in FENCE.findAll(t)) {
        if (m.range.first > pos) t.substring(pos, m.range.first).trim('\n').takeIf { it.isNotBlank() }?.let { out += Seg(false, "", it) }
        out += Seg(true, m.groupValues[1], m.groupValues[2].trimEnd('\n'))
        pos = m.range.last + 1
    }
    if (pos < t.length) t.substring(pos).trim('\n').takeIf { it.isNotBlank() }?.let { out += Seg(false, "", it) }
    return out
}

internal fun hasCode(t: String) = t.contains("```")

/** A message body: normal text, and every ``` block as its own box with a copy button (works for any text, not only Python). */
@Composable
internal fun RichText(text: String, color: Color) {
    if (!hasCode(text)) { Text(text, color = color, fontSize = 15.sp, lineHeight = 22.sp); return }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        segments(text).forEach { s ->
            if (s.code) CodeBlock(s.lang, s.text) else Text(s.text, color = color, fontSize = 15.sp, lineHeight = 22.sp)
        }
    }
}

@Composable
private fun CodeBlock(lang: String, body: String) {
    val ctx = LocalContext.current
    var copied by remember(body.length / 40) { mutableStateOf(false) }
    LaunchedEffect(copied) { if (copied) { delay(1600); copied = false } }
    val shape = RoundedCornerShape(14.dp)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.fillMaxWidth().clip(shape).background(Color(0xFF0D0D0F)).border(1.dp, Color.White.copy(alpha = 0.10f), shape)) {
            Row(Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.06f)).padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(lang.ifBlank { "code" }, Modifier.weight(1f), color = InkDim, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Row(
                    Modifier.clickable { ctx.copyText(body); copied = true }.padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    LineIcon(16.dp) { s, sw -> icCopy(if (copied) Ok else InkDim, s, sw) }
                    Text(if (copied) "Copied" else "Copy", color = if (copied) Ok else InkDim, fontSize = 12.sp)
                }
            }
            Box(Modifier.horizontalScroll(rememberScrollState()).padding(12.dp)) {
                SelectionContainer { Text(body, color = Color(0xFFDAD7CF), fontSize = 12.5.sp, lineHeight = 18.sp, fontFamily = FontFamily.Monospace) }
            }
        }
    }
}

// ======================================================================= avatar with the user's photo

@Composable
internal fun UserAvatar(d: Dp) {
    val ctx = LocalContext.current
    val ver = UserProfile.photoVersion
    val mail = UserProfile.email
    val bmp by produceState<ImageBitmap?>(null, ver, mail) {
        value = withContext(Dispatchers.IO) { UserProfile.photo(ctx)?.let { f -> BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap() } }
    }
    val b = bmp
    if (b != null) Image(b, null, Modifier.size(d).clip(CircleShape), contentScale = ContentScale.Crop) else Avatar(d)
}

// ======================================================================= small shared pieces

@Composable
internal fun BackArrow(onClick: () -> Unit) {
    Box(Modifier.size(42.dp).glass(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        // RTL app: the "back" arrow points to the right.
        LineIcon(20.dp) { s, sw ->
            drawLine(Ink, Offset(s * 0.2f, s * 0.5f), Offset(s * 0.8f, s * 0.5f), sw, StrokeCap.Round)
            drawLine(Ink, Offset(s * 0.8f, s * 0.5f), Offset(s * 0.55f, s * 0.25f), sw, StrokeCap.Round)
            drawLine(Ink, Offset(s * 0.8f, s * 0.5f), Offset(s * 0.55f, s * 0.75f), sw, StrokeCap.Round)
        }
    }
}

@Composable
internal fun AppSwitch(checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Switch(checked, onChange, enabled = enabled, colors = SwitchDefaults.colors(
        checkedThumbColor = Ink, checkedTrackColor = Color.White.copy(alpha = 0.28f), checkedBorderColor = Color.Transparent,
        uncheckedThumbColor = InkDim, uncheckedTrackColor = Color.White.copy(alpha = 0.08f), uncheckedBorderColor = Color.White.copy(alpha = 0.2f)))
}

@Composable
private fun SettingSwitch(title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Ink, fontSize = 14.sp, lineHeight = 20.sp)
            if (sub != null) Text(sub, color = InkDim, fontSize = 11.5.sp, lineHeight = 16.sp)
        }
        AppSwitch(checked, onChange = onChange)
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = InkDim, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 6.dp))
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp), 0.8f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
    }
}

@Composable
private fun Hint(t: String, color: Color = InkDim) = Text(t, color = color, fontSize = 11.5.sp, lineHeight = 16.sp)

// ======================================================================= SETTINGS (full page)

@Composable
internal fun SettingsScreen(onClose: () -> Unit, onVoicePicker: () -> Unit, onProfile: () -> Unit) {
    val ctx = LocalContext.current
    val c = AgentController
    @Suppress("UNUSED_VARIABLE") val rv = QuotaTracker.version
    @Suppress("UNUSED_VARIABLE") val tv = TokenBudget.version
    @Suppress("UNUSED_VARIABLE") val ev = Extras.ver

    var aiUrl by remember { mutableStateOf(c.aiBaseUrl) }
    var aiModel by remember { mutableStateOf(c.aiModel) }
    var aiKey by remember { mutableStateOf(c.apiKeys) }
    var useAi by remember { mutableStateOf(c.useAi) }
    var useVision by remember { mutableStateOf(c.useVision) }
    var visionModel by remember { mutableStateOf(c.visionModel) }
    var gemKey by remember { mutableStateOf(c.geminiKey) }
    var harsh by remember { mutableStateOf(c.harshMode) }
    var adult by remember { mutableStateOf(c.adultMode) }
    var qafOn by remember { mutableStateOf(Extras.connectorOn("qaf")) }
    var qafUrl by remember { mutableStateOf(Extras.qafUrl) }
    var qafKey by remember { mutableStateOf(Extras.qafKey) }
    var vAlways by remember { mutableStateOf(Voice.always) }
    var vHands by remember { mutableStateOf(Voice.handsFree) }
    var sttLang by remember { mutableStateOf(Voice.sttLang) }
    var ttsUrl by remember { mutableStateOf(Voice.ttsUrl) }
    var ttsModel by remember { mutableStateOf(Voice.ttsModel) }
    val scope = rememberCoroutineScope()
    var modelMsg by remember { mutableStateOf(if (LlmPlanner.isReady()) "مثبّت (${LlmPlanner.sizeMb()} MB)" else "غير مثبّت") }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { modelMsg = "جارٍ النسخ…"; scope.launch { modelMsg = if (LlmPlanner.importModel(uri)) "مثبّت (${LlmPlanner.sizeMb()} MB)" else "فشل النسخ" } }
    }
    var cookieMsg by remember { mutableStateOf(if (MediaDownloader.hasCookies(ctx)) "مستورد" else "غير موجود") }
    val cookiePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) cookieMsg = if (MediaDownloader.importCookies(ctx, uri)) "مستورد" else "فشل النسخ"
    }

    fun save() {
        c.aiBaseUrl = aiUrl; c.aiModel = aiModel; c.apiKeys = aiKey; c.useAi = useAi; c.useVision = useVision; c.visionModel = visionModel; c.geminiKey = gemKey
        c.harshMode = harsh; c.adultMode = adult
        Extras.setConnector("qaf", qafOn)
        if (qafUrl.isNotBlank() && qafUrl != Extras.qafUrl) Extras.qafUrl = qafUrl
        if (qafKey.isNotBlank() && qafKey != Extras.qafKey) Extras.qafKey = qafKey
        Voice.always = vAlways; Voice.applyHandsFree(vHands)
        Voice.ttsUrl = ttsUrl; Voice.ttsModel = ttsModel; Voice.sttLang = sttLang
    }
    val close = { save(); onClose() }
    BackHandler(true) { close() }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF131315)).pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding().navigationBarsPadding().imePadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BackArrow(close)
            Text("الإعدادات", Modifier.weight(1f), color = Ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text("يُحفظ تلقائياً", color = InkDim, fontSize = 11.sp)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {

            // ---- account
            Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp), 0.8f).clickable { save(); onProfile() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                UserAvatar(52.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(UserProfile.name, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(UserProfile.subtitle, color = InkDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(if (UserProfile.signedIn) "الحساب" else "تسجيل الدخول", color = Ok, fontSize = 13.sp)
            }

            // ---- chat style
            Section("أسلوب الدردشة") {
                SettingSwitch("الرد القاسي والشتم", "مطفأ افتراضياً. وهو مطفأ: ما بشتم ولا برد بقسوة أبداً. إذا فعّلته بيرد بوقاحة وتريقة (بدون المساس بالدين أو العائلة)، والأسئلة الدينية تبقى محترمة دائماً.", harsh) { harsh = it }
                SettingSwitch("وضع البالغين (+18)", "أنا عمري 18 أو أكتر، فعّل الكلام الصريح بالدردشة (نماذج Llama على Groq فقط، وبحدود صارمة).", adult) { adult = it }
            }

            // ---- religious questions
            Section("الأسئلة الدينية (Qaf AI)") {
                SettingSwitch("أجب الأسئلة الدينية من Qaf", "أي سؤال عن حكم أو حديث أو تفسير أو دعاء يُرسل لـ Qaf ويظهر جوابه كما هو بدون تدخل من النموذج.", qafOn) { qafOn = it }
                GlassField("عنوان QafAI", qafUrl, { qafUrl = it })
                GlassField("مفتاح Qaf", qafKey, { qafKey = it }, secret = true)
                Hint("العنوان: https://qafai.net والمفتاح من qafai.net > الإعدادات > مفاتيح API (يبدأ بـ qaf_). المفتاح يُرسل لهذا الموقع فقط. القالب العام لـ Qaf ليس خاصاً بالدين، لذلك التطبيق يرسل معه تعليمات شرعية، ومع ذلك راجع عالماً في الأمور المهمة.")
            }

            // ---- AI
            Section("الذكاء الاصطناعي") {
                SettingSwitch("استخدم الذكاء الاصطناعي دائماً", "وإلا يُستخدم فقط للأوامر التي لا يفهمها التطبيق بنفسه.", useAi) { useAi = it }
                GlassField("عنوان الخدمة (متوافق مع OpenAI)", aiUrl, { aiUrl = it })
                GlassField("النموذج الذكي (يخطط ويحل المواقف الصعبة)", aiModel, { aiModel = it })
                GlassField("مفاتيح API (مفتاح بكل سطر)", aiKey, { aiKey = it }, secret = true, lines = 4)
                Hint("الحصة المجانية في Groq محسوبة لكل حساب لا لكل مفتاح. المفاتيح تتبدّل تلقائياً عند الوصول للحد.")
                GlassField("مفتاح Gemini المجاني (احتياطي)", gemKey, { gemKey = it }, secret = true)
                Hint("من aistudio.google.com/apikey. يشتغل فوراً لما تخلص حصة Groq.")
                SettingSwitch("الوضع السريع", "نموذج سريع يشوف الصور لكل خطوة، والنموذج الذكي يخطط ويتدخل لما يتعثر.", useVision) { useVision = it }
                if (useVision) GlassField("النموذج السريع", visionModel, { visionModel = it })
            }

            // ---- voice
            Section("الصوت") {
                SettingSwitch("رد صوتي دائماً", "وإلا فقط لما تحكي معه.", vAlways) { vAlways = it }
                SettingSwitch("وضع المحادثة", "يستمع تلقائياً بعد كل رد والتطبيق مفتوح.", vHands) { vHands = it }
                GlassButton("اختيار الصوت وتجربته", Modifier.fillMaxWidth()) { save(); onVoicePicker() }
                Hint("الاستماع عبر Whisper يفهم أغلب لغات العالم واللهجات العربية ويكتشف اللغة لحاله.")
                GlassField("لغة التعرف الاحتياطي", sttLang, { sttLang = it })
                GlassField("عنوان الصوت (TTS)", ttsUrl, { ttsUrl = it })
                GlassField("نموذج الصوت", ttsModel, { ttsModel = it })
                if (Voice.ttsStatus.isNotBlank()) Hint("آخر مشكلة بالصوت الطبيعي: ${Voice.ttsStatus}", Danger)
            }

            // ---- real usage
            Section("الرصيد والاستهلاك (أرقام حقيقية)") {
                Text("المستهلك اليوم على هذا الهاتف: ${QuotaTracker.fmt(TokenBudget.used())} توكن", color = Ink, fontSize = 14.sp)
                Hint("عدّاد دقيق: يُجمع من حقل الاستهلاك الذي يرسله المزوّد مع كل رد. لا يوجد أي رقم تقديري.")
                QuotaTracker.requestsLeftToday()?.let { Text("الطلبات المتبقية اليوم: $it", color = Ink, fontSize = 14.sp); Hint("قيمة فعلية من ترويسات Groq لآخر نموذج استُخدم، مجموعة على كل المفاتيح.") }
                val daily = QuotaTracker.dailyAll()
                daily.forEach { d ->
                    Text("${d.model.substringAfterLast('/')} · مفتاح …${d.keyTail}: المتبقي اليومي ${QuotaTracker.fmt((d.limit - d.used).coerceAtLeast(0))} من ${QuotaTracker.fmt(d.limit)} توكن", color = Danger, fontSize = 12.sp, lineHeight = 17.sp)
                }
                val qs = QuotaTracker.all()
                if (qs.isEmpty() && daily.isEmpty()) Hint("تظهر الأرقام بعد أول طلب للذكاء الاصطناعي.")
                qs.forEach { q ->
                    Text("${q.model.substringAfterLast('/')} · مفتاح …${q.keyTail}: ${QuotaTracker.fmt(q.remTok)} / ${QuotaTracker.fmt(q.limTok)} توكن بالدقيقة" +
                        (if (q.remReq >= 0) " · ${q.remReq} طلب باليوم" else "") + (if (q.resetTok.isNotBlank()) " · يتجدد خلال ${q.resetTok}" else ""),
                        color = if (q.remTok < 1500) Danger else InkDim, fontSize = 12.sp, lineHeight = 17.sp)
                }
                Hint("Groq لا يرسل رصيد التوكنز اليومي الكلي إلا عند الوصول للحد (يظهر بالأحمر أعلاه)، لذلك التطبيق لا يخمّنه. Gemini لا يرسل هذه المعلومات أبداً.")
            }

            // ---- local model & downloads
            Section("النموذج المحلي والتنزيلات") {
                Text("النموذج المحلي (دون إنترنت): $modelMsg", color = Ink, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("اختيار ملف .task") { modelPicker.launch(arrayOf("*/*")) }
                    GlassButton("حذف النموذج") { LlmPlanner.deleteModel(); modelMsg = "غير مثبّت" }
                }
                Text("ملف cookies.txt للتنزيل: $cookieMsg", color = Ink, fontSize = 13.sp)
                Hint("يلزم فقط لمحتوى إنستغرام/فيسبوك الذي يطلب تسجيل دخول.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("استيراد cookies.txt") { cookiePicker.launch(arrayOf("*/*")) }
                    GlassButton("حذفه") { MediaDownloader.deleteCookies(ctx); cookieMsg = "غير موجود" }
                }
            }

            // ---- data
            Section("البيانات") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("مسح المحادثة الحالية") { c.clearHistory() }
                    GlassButton("حذف المفاتيح", tint = Danger) { aiKey = ""; c.apiKeys = ""; gemKey = ""; c.geminiKey = ""; c.backendUrl = ""; c.backendToken = "" }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ======================================================================= AUTH (sign in / create account, on the server)

/** Slow-moving light behind the sign-in page: three soft glows drifting on their own paths + faint flowing lines. */
@Composable
private fun AuthBackdrop(modifier: Modifier = Modifier) {
    val t by rememberInfiniteTransition(label = "backdrop").animateFloat(
        0f, (2 * PI).toFloat(), infiniteRepeatable(tween(20000, easing = LinearEasing)), label = "backdropT")
    Canvas(modifier) {
        drawRect(Color(0xFF0D0D10))
        val w = size.width; val h = size.height
        fun glow(cx: Float, cy: Float, r: Float, c: Color) =
            drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(cx, cy), radius = r), r, Offset(cx, cy))
        glow(w * (0.22f + 0.16f * cos(t)), h * (0.18f + 0.07f * sin(2f * t)), w * 0.85f, Color(0xFF7C8CFF).copy(alpha = 0.20f))
        glow(w * (0.85f + 0.12f * sin(t)), h * (0.48f + 0.09f * cos(t)), w * 0.75f, Color(0xFF4FD6B8).copy(alpha = 0.13f))
        glow(w * (0.35f + 0.22f * sin(t + 2f)), h * (0.92f + 0.05f * cos(2f * t)), w * 0.9f, Color(0xFFB07CFF).copy(alpha = 0.14f))
        for (i in 0 until 7) {
            val p = Path()
            val baseY = h * (0.08f + i * 0.14f)
            var x = 0f
            p.moveTo(0f, baseY)
            while (x <= w) {
                val y = baseY + sin(x / w * 7.5f + t * (1f + i * 0.18f) + i) * h * 0.018f
                p.lineTo(x, y); x += w / 48f
            }
            drawPath(p, Color.White.copy(alpha = 0.03f), style = Stroke(1.dp.toPx()))
        }
    }
}

/** Fade + rise for staggered entrance: [p] is this item's progress 0..1. */
private fun Modifier.rise(p: Float): Modifier = this.graphicsLayer { alpha = p; translationY = (1f - p) * 36f }

@Composable
private fun AuthField(label: String, value: String, onChange: (String) -> Unit, secret: Boolean = false, ltr: Boolean = true, kb: KeyboardType = KeyboardType.Text) {
    var focused by remember { mutableStateOf(false) }
    var visible by remember { mutableStateOf(false) }
    val glow by animateFloatAsState(if (focused) 1f else 0f, tween(220), label = "fieldGlow")
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color.White.copy(alpha = 0.045f + 0.035f * glow))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.10f + 0.45f * glow), Color.White.copy(alpha = 0.04f + 0.12f * glow))), shape)
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(label, color = if (focused) Ink else InkDim, fontSize = 11.5.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(
                value, onChange,
                Modifier.weight(1f).padding(top = 3.dp, bottom = 2.dp).onFocusChanged { focused = it.isFocused },
                singleLine = true,
                textStyle = TextStyle(color = Ink, fontSize = 16.sp, textDirection = if (ltr) TextDirection.Ltr else TextDirection.Content),
                cursorBrush = SolidColor(Ink),
                visualTransformation = if (secret && !visible) PasswordVisualTransformation() else VisualTransformation.None,
                keyboardOptions = KeyboardOptions(keyboardType = if (secret) KeyboardType.Password else kb)
            )
            if (secret) Text(if (visible) "إخفاء" else "إظهار", color = InkDim, fontSize = 12.sp,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { visible = !visible }.padding(horizontal = 8.dp, vertical = 4.dp))
        }
    }
}

@Composable
private fun LoadingDots(c: Color) {
    val ph by rememberInfiniteTransition(label = "dots").animateFloat(0f, 3f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "dotsP")
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        for (i in 0 until 3) {
            val d = ((ph - i + 3f) % 3f)
            val up = if (d < 1f) sin(d * PI.toFloat()) else 0f
            Box(Modifier.size(7.dp).graphicsLayer { translationY = -up * 10f; alpha = 0.45f + 0.55f * up }.clip(CircleShape).background(c))
        }
    }
}

/** Light pill button with a slow sheen passing over it and a press "squish". */
@Composable
private fun AuthPrimaryButton(label: String, busy: Boolean, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.965f else 1f, tween(110), label = "primScale")
    val sheen by rememberInfiniteTransition(label = "sheen").animateFloat(-0.6f, 1.8f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "sheenX")
    Box(
        Modifier.fillMaxWidth().height(56.dp).graphicsLayer { scaleX = sc; scaleY = sc }.clip(RoundedCornerShape(28.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFFF4F2EC), Color(0xFFD8D5CD))))
            .drawWithContent {
                drawContent()
                val x = size.width * sheen
                drawRect(Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent),
                    start = Offset(x - size.width * 0.25f, 0f), end = Offset(x, size.height)))
            }
            .clickable(interactionSource = src, indication = null, enabled = !busy, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (busy) LoadingDots(Color(0xFF16161A))
        else Text(label, color = Color(0xFF16161A), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Google's own "G" icon, shipped inside Google Play services (part of this app): never redrawn by hand. */
@Composable
private fun GoogleMark(size: Dp) {
    val ctx = LocalContext.current
    val id = remember {
        listOf("googleg_standard_color_18", "common_google_signin_btn_icon_light_normal_background")
            .map { ctx.resources.getIdentifier(it, "drawable", ctx.packageName) }.firstOrNull { it != 0 } ?: 0
    }
    if (id != 0) Image(painterResource(id), contentDescription = "Google", modifier = Modifier.size(size))
    else Box(Modifier.size(size).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
        Text("G", color = Color(0xFF3C4043), fontSize = (size.value * 0.62f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun GoogleButton(enabled: Boolean, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.965f else 1f, tween(110), label = "gScale")
    val shape = RoundedCornerShape(28.dp)
    Row(
        Modifier.fillMaxWidth().height(56.dp).graphicsLayer { scaleX = sc; scaleY = sc }.clip(shape)
            .background(Color(0xFF131314)).border(1.dp, Color(0xFF8E918F).copy(alpha = 0.55f), shape)
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        GoogleMark(20.dp)
        Spacer(Modifier.width(12.dp))
        Text("المتابعة باستخدام Google", color = Color(0xFFE3E3E3), fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun AuthTabs(tab: Int, onTab: (Int) -> Unit) {
    BoxWithConstraints(
        Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(24.dp)).background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Color.White.copy(alpha = 0.07f), RoundedCornerShape(24.dp)).padding(4.dp)
    ) {
        val half = maxWidth / 2
        val off by animateDpAsState(if (tab == 0) 0.dp else half, tween(320, easing = FastOutSlowInEasing), label = "tabOff")
        Box(Modifier.offset(x = off).width(half).fillMaxHeight().clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.15f)))
        Row(Modifier.fillMaxSize()) {
            listOf("تسجيل الدخول", "حساب جديد").forEachIndexed { i, t ->
                Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(20.dp)).clickable { onTab(i) }, contentAlignment = Alignment.Center) {
                    Text(t, color = if (tab == i) Ink else InkDim, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
internal fun AuthScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }
    var mail by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var needConfirm by remember { mutableStateOf(false) }
    var resetMode by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    fun finish() { UserProfile.authSeen = true; onDone() }
    fun show(r: AuthRes) { err = r.error?.ifBlank { null }; info = r.info?.ifBlank { null }; needConfirm = r.error?.contains("تأكد بريدك") == true }
    fun act(block: suspend () -> AuthRes, onOk: () -> Unit = {}) {
        if (busy) return
        busy = true; err = null; info = null
        scope.launch {
            val r = try { block() } catch (e: Exception) { AuthRes("صار خطأ: ${e.message?.take(100)}") }
            busy = false; show(r)
            if (r.ok) onOk()
        }
    }
    BackHandler(true) { finish() }

    // Entrance: everything rises in, one after the other.
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(1400, easing = FastOutSlowInEasing)) }
    fun step(i: Int): Float = ((appear.value - i * 0.08f) / 0.5f).coerceIn(0f, 1f)
    val breathe by rememberInfiniteTransition(label = "breathe").animateFloat(0.25f, 0.6f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breatheE")

    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }) {
        AuthBackdrop(Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding().verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Text("تخطي", color = InkDim, fontSize = 14.sp, modifier = Modifier.rise(step(0)).clip(RoundedCornerShape(12.dp)).clickable { finish() }.padding(horizontal = 12.dp, vertical = 6.dp))
            }
            AgentLogo(120.dp, energy = if (busy) 0.9f else breathe, appear = appear.value)
            Column(Modifier.rise(step(1)), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Crossfade(tab, label = "title") { t ->
                    Text(if (t == 0) "أهلاً من جديد" else "يلّا نبلّش", color = Ink, fontSize = 28.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
                Crossfade(tab, label = "sub") { t ->
                    Text(if (t == 0) "سجّل دخولك لترجع محادثاتك من أي هاتف" else "اعمل حسابك ومحادثاتك بتنحفظ معك وين ما رحت",
                        color = InkDim, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
            if (!UserProfile.configured) Text("⚠ السيرفر غير مضبوط بهالنسخة، فإنشاء الحساب وتسجيل الدخول ما رح يشتغلوا لحد ما تحط مفاتيح Supabase.",
                color = Danger, fontSize = 12.5.sp, lineHeight = 18.sp, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(2.dp))
            Box(Modifier.rise(step(2))) { AuthTabs(tab) { tab = it; err = null; info = null; needConfirm = false; resetMode = false } }

            Column(Modifier.fillMaxWidth().rise(step(3)).animateContentSize(tween(260)), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AnimatedVisibility(tab == 1, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                    AuthField("الاسم الكامل", name, { name = it }, ltr = false)
                }
                AuthField("البريد الإلكتروني", mail, { mail = it.trim() }, kb = KeyboardType.Email)
                if (!(tab == 0 && resetMode)) AuthField("كلمة المرور", pass, { pass = it }, secret = true)
                AnimatedVisibility(tab == 1, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        AuthField("تأكيد كلمة المرور", pass2, { pass2 = it }, secret = true)
                        Text("8 أحرف على الأقل، فيها أحرف وأرقام.", color = InkDim, fontSize = 11.5.sp, modifier = Modifier.padding(horizontal = 6.dp))
                    }
                }
                AnimatedVisibility(tab == 0 && resetMode, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("بعتنالك كود على الإيميل. اكتبه مع كلمة المرور الجديدة:", color = Ink, fontSize = 13.5.sp, lineHeight = 19.sp, modifier = Modifier.padding(horizontal = 4.dp))
                        AuthField("الكود من الإيميل", code, { code = it.filter { ch -> ch.isDigit() }.take(8) }, kb = KeyboardType.Number)
                        AuthField("كلمة المرور الجديدة", pass, { pass = it }, secret = true)
                        AuthField("تأكيد كلمة المرور الجديدة", pass2, { pass2 = it }, secret = true)
                    }
                }
            }

            AnimatedVisibility(err != null, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                Text(err.orEmpty(), color = Danger, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp)).background(Danger.copy(alpha = 0.10f)).padding(12.dp))
            }
            AnimatedVisibility(info != null, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                Text(info.orEmpty(), color = Ok, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp)).background(Ok.copy(alpha = 0.10f)).padding(12.dp))
            }

            Box(Modifier.rise(step(4))) {
                AuthPrimaryButton(
                    when { tab == 0 && resetMode -> "غيّر كلمة المرور وادخل"; tab == 0 -> "تسجيل الدخول"; else -> "إنشاء الحساب" }, busy
                ) {
                    when {
                        tab == 0 && resetMode -> act({ UserProfile.completeReset(ctx, mail, code, pass, pass2) }) { if (UserProfile.signedIn) finish() }
                        tab == 0 -> act({ UserProfile.login(ctx, mail, pass) }) { finish() }
                        else -> act({ UserProfile.register(ctx, name, mail, pass, pass2) }) {
                            if (UserProfile.signedIn) finish() else { tab = 0; pass2 = "" }   // e-mail confirmation pending: back to sign in
                        }
                    }
                }
            }
            if (tab == 0) Row(Modifier.fillMaxWidth().rise(step(4)), horizontalArrangement = Arrangement.SpaceBetween) {
                if (resetMode) Text("رجوع لتسجيل الدخول", color = InkDim, fontSize = 13.sp, modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { resetMode = false; code = "" }.padding(6.dp))
                else Text("نسيت كلمة المرور؟", color = InkDim, fontSize = 13.sp, modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable(enabled = !busy) {
                    act({ UserProfile.resetPassword(mail) }) { resetMode = true; pass = ""; pass2 = "" }
                }.padding(6.dp))
                if (needConfirm) Text("أعد إرسال رسالة التأكيد", color = Ok, fontSize = 13.sp, modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable(enabled = !busy) { act({ UserProfile.resendConfirmation(mail) }) }.padding(6.dp))
            }
            Row(Modifier.fillMaxWidth().rise(step(5)), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.16f)))))
                Text("أو", color = InkDim, fontSize = 12.sp)
                Box(Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(Color.White.copy(alpha = 0.16f), Color.Transparent))))
            }
            Box(Modifier.rise(step(5))) {
                GoogleButton(enabled = !busy) {
                    val a = ctx as? Activity
                    if (a != null) act({ UserProfile.googleSignIn(a) }) { if (UserProfile.signedIn) finish() }
                }
            }
            Text("المتابعة كضيف", color = InkDim, fontSize = 14.sp, modifier = Modifier.rise(step(6)).clip(RoundedCornerShape(12.dp)).clickable { finish() }.padding(horizontal = 14.dp, vertical = 10.dp))
            Text("حسابك ومحادثاتك محفوظين على السيرفر، وكلمة المرور ما بتنحفظ على الهاتف أبداً.",
                color = InkDim.copy(alpha = 0.7f), fontSize = 11.5.sp, lineHeight = 16.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().rise(step(6)))
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun AgentLogoSmall() {
    Box(Modifier.size(84.dp).glass(CircleShape, 1.6f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(34.dp)) {
            val u = size.width / 72f * 2f
            val cx = size.width / 2f; val cy = size.height / 2f
            val pts = listOf(-8.5f to -14f, -8.5f to 12f, -2.3f to 6.4f, 1.8f to 15.8f, 6.1f to 13.9f, 2f to 4.6f, 10.1f to 4.6f)
            val p = Path()
            pts.forEachIndexed { i, pt -> val x = cx + pt.first * u; val y = cy + pt.second * u; if (i == 0) p.moveTo(x, y) else p.lineTo(x, y) }
            p.close(); drawPath(p, Ink)
        }
    }
}

// ======================================================================= PROFILE

@Composable
internal fun ProfileScreen(onClose: () -> Unit, onSignedOut: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(UserProfile.name) }
    var old by remember { mutableStateOf("") }
    var new1 by remember { mutableStateOf("") }
    var new2 by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<Pair<Boolean, String>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { UserProfile.syncProfile(); name = UserProfile.name }
    fun act(okText: String, block: suspend () -> AuthRes, onOk: () -> Unit = {}) {
        if (busy) return
        busy = true; msg = null
        scope.launch {
            val r = try { block() } catch (e: Exception) { AuthRes("صار خطأ: ${e.message?.take(100)}") }
            busy = false
            msg = if (r.ok) true to (r.info ?: okText) else false to (r.error ?: "")
            if (r.ok) onOk()
        }
    }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) act("تم رفع الصورة على السيرفر", { UserProfile.setPhoto(ctx, uri) })
    }
    BackHandler(true) { onClose() }
    Column(
        Modifier.fillMaxSize().background(Color(0xFF131315)).pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding().navigationBarsPadding().imePadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BackArrow(onClose)
            Text("حسابي", Modifier.weight(1f), color = Ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            if (busy || UserProfile.syncing) Text("مزامنة…", color = InkDim, fontSize = 11.sp)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.clickable(enabled = !busy) { photoPicker.launch("image/*") }) { UserAvatar(112.dp) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("تغيير الصورة", enabled = !busy, strong = true) { photoPicker.launch("image/*") }
                if (UserProfile.photo(ctx) != null) GlassButton("إزالة الصورة", enabled = !busy, tint = Danger) { act("تمت إزالة الصورة", { UserProfile.removePhoto(ctx) }) }
            }
            Text(UserProfile.email, color = InkDim, fontSize = 13.sp)
            Text(if (UserProfile.provider == "google") "حساب Google · محفوظ على السيرفر" else "حساب بريد إلكتروني · محفوظ على السيرفر", color = InkDim, fontSize = 12.sp)
            msg?.let { (ok, t) -> if (t.isNotBlank()) Text(t, color = if (ok) Ok else Danger, fontSize = 13.sp, textAlign = TextAlign.Center) }

            Section("الاسم") {
                GlassField("الاسم الظاهر", name, { name = it })
                GlassButton("حفظ الاسم", Modifier.fillMaxWidth(), enabled = !busy, strong = true) { act("تم حفظ الاسم", { UserProfile.updateName(ctx, name) }) }
            }
            if (UserProfile.provider != "google") Section("تغيير كلمة المرور") {
                GlassField("كلمة المرور الحالية", old, { old = it }, secret = true)
                GlassField("كلمة المرور الجديدة", new1, { new1 = it }, secret = true)
                GlassField("تأكيد كلمة المرور الجديدة", new2, { new2 = it }, secret = true)
                GlassButton("تغيير كلمة المرور", Modifier.fillMaxWidth(), enabled = !busy, strong = true) {
                    act("تم تغيير كلمة المرور", { UserProfile.changePassword(ctx, old, new1, new2) }) { old = ""; new1 = ""; new2 = "" }
                }
            } else Section("كلمة المرور") { Hint("حسابك مرتبط بـ Google، وكلمة المرور تُدار من حساب Google.") }
            GlassButton("تسجيل الخروج", Modifier.fillMaxWidth(), tint = Danger) { UserProfile.signOut(ctx); onSignedOut() }
            Text("حذف الحساب نهائياً", color = Danger.copy(alpha = 0.8f), fontSize = 13.sp, modifier = Modifier.clickable(enabled = !busy) { confirmDelete = true }.padding(8.dp))
            Spacer(Modifier.height(24.dp))
        }
    }
    if (confirmDelete) androidx.compose.ui.window.Dialog(onDismissRequest = { confirmDelete = false }) {
        Column(Modifier.fillMaxWidth().sheet(RoundedCornerShape(26.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("حذف الحساب", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text("رح ينحذف حسابك واسمك وصورتك من السيرفر نهائياً، وما في رجعة.", color = Ink.copy(alpha = 0.9f), fontSize = 14.sp, lineHeight = 21.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("احذف", Modifier.weight(1f), enabled = !busy, tint = Danger) {
                    act("انحذف الحساب", { UserProfile.deleteAccount(ctx) }) { confirmDelete = false; onSignedOut() }
                }
                GlassButton("إلغاء", Modifier.weight(1f), strong = true) { confirmDelete = false }
            }
        }
    }
}

// ======================================================================= the "+" sheet: tiles + projects / permission / connectors / skills / memory

private fun DrawScope.icFolder(c: Color, s: Float, sw: Float) {
    val p = Path().apply {
        moveTo(s * 0.1f, s * 0.28f); lineTo(s * 0.4f, s * 0.28f); lineTo(s * 0.5f, s * 0.4f); lineTo(s * 0.9f, s * 0.4f)
        lineTo(s * 0.9f, s * 0.82f); lineTo(s * 0.1f, s * 0.82f); close()
    }
    drawPath(p, c, style = strokeOf(sw))
}
private fun DrawScope.icShield(c: Color, s: Float, sw: Float) {
    val p = Path().apply {
        moveTo(s * 0.5f, s * 0.1f); lineTo(s * 0.84f, s * 0.24f); lineTo(s * 0.84f, s * 0.52f)
        cubicTo(s * 0.84f, s * 0.72f, s * 0.68f, s * 0.86f, s * 0.5f, s * 0.92f)
        cubicTo(s * 0.32f, s * 0.86f, s * 0.16f, s * 0.72f, s * 0.16f, s * 0.52f); lineTo(s * 0.16f, s * 0.24f); close()
    }
    drawPath(p, c, style = strokeOf(sw))
    drawLine(c, Offset(s * 0.36f, s * 0.52f), Offset(s * 0.47f, s * 0.64f), sw, StrokeCap.Round)
    drawLine(c, Offset(s * 0.47f, s * 0.64f), Offset(s * 0.66f, s * 0.4f), sw, StrokeCap.Round)
}
private fun DrawScope.icBlocks(c: Color, s: Float, sw: Float) {
    val st = strokeOf(sw)
    drawRoundRect(c, Offset(s * 0.12f, s * 0.46f), Size(s * 0.3f, s * 0.3f), CornerRadius(s * 0.05f), style = st)
    drawRoundRect(c, Offset(s * 0.12f, s * 0.12f), Size(s * 0.3f, s * 0.3f), CornerRadius(s * 0.05f), style = st)
    drawRoundRect(c, Offset(s * 0.46f, s * 0.46f), Size(s * 0.3f, s * 0.3f), CornerRadius(s * 0.05f), style = st)
    drawRoundRect(c, Offset(s * 0.6f, s * 0.12f), Size(s * 0.26f, s * 0.26f), CornerRadius(s * 0.05f), style = st)
}
private fun DrawScope.icSpark(c: Color, s: Float, sw: Float) {
    val p = Path().apply {
        moveTo(s * 0.5f, s * 0.08f); lineTo(s * 0.6f, s * 0.4f); lineTo(s * 0.92f, s * 0.5f); lineTo(s * 0.6f, s * 0.6f)
        lineTo(s * 0.5f, s * 0.92f); lineTo(s * 0.4f, s * 0.6f); lineTo(s * 0.08f, s * 0.5f); lineTo(s * 0.4f, s * 0.4f); close()
    }
    drawPath(p, c, style = strokeOf(sw))
}
private fun DrawScope.icMemory(c: Color, s: Float, sw: Float) {
    drawArc(c, -50f, 290f, false, Offset(s * 0.14f, s * 0.14f), Size(s * 0.72f, s * 0.72f), style = strokeOf(sw))
    drawLine(c, Offset(s * 0.5f, s * 0.3f), Offset(s * 0.5f, s * 0.52f), sw, StrokeCap.Round)
    drawLine(c, Offset(s * 0.5f, s * 0.52f), Offset(s * 0.66f, s * 0.6f), sw, StrokeCap.Round)
}
private fun DrawScope.icBackChevron(c: Color, s: Float, sw: Float) {
    drawLine(c, Offset(s * 0.65f, s * 0.2f), Offset(s * 0.35f, s * 0.5f), sw, StrokeCap.Round)
    drawLine(c, Offset(s * 0.35f, s * 0.5f), Offset(s * 0.65f, s * 0.8f), sw, StrokeCap.Round)
}

@Composable
private fun SheetRow(title: String, value: String?, icon: DrawScope.(Float, Float) -> Unit, trailing: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.8f).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f)), contentAlignment = Alignment.Center) { LineIcon(20.dp, icon) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 16.sp)
            if (value != null) Text(value, color = InkDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (trailing != null) trailing() else LineIcon(14.dp) { s, sw -> icBackChevron(InkDim, s, sw) }
    }
}

@Composable
private fun PageHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onBack), contentAlignment = Alignment.Center) {
            LineIcon(18.dp) { s, sw ->
                drawLine(Ink, Offset(s * 0.2f, s * 0.5f), Offset(s * 0.8f, s * 0.5f), sw, StrokeCap.Round)
                drawLine(Ink, Offset(s * 0.8f, s * 0.5f), Offset(s * 0.55f, s * 0.25f), sw, StrokeCap.Round)
                drawLine(Ink, Offset(s * 0.8f, s * 0.5f), Offset(s * 0.55f, s * 0.75f), sw, StrokeCap.Round)
            }
        }
        Text(title, Modifier.weight(1f), color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ChoiceRow(title: String, sub: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (selected) Color.White.copy(alpha = 0.10f) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = if (selected) Ok else Ink, fontSize = 15.sp)
            if (sub.isNotBlank()) Text(sub, color = InkDim, fontSize = 12.sp, lineHeight = 17.sp)
        }
        if (selected) Text("\u2713", color = Ok, fontSize = 17.sp)
    }
}

/**
 * "+" sheet: camera / photos / files on top, then Projects, Permission, Connectors, Skills and Memory rows.
 * Drag it down (anywhere that is not scrolling) to close it. [page] is hoisted so the system Back button steps out of a sub-page first.
 */
@Composable
internal fun AttachSheetV2(page: String, setPage: (String) -> Unit, onClose: () -> Unit, onPhoto: () -> Unit, onVideo: () -> Unit, onGallery: () -> Unit, onFiles: () -> Unit) {
    @Suppress("UNUSED_VARIABLE") val ev = Extras.ver
    val chatId = AgentController.currentChatId
    val proj = Extras.projectOf(chatId)
    Column(
        Modifier.swipeDown(onClose).fillMaxWidth().heightIn(max = 640.dp).sheet(TopSheetShape).pointerInput(Unit) { detectTapGestures { } }
            .imePadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SheetHandle()
        when (page) {
            "projects" -> ProjectsPage(chatId, { setPage("main") })
            "permission" -> {
                PageHeader("الصلاحيات") { setPage("main") }
                ChoiceRow("يدوي", "يسألك قبل أي إجراء حساس على الهاتف: إرسال، حذف، شراء، تأكيد…", !Extras.permissionAuto) { Extras.permissionAuto = false }
                ChoiceRow("تلقائي", "ينفّذ الإجراءات بدون سؤال، ما عدا الدفع والشراء والحذف والتحويل فتبقى بموافقتك.", Extras.permissionAuto) { Extras.permissionAuto = true }
            }
            "connectors" -> {
                PageHeader("الموصّلات") { setPage("main") }
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Extras.connectors.forEach { cn ->
                        Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.8f).padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(cn.title, color = Ink, fontSize = 15.sp)
                                Text(cn.desc, color = InkDim, fontSize = 12.sp, lineHeight = 17.sp)
                                if (cn.id == "qaf" && Extras.qafKey.isBlank()) Text("لا يوجد مفتاح Qaf: أضفه من الإعدادات.", color = Danger, fontSize = 11.5.sp)
                            }
                            AppSwitch(Extras.connectorOn(cn.id)) { Extras.setConnector(cn.id, it) }
                        }
                    }
                }
            }
            "skills" -> SkillsPage { setPage("main") }
            "memory" -> {
                PageHeader("الذاكرة") { setPage("main") }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("احفظ معلومات عني", Modifier.weight(1f), color = Ink, fontSize = 15.sp)
                    AppSwitch(Extras.memoryOn) { Extras.memoryOn = it }
                }
                Text("اكتب بالدردشة: «تذكّر أن اسمي أحمد» وبحفظها هون وبستخدمها بالأجوبة. لا يُحفظ شي إلا لما تطلب.", color = InkDim, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.fillMaxWidth())
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (Extras.memory.isEmpty()) Text("الذاكرة فاضية.", color = InkDim, fontSize = 13.sp)
                    Extras.memory.toList().forEachIndexed { i, t ->
                        Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp), 0.7f).padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(t, Modifier.weight(1f).padding(vertical = 10.dp), color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                            Box(Modifier.size(40.dp).clip(CircleShape).clickable { Extras.removeMemory(i) }, contentAlignment = Alignment.Center) { Text("×", color = InkDim, fontSize = 20.sp) }
                        }
                    }
                }
                if (Extras.memory.isNotEmpty()) GlassButton("مسح كل الذاكرة", Modifier.fillMaxWidth(), tint = Danger) { Extras.clearMemory() }
            }
            else -> {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                        LineIcon(18.dp) { s, sw ->
                            drawLine(Ink, Offset(s * 0.2f, s * 0.2f), Offset(s * 0.8f, s * 0.8f), sw, StrokeCap.Round)
                            drawLine(Ink, Offset(s * 0.8f, s * 0.2f), Offset(s * 0.2f, s * 0.8f), sw, StrokeCap.Round)
                        }
                    }
                    Text("إضافة إلى الجلسة", Modifier.weight(1f), color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    Spacer(Modifier.width(38.dp))
                }
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AttachTile("الكاميرا", Modifier.weight(1f), onPhoto) { s, sw -> icCamera(Ink, s, sw) }
                        AttachTile("فيديو", Modifier.weight(1f), onVideo) { s, sw -> icVideoCam(Ink, s, sw) }
                        AttachTile("الصور", Modifier.weight(1f), onGallery) { s, sw -> icImage(Ink, s, sw) }
                        AttachTile("الملفات", Modifier.weight(1f), onFiles) { s, sw -> icFile(Ink, s, sw) }
                    }
                    SheetRow("إضافة إلى مشروع", proj?.name ?: "بدون", { s, sw -> icFolder(Ink, s, sw) }) { setPage("projects") }
                    SheetRow("الصلاحيات", if (Extras.permissionAuto) "تلقائي" else "يدوي", { s, sw -> icShield(Ink, s, sw) }) { setPage("permission") }
                    SheetRow("الموصّلات", Extras.connectors.count { Extras.connectorOn(it.id) }.let { "$it مفعّل" }, { s, sw -> icBlocks(Ink, s, sw) }) { setPage("connectors") }
                    SheetRow("المهارات", skillsSummary(), { s, sw -> icSpark(Ink, s, sw) }) { setPage("skills") }
                    SheetRow("الذاكرة", if (Extras.memoryOn) "${Extras.memory.size} معلومة محفوظة" else "متوقفة", { s, sw -> icMemory(Ink, s, sw) },
                        trailing = { AppSwitch(Extras.memoryOn) { Extras.memoryOn = it } }) { setPage("memory") }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
    }
}

private fun skillsSummary(): String { val n = Extras.skills().count { Extras.skillOn(it.id) }; return if (n == 0) "لا شي مفعّل" else "$n مفعّلة" }

@Composable
private fun SkillsPage(onBack: () -> Unit) {
    var adding by remember { mutableStateOf(false) }
    var n by remember { mutableStateOf("") }
    var t by remember { mutableStateOf("") }
    PageHeader("المهارات", onBack)
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Extras.skills().forEach { sk ->
            Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.8f).padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(sk.name, color = Ink, fontSize = 15.sp)
                    Text(sk.text, color = InkDim, fontSize = 12.sp, lineHeight = 17.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
                if (!sk.builtin) Box(Modifier.size(38.dp).clip(CircleShape).clickable { Extras.removeSkill(sk.id) }, contentAlignment = Alignment.Center) { Text("×", color = InkDim, fontSize = 20.sp) }
                AppSwitch(Extras.skillOn(sk.id)) { Extras.setSkill(sk.id, it) }
                Spacer(Modifier.width(4.dp))
            }
        }
        if (adding) {
            GlassField("اسم المهارة", n, { n = it })
            GlassField("التعليمات (كيف يتصرف عندما تكون المهارة مفعّلة)", t, { t = it }, lines = 4)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("إضافة", Modifier.weight(1f), enabled = n.isNotBlank() && t.isNotBlank(), strong = true) { Extras.addSkill(n, t); n = ""; t = ""; adding = false }
                GlassButton("إلغاء", Modifier.weight(1f)) { adding = false }
            }
        } else GlassButton("+ مهارة جديدة", Modifier.fillMaxWidth()) { adding = true }
    }
}

@Composable
private fun ProjectsPage(chatId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<String?>(null) }     // project id, or "new"
    var name by remember { mutableStateOf("") }
    var ins by remember { mutableStateOf("") }
    val current = Extras.projectOf(chatId)
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val id = editing
        if (uri != null && id != null && id != "new") scope.launch {
            val ok = withContext(Dispatchers.IO) { Extras.addProjectFile(ctx, id, uri, displayName(ctx, uri)) }
            if (!ok) android.widget.Toast.makeText(ctx, "الملف لازم يكون نصياً (txt, md, كود, csv, json…)", android.widget.Toast.LENGTH_LONG).show()
        }
    }
    val ed = editing
    if (ed == null) {
        PageHeader("المشاريع", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceRow("بدون مشروع", "محادثة عادية", current == null) { Extras.setChatProject(chatId, null) }
            Extras.projects.toList().forEach { p ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { ChoiceRow(p.name, if (p.files.isEmpty()) p.instructions.take(60) else "${p.files.size} ملف · " + p.instructions.take(40), current?.id == p.id) { Extras.setChatProject(chatId, p.id) } }
                    Box(Modifier.size(42.dp).clip(CircleShape).clickable { editing = p.id; name = p.name; ins = p.instructions }, contentAlignment = Alignment.Center) { LineIcon(18.dp) { s, sw -> icEdit(InkDim, s, sw) } }
                }
            }
            GlassButton("+ مشروع جديد", Modifier.fillMaxWidth()) { editing = "new"; name = ""; ins = "" }
            Text("المشروع = تعليمات وملفات نصية يتذكرها المساعد في هذه المحادثة (مثل مشاريع Claude).", color = InkDim, fontSize = 11.5.sp, lineHeight = 16.sp)
        }
    } else {
        PageHeader(if (ed == "new") "مشروع جديد" else "تعديل المشروع") { editing = null }
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassField("اسم المشروع", name, { name = it })
            GlassField("التعليمات (كيف تريد أن يتصرف في هذا المشروع)", ins, { ins = it }, lines = 5)
            if (ed != "new") {
                Extras.projects.firstOrNull { it.id == ed }?.files?.forEachIndexed { i, f ->
                    Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp), 0.7f).padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(f.first, Modifier.weight(1f).padding(vertical = 10.dp), color = Ink, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Box(Modifier.size(40.dp).clip(CircleShape).clickable { Extras.removeProjectFile(ed, i) }, contentAlignment = Alignment.Center) { Text("×", color = InkDim, fontSize = 20.sp) }
                    }
                }
                GlassButton("إضافة ملف نصي للمشروع", Modifier.fillMaxWidth()) { filePicker.launch(arrayOf("text/*", "application/json", "application/xml", "application/javascript", "application/octet-stream")) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton(if (ed == "new") "إنشاء" else "حفظ", Modifier.weight(1f), enabled = name.isNotBlank(), strong = true) {
                    if (ed == "new") { Extras.addProject(name, ins)?.let { p -> editing = p.id; Extras.setChatProject(chatId, p.id) } }
                    else { Extras.updateProject(ed, name, ins); editing = null }
                }
                if (ed != "new") GlassButton("حذف", Modifier.weight(1f), tint = Danger) { Extras.removeProject(ed); editing = null }
            }
        }
    }
}
