package com.aiphoneagent

data class UiNode(
    val id: Int, val text: String, val desc: String, val viewId: String, val cls: String,
    val clickable: Boolean, val scrollable: Boolean, val editable: Boolean,
    val left: Int, val top: Int, val right: Int, val bottom: Int
)

data class ScreenSnapshot(val pkg: String, val nodes: List<UiNode>, val note: String = "", val w: Int = 0, val h: Int = 0,
    /** Optional JPEG screenshot (base64) + its pixel size, for vision models. */
    val image: String? = null, val imgW: Int = 0, val imgH: Int = 0) {
    /** Text + coarse position, so layout changes without text changes (a drawer opening) also count as a change. */
    fun signature(): Int = (pkg + nodes.size + nodes.joinToString("|") { it.text + it.desc + (it.left / 24) + "," + (it.top / 24) }).hashCode()
}

/** type: open_app | open_url | click | set_text | scroll | back | tap_at */
data class AgentAction(
    val type: String, val nodeId: Int? = null, val text: String? = null,
    val target: String? = null, val reason: String = "", val sensitive: Boolean = false,
    /** set_text only: press Enter right after typing (search boxes) without another model round trip. */
    val thenEnter: Boolean = false
)

/** Result of the one-time planning call. */
data class PlanResult(val steps: List<String>, val firstApp: String?)

data class BackendReply(
    val action: AgentAction?, val say: String?, val done: Boolean = false, val askUser: String? = null, val note: String? = null,
    /** The model asks for a screenshot on the next turn. */
    val look: Boolean = false
)

data class ActionResult(val dispatched: Boolean, val verified: Boolean?, val message: String)

/** Swap this interface to change the model/provider without touching the app. */
interface AgentBackend {
    suspend fun next(goal: String, history: List<String>, screen: ScreenSnapshot): BackendReply
    /** One-time planning with the smartest model. Null = no separate planning. */
    suspend fun plan(goal: String): PlanResult? = null
    /** Same as [next] but with the smartest model (used when stuck and to verify completion). */
    suspend fun nextSmart(goal: String, history: List<String>, screen: ScreenSnapshot): BackendReply = next(goal, history, screen)
    /** A 2-4 word title for a conversation transcript. Null = unsupported/failed. */
    suspend fun title(transcript: String): String? = null
}

/** Providers and models offered in the model picker next to the + button. */
object ModelCatalog {
    val groq = listOf(
        "llama-3.3-70b-versatile", "openai/gpt-oss-120b", "openai/gpt-oss-20b",
        "meta-llama/llama-4-scout-17b-16e-instruct", "llama-3.1-8b-instant", "qwen/qwen3-32b"
    )
    /** Google retired the 2.5 family for new keys (HTTP 404 "no longer available to new users"): the picker lists the 3.x models. */
    val gemini = listOf("gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-3.1-pro-preview")
    const val GEMINI_DEFAULT = "gemini-3.8-flash"
    const val GEMINI_LITE = "gemini-3.5-flash-lite"
    const val GEMINI_FLASH = "gemini-3.6-flash"

    /** A model id saved by an older build (2.5 family) is moved to its current replacement. */
    fun migrateGemini(id: String): String = when (id) {
        "", "gemini-2.5-flash" -> GEMINI_DEFAULT
        "gemini-2.5-flash-lite" -> GEMINI_LITE
        "gemini-2.5-pro" -> "gemini-3.1-pro-preview"
        else -> id
    }

    /** "Gemini 2.5 Flash" for Gemini, "Groq · Llama 3.3 70B" for Groq: always the exact model that answers. */
    fun label(provider: String, id: String): String {
        if (provider == "gemini")
            return id.split('-').joinToString(" ") { p -> if (p.firstOrNull()?.isDigit() == true) p else p.replaceFirstChar { it.uppercase() } }
        val name = when (id.substringAfterLast('/')) {
            "llama-3.3-70b-versatile" -> "Llama 3.3 70B"
            "gpt-oss-120b" -> "GPT-OSS 120B"
            "gpt-oss-20b" -> "GPT-OSS 20B"
            "llama-4-scout-17b-16e-instruct" -> "Llama 4 Scout"
            "llama-3.1-8b-instant" -> "Llama 3.1 8B"
            "qwen3-32b" -> "Qwen3 32B"
            else -> id.substringAfterLast('/')
        }
        return "Groq \u00b7 $name"
    }
}
