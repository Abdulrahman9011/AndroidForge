package com.aiphoneagent

import java.io.File
import androidx.core.content.FileProvider
import android.provider.OpenableColumns
import android.provider.MediaStore
import android.os.Build
import android.net.Uri
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.content.ContentValues
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.*

data class Attachment(val name: String, val mime: String, val path: String)

internal val msgCounter = java.util.concurrent.atomic.AtomicLong()

data class ChatMsg(
    val fromUser: Boolean, val text: String,
    val time: Long = System.currentTimeMillis(),
    val id: Long = msgCounter.incrementAndGet(),
    /** True for the single collapsible "thinking" strip that holds the step-by-step log of one run. */
    val thinking: Boolean = false,
    /** Files/images/videos sent with this message: shown as thumbnails in the bubble. */
    val atts: List<Attachment> = emptyList()
) {
    val steps = mutableStateListOf<String>()
    var finished by mutableStateOf(false)
    /** True for a reply that just arrived in this session: the bubble reveals its text progressively. */
    var animate = false
    /** 1 = like, -1 = dislike, 0 = none. Local to this session. */
    var reaction by mutableStateOf(0)

    fun toJson(): JSONObject = JSONObject().put("u", fromUser).put("t", text).put("ts", time).put("th", thinking).put("rx", reaction)
        .put("steps", JSONArray(steps.toList()))
        .put("at", JSONArray(atts.map { JSONObject().put("n", it.name).put("m", it.mime).put("p", it.path) }))

    companion object {
        fun fromJson(o: JSONObject): ChatMsg {
            val at = o.optJSONArray("at")
            val list = if (at == null) emptyList() else (0 until at.length()).map {
                val a = at.getJSONObject(it); Attachment(a.optString("n"), a.optString("m"), a.optString("p"))
            }
            val m = ChatMsg(o.optBoolean("u"), o.optString("t"), o.optLong("ts", System.currentTimeMillis()), thinking = o.optBoolean("th"), atts = list)
            o.optJSONArray("steps")?.let { st -> for (i in 0 until st.length()) m.steps.add(st.optString(i)) }
            m.finished = true; m.reaction = o.optInt("rx")
            return m
        }
    }
}

/** Task execution engine: one validated action at a time, observe, verify, continue/ask/stop. */
object AgentController {
    val messages = mutableStateListOf<ChatMsg>()
    var running by mutableStateOf(false)
    var paused by mutableStateOf(false)
    var status by mutableStateOf("Idle")
    var pendingConfirm by mutableStateOf<String?>(null)
    var awaitingAnswer by mutableStateOf(false)
    private var answerDeferred: CompletableDeferred<String>? = null
    var cursorVisible by mutableStateOf(false)
    var cursorX by mutableFloatStateOf(0f)
    var cursorY by mutableFloatStateOf(0f)
    var cursorClick by mutableIntStateOf(0)
    /** True only while the agent really works on the phone (not while it just chats): the floating panel and the cursor follow it. */
    var phoneActive by mutableStateOf(false)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var confirmation: CompletableDeferred<Boolean>? = null
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var appCtx: Context

    private const val MAX_STEPS = 150
    /** "افتح X" / "open X" and nothing else: no model call needed. */
    private val PURE_OPEN = Regex("^(?:ا?فتح(?:لي)?|شغّ?ل(?:ي)?|open|launch)\\s+(?:تطبيق\\s+|برنامج\\s+|app\\s+)?([\\p{L}\\p{N}.\\-]+(?:\\s+[\\p{L}\\p{N}.\\-]+)?)$", RegexOption.IGNORE_CASE)
    private val SEND_LABEL = Regex("send|إرسال|ارسال|gönder", RegexOption.IGNORE_CASE)
    private val CONJ = Regex("(^|\\s)(ثم|و|بعدين|وبعدين|and|then|ve)(\\s|$)", RegexOption.IGNORE_CASE)
    private val ALLOWED = setOf("open_app", "open_url", "click", "set_text", "scroll", "back", "tap_at", "wait", "enter", "home", "send_file", "voice_note")
    private val SENSITIVE = Regex(
        "buy|purchase|pay|place order|send|delete|remove|submit|confirm|transfer|checkout|subscribe|شراء|دفع|إرسال|حذف|تأكيد",
        RegexOption.IGNORE_CASE)

    fun init(c: Context) { appCtx = c.applicationContext; TokenBudget.init(appCtx); Voice.init(appCtx); LlmPlanner.init(c); if (!::prefs.isInitialized) prefs = c.getSharedPreferences("agent", Context.MODE_PRIVATE); loadChats() }
    var backendUrl: String
        get() = prefs.getString("url", "").orEmpty()
        set(v) { prefs.edit().putString("url", v.trim()).apply() }
    var backendToken: String
        get() = prefs.getString("token", "").orEmpty()
        set(v) { prefs.edit().putString("token", v.trim()).apply() }

    var aiBaseUrl: String
        get() = prefs.getString("aiurl", "https://api.groq.com/openai/v1/chat/completions").orEmpty()
        set(v) { prefs.edit().putString("aiurl", v.trim()).apply() }
    var aiModel: String
        get() = prefs.getString("aimodel", "llama-3.3-70b-versatile").orEmpty()
        set(v) { prefs.edit().putString("aimodel", v.trim()).apply(); modelVer++ }
    /** "groq" or "gemini". Saving the first Gemini key switches to Gemini (unless a provider was already picked). */
    var provider: String
        get() = prefs.getString("provider", null) ?: "groq"
        set(v) { prefs.edit().putString("provider", v).apply(); modelVer++ }
    var geminiModel: String
        get() = ModelCatalog.migrateGemini(prefs.getString("geminimodel", ModelCatalog.GEMINI_DEFAULT).orEmpty())
        set(v) { prefs.edit().putString("geminimodel", v.trim()).apply(); modelVer++ }
    private var modelVer by mutableIntStateOf(0)
    /** Exact name of the model that answers, e.g. "Gemini 2.5 Flash". Read in Compose, so it updates when the choice changes. */
    val modelLabel: String
        get() { val v = modelVer; return if (v >= 0 && provider == "gemini") ModelCatalog.label("gemini", geminiModel) else ModelCatalog.label("groq", aiModel) }
    fun pickModel(p: String, m: String) { if (p == "gemini") geminiModel = m else aiModel = m; provider = p }
    private fun splitKeys(s: String) = s.split(Regex("[,;\\s]+")).map { it.trim() }.filter { it.length > 8 }
    /** Every usable key: saved ones (one per line in Settings) + the legacy single key + keys baked in at build time. */
    private var keyCache: List<String>? = null     // Keystore decryption is slow: the composer reads these on every recomposition
    val apiKeyList: List<String>
        get() = keyCache ?: run {
            val saved = splitKeys(Secure.decrypt(prefs.getString("aikeys", "").orEmpty()) + "\n" + Secure.decrypt(prefs.getString("aikey", "").orEmpty()))
            (saved + splitKeys(BuildConfig.DEFAULT_API_KEYS) + splitKeys(BuildConfig.DEFAULT_API_KEY)).distinct().also { keyCache = it }
        }
    /** First key (voice/TTS uses it). */
    val apiKey: String get() = apiKeyList.firstOrNull().orEmpty()
    /** Settings text: one key per line. Quotas are per Groq account, so the pool rotates through them. */
    var apiKeys: String
        get() = apiKeyList.joinToString("\n")
        set(v) { prefs.edit().putString("aikeys", Secure.encrypt(splitKeys(v).distinct().joinToString("\n"))).remove("aikey").apply(); keyCache = null; TokenBudget.version++ }
    var visionModel: String
        get() = prefs.getString("visionmodel", "meta-llama/llama-4-scout-17b-16e-instruct").orEmpty()
        set(v) { prefs.edit().putString("visionmodel", v.trim()).apply() }
    var useVision: Boolean
        get() = prefs.getBoolean("usevision", true)
        set(v) { prefs.edit().putBoolean("usevision", v).apply() }
    var useAi: Boolean
        get() = prefs.getBoolean("useai", true)
        set(v) { prefs.edit().putBoolean("useai", v).apply() }
    private var gemCache: String? = null
    var geminiKey: String
        get() = gemCache ?: Secure.decrypt(prefs.getString("geminikey", "").orEmpty()).also { gemCache = it }
        set(v) {
            prefs.edit().putString("geminikey", Secure.encrypt(v.trim())).apply(); gemCache = v.trim()
            // First Gemini key: start using Gemini unless the user already picked a provider.
            if (v.isNotBlank() && !prefs.contains("provider")) prefs.edit().putString("provider", "gemini").apply()
            modelVer++; TokenBudget.version++
        }
    val aiReady: Boolean get() = apiKey.isNotBlank() || geminiKey.isNotBlank() || backendUrl.isNotBlank()

    /** True when the current task came from voice (or "always speak" is on): replies are spoken. */
    var speakBack = false
        private set
    private fun talk(t: String) { if (speakBack) Voice.speak(t) }
    fun info(t: String) = say(t)
    /** Download button on the clipboard banner. */
    fun downloadLink(url: String, kind: String) {
        messages += ChatMsg(true, "نزّل " + (when (kind) { "audio" -> "الصوت"; "image" -> "الصورة"; else -> "الفيديو" }) + " " + url); scheduleSave()
        MediaDownloader.dismiss()
        scope.launch { MediaDownloader.run(appCtx, MediaDownloader.Req(url, kind)) { say(it) } }
    }
    private val ACKS = listOf("تمام", "حاضر", "ماشي", "أبشر")
    private fun bringAppToFront(svc: AgentAccessibilityService) {
        svc.startIntent(Intent(appCtx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }

    /** "Clear conversation" in Settings: deletes the open conversation (also from the list). */
    fun clearHistory() { deleteChat(currentChatId) }

    // ---- saved conversations (the list in the side menu) ----
    val chats = mutableStateListOf<ChatMeta>()
    var currentChatId by mutableStateOf(java.util.UUID.randomUUID().toString())
        private set
    private var chatsLoaded = false
    private var saveJob: Job? = null
    private val titling = HashSet<String>()

    private fun loadChats() {
        if (chatsLoaded) return
        chatsLoaded = true
        ChatStore.init(appCtx)
        chats.clear(); chats.addAll(ChatStore.loadIndex().sortedByDescending { it.updated })
    }
    private fun quickTitle(t: String): String { val x = t.trim().replace('\n', ' '); return if (x.length > 32) x.take(32).trimEnd() + "…" else x }
    private fun scheduleSave() {
        if (!chatsLoaded) return
        saveJob?.cancel()
        saveJob = scope.launch { delay(500); persistNow() }
    }
    /** Writes the open conversation (messages + list entry). A conversation with no user message is never saved. */
    fun persistNow() {
        if (!chatsLoaded) return
        val real = messages.toList().filter { !it.thinking || it.steps.isNotEmpty() }
        val first = real.firstOrNull { it.fromUser } ?: return
        val id = currentChatId
        val arr = JSONArray(); real.forEach { arr.put(it.toJson()) }
        val old = chats.firstOrNull { it.id == id }
        val meta = ChatMeta(id, old?.title ?: quickTitle(first.text), System.currentTimeMillis(), old?.auto ?: true)
        if (old != null) chats.remove(old)
        chats.add(0, meta)
        val list = chats.toList()
        scope.launch(Dispatchers.IO) { ChatStore.save(id, arr); ChatStore.saveIndex(list) }
    }
    fun newChat(): Boolean {
        if (running) return false
        persistNow()
        messages.clear(); convo.clear(); attachments.clear(); attachmentsSent = false
        currentChatId = java.util.UUID.randomUUID().toString()
        return true
    }
    fun openChat(id: String): Boolean {
        if (running) return false
        if (id == currentChatId) return true
        persistNow()
        val arr = ChatStore.load(id) ?: return false
        val list = (0 until arr.length()).mapNotNull { runCatching { ChatMsg.fromJson(arr.getJSONObject(it)) }.getOrNull() }
        messages.clear(); messages.addAll(list); convo.clear(); attachments.clear(); attachmentsSent = false
        list.filter { !it.thinking && it.text.isNotBlank() }.takeLast(8).forEach { remember((if (it.fromUser) "user: " else "assistant: ") + it.text) }
        currentChatId = id
        return true
    }
    fun deleteChat(id: String) {
        val arr = ChatStore.load(id)
        if (arr != null) for (i in 0 until arr.length()) {
            val at = arr.optJSONObject(i)?.optJSONArray("at") ?: continue
            for (j in 0 until at.length()) runCatching { File(at.getJSONObject(j).optString("p")).delete() }
        }
        chats.removeAll { it.id == id }
        ChatStore.delete(id)
        val list = chats.toList()
        scope.launch(Dispatchers.IO) { ChatStore.saveIndex(list) }
        if (id == currentChatId) { messages.clear(); convo.clear(); attachments.clear(); attachmentsSent = false; currentChatId = java.util.UUID.randomUUID().toString() }
    }
    /** One cheap model call: a 2-4 word title for the conversation, replacing the quick title. Tried once per conversation. */
    private fun autoTitle(id: String) {
        if (!titling.add(id)) return
        val b: AgentBackend = (if (apiKeyList.isNotEmpty() || geminiKey.isNotBlank())
            DirectBackend(aiBaseUrl, aiModel, apiKeyList, if (useVision) visionModel else "", geminiKey, provider, geminiModel) { aiModel = it } else null) ?: return
        val transcript = messages.toList().filter { !it.thinking }.take(6)
            .joinToString("\n") { (if (it.fromUser) "user: " else "assistant: ") + it.text.take(160) }
        scope.launch {
            val t = withContext(Dispatchers.IO) { runCatching { b.title(transcript) }.getOrNull() }
            val i = chats.indexOfFirst { it.id == id }
            if (i >= 0) {
                chats[i] = chats[i].copy(title = t ?: chats[i].title, auto = false)
                val l = chats.toList(); launch(Dispatchers.IO) { ChatStore.saveIndex(l) }
            }
        }
    }

    // ---- conversation memory (context for chatting) ----
    private val convo = java.util.concurrent.CopyOnWriteArrayList<String>()
    private fun remember(line: String) { convo.add(line.take(220)); while (convo.size > 8) convo.removeAt(0) }

    // ---- attachments: files/images/videos the user wants the agent to hand to other apps ----
    val attachments = mutableStateListOf<Attachment>()
    /** True once the current attachments were sent with a message: they leave the composer (they live in the bubble) but stay available to the agent. */
    var attachmentsSent by mutableStateOf(false)

    fun addAttachments(uris: List<Uri>) {
        scope.launch(Dispatchers.IO) {
            val dir = File(appCtx.filesDir, "media").apply { mkdirs() }
            for (u in uris) {
                try {
                    var name = "file"
                    appCtx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) name = c.getString(0) ?: name }
                    val mime = appCtx.contentResolver.getType(u) ?: "*/*"
                    val safe = name.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").takeLast(80)
                    val f = File(dir, "${System.currentTimeMillis()}_$safe")
                    val ok = appCtx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) }; true } ?: false
                    if (!ok) continue
                    stageToDownloads(f, safe, mime)
                    withContext(Dispatchers.Main) {
                        if (attachmentsSent) { attachments.clear(); attachmentsSent = false }
                        attachments += Attachment(name, mime, f.absolutePath)
                    }
                } catch (e: Exception) { say("تعذّر إرفاق الملف: ${e.message}") }
            }
        }
    }
    fun removeAttachment(a: Attachment) { attachments.remove(a); runCatching { File(a.path).delete() } }
    /** Files stay on disk: the sent message still shows them as thumbnails. */
    private fun clearAttachments() { attachments.clear(); attachmentsSent = false }

    /** A copy in Downloads/AIPhoneAgent so apps without a share target can still pick it from the system file picker. */
    private fun stageToDownloads(f: File, name: String, mime: String) {
        if (Build.VERSION.SDK_INT < 29) return
        runCatching {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/AIPhoneAgent")
            }
            val uri = appCtx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return
            appCtx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
        }
    }

    private fun sendFile(svc: AgentAccessibilityService, a: AgentAction): ActionResult {
        if (attachments.isEmpty()) return ActionResult(false, null, "No attached files. Ask the user to attach the file with the paperclip button.")
        val sel = a.text.orEmpty().trim()
        val all = attachments.toList()
        val files = if (sel.isEmpty() || sel.equals("all", true)) all else all.filter { it.name.contains(sel, true) }.ifEmpty { all }
        val target = a.target.orEmpty().trim()
        val pkg = if (target.contains('.') && !target.contains(' ')) target else AppResolver.find(appCtx, target, strict = false)
            ?: return ActionResult(false, null, "App '$target' is not installed or could not be matched.")
        val uris = ArrayList<Uri>()
        files.forEach { runCatching { uris += FileProvider.getUriForFile(appCtx, "${appCtx.packageName}.files", File(it.path)) } }
        if (uris.isEmpty()) return ActionResult(false, null, "Could not read the attached file.")
        val i = Intent(if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE).apply {
            type = files.map { it.mime }.distinct().singleOrNull() ?: "*/*"
            if (uris.size == 1) putExtra(Intent.EXTRA_STREAM, uris[0]) else putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            setPackage(pkg)
            clipData = ClipData.newRawUri("files", uris[0]).also { cd -> uris.drop(1).forEach { cd.addItem(ClipData.Item(it)) } }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (i.resolveActivity(appCtx.packageManager) == null)
            return ActionResult(false, null, "$pkg has no share target. Open it, tap its attach button and pick the file from Downloads/AIPhoneAgent.")
        return try { svc.startActivity(i); ActionResult(true, null, "share sheet of $pkg opened with ${uris.size} file(s)") }
        catch (e: Exception) { ActionResult(false, null, e.message ?: "share failed") }
    }

    private val MIC_RE = Regex("voice|mic|record|audio|hold to|ses |mikrofon|صوت|ميكروفون|مايك|تسجيل", RegexOption.IGNORE_CASE)
    private val SEND_RE = Regex("send|إرسال|ارسال|gönder", RegexOption.IGNORE_CASE)
    private val DUR_RE = Regex("^\\s*\\d{1,2}:\\d{2}\\s*$")
    private fun lab(n: UiNode) = n.text + " " + n.desc + " " + n.viewId
    /** Voice messages show their length ("0:05"): a new one in the chat means the note was sent. */
    private fun durCount(s: ScreenSnapshot) = s.nodes.count { DUR_RE.matches(it.text) || DUR_RE.matches(it.desc) }

    /** The model's choice if it really is a mic/record control; otherwise the labelled mic button in the lower part of the screen (its id often says "voice"/"audio"). */
    private fun pickMic(s: ScreenSnapshot, chosen: UiNode?): UiNode? {
        if (chosen != null && MIC_RE.containsMatchIn(lab(chosen))) return chosen
        val low = if (s.h > 0) (s.h * 0.55f).toInt() else 0
        val found = s.nodes.filter { MIC_RE.containsMatchIn(lab(it)) && it.top >= low && it.right > it.left && it.bottom > it.top }
            .sortedByDescending { it.clickable }.firstOrNull()
        return found ?: chosen
    }

    private suspend fun speakAndWait(text: String) {
        val done = CompletableDeferred<Unit>()
        Voice.speak(text) { done.complete(Unit) }
        withTimeoutOrNull(45_000L) { done.await() }             // exact end of the speech
        delay(800)                                              // tail, so the last word is not cut
    }

    /**
     * Records a voice note with the phone's own voice: audio is downloaded first (no gaps), then
     *  1. the mic button is held down exactly until the last word is spoken, then released (sends the note); if the app showed no
     *     sign of recording,
     *  2. tap-to-record mode: one tap, and if a send button appears, speak and press it.
     * It reports honestly when nothing started, so the agent never pretends it sent something.
     * Clarity: media volume to maximum and exclusive audio focus, so other apps stay silent while the microphone listens.
     */
    private suspend fun voiceNote(svc: AgentAccessibilityService, a: AgentAction, s: ScreenSnapshot): ActionResult {
        val n = pickMic(s, s.nodes.firstOrNull { it.id == a.nodeId }) ?: return ActionResult(false, null, "mic node not on screen")
        val cx = (n.left + n.right) / 2f; val cy = (n.top + n.bottom) / 2f
        val text = a.text.orEmpty()
        val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val oldVol = am?.getStreamVolume(AudioManager.STREAM_MUSIC)
        Voice.stopSpeaking()
        withTimeoutOrNull(20_000L) { Voice.prefetch(text) }          // audio ready before the button is pressed
        if (am != null && oldVol != null) runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0) }
        val focus = if (am == null) null else runCatching {
            AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setOnAudioFocusChangeListener { }.build().also { am.requestAudioFocus(it) }
        }.getOrNull()
        try {
            var uiChanged = false
            val hold = svc.holdWhile(cx, cy) {
                delay(1200)                                           // the app has started recording
                uiChanged = snap(svc).signature() != s.signature()
                speakAndWait(text)
            }
            delay(1300)
            val after = snap(svc)
            if (durCount(after) > durCount(s)) return ActionResult(true, null, "voice note sent: a new voice message appeared in the chat")
            if (hold.dispatched && uiChanged) return ActionResult(true, null, "mic held while speaking, then released; the recording UI appeared. The note should now be in the chat: check it, do not record again")
            val sendBefore = s.nodes.count { SEND_RE.containsMatchIn(lab(it)) }
            svc.tapAt(cx, cy); delay(1000)
            val rec = snap(svc)
            val sends = rec.nodes.filter { SEND_RE.containsMatchIn(lab(it)) && it.right > it.left }
            if (sends.size > sendBefore) {
                val send = sends.last()
                speakAndWait(text)
                svc.tapAt((send.left + send.right) / 2f, (send.top + send.bottom) / 2f)
                return ActionResult(true, null, "voice note recorded in tap-to-record mode and sent")
            }
            return ActionResult(false, null, "التسجيل ما بدأ: الضغط المطوّل والنقر على المايك ما غيّروا الشاشة (${hold.message}). تأكد إن التطبيق عنده إذن المايك وإن ما في برنامج تاني يستخدم المايك (مثل مسجّل الشاشة).")
        } finally {
            if (am != null && oldVol != null) runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, oldVol, 0) }
            if (am != null && focus != null) runCatching { am.abandonAudioFocusRequest(focus) }
        }
    }
    /** Removes the message with [id] and everything after it (used by edit and retry). */
    fun truncateFrom(id: Long) {
        val i = messages.indexOfFirst { it.id == id }
        if (i >= 0) while (messages.size > i) messages.removeAt(messages.size - 1)
        scheduleSave()
    }
    /** Runs the user command that produced [ai] again. */
    fun retry(ai: ChatMsg) {
        if (running) return
        val i = messages.indexOfFirst { it.id == ai.id }
        val u = messages.take(if (i < 0) messages.size else i).lastOrNull { it.fromUser } ?: return
        val t = u.text
        truncateFrom(u.id)
        submit(t)
    }
    fun togglePause() { paused = !paused }
    fun answer(ok: Boolean) { confirmation?.complete(ok) }
    fun stop() {
        Voice.stopSpeaking()
        job?.cancel(); confirmation?.complete(false)
        // Reset the UI right away so the floating panel reacts instantly, even if a network call is still unwinding.
        running = false; paused = false; status = "Idle"; pendingConfirm = null; cursorVisible = false; awaitingAnswer = false; phoneActive = false
    }
    private fun say(t: String, atts: List<Attachment> = emptyList()) { messages += ChatMsg(false, t, atts = atts).also { it.animate = true }; scheduleSave() }
    /** Progress goes into the collapsible thinking strip, not into the chat. */
    private var thinkingMsg: ChatMsg? = null
    private fun log(t: String) { val th = thinkingMsg; if (th != null) th.steps.add(t) else say(t) }
    private fun service() = AgentAccessibilityService.instance

    fun submit(text: String, byVoice: Boolean = false) {
        if (text.isBlank()) return
        if (TokenBudget.exhausted()) return   // out of tokens for today: the composer shows the renewal time instead
        if (!Net.online && !awaitingAnswer) { info("ما في إنترنت حالياً، فما بقدر أرد. أول ما يرجع الاتصال جرّب مرة ثانية."); return }
        if (awaitingAnswer) { messages += ChatMsg(true, text); scheduleSave(); answerDeferred?.complete(text); return }
        if (running) return
        speakBack = byVoice || Voice.always
        voiceFails = 0; voiceApproved = false
        val sent = if (attachmentsSent) emptyList() else attachments.toList()
        messages += ChatMsg(true, text, atts = sent)
        if (sent.isNotEmpty()) attachmentsSent = true
        scheduleSave()
        remember("user: $text")
        // A link + "download" (or just a supported link) never goes to the phone-control agent: it is downloaded directly.
        MediaDownloader.parse(text, appCtx)?.let { req ->
            scope.launch { MediaDownloader.run(appCtx, req) { say(it) } }
            return
        }
        // Commands: /work = control the phone, /image and /video = generate media. Everything else is plain chat (no phone control at all).
        val t0 = text.trim()
        val cmd = CMD.find(t0)
        val spoken = byVoice && cmd == null && VOICE_WORK.containsMatchIn(t0)
        val kind = when { cmd != null -> cmd.groupValues[1].lowercase(); spoken -> "work"; t0 == "/selftest" -> "selftest"; else -> "chat" }
        val body = when { cmd != null -> t0.substring(cmd.range.last + 1).trim(); spoken -> t0.replace(VOICE_WORK, "").trim(); else -> t0 }
        // The floating panel / cursor / notification are NOT started here: only when the agent really begins working on the phone (see beginPhoneWork).
        job = scope.launch {
            val me = coroutineContext[Job]
            running = true; paused = false
            val th = ChatMsg(false, "", thinking = true); messages += th; thinkingMsg = th
            val dm0 = appCtx.resources.displayMetrics
            cursorX = dm0.widthPixels / 2f; cursorY = dm0.heightPixels / 2f; cursorVisible = false; phoneActive = false
            try {
                when (kind) {
                    "selftest" -> selfTest()
                    "work" -> if (body.isBlank()) say("اكتب المهمة بعد /work، مثلاً: /work افتح يوتيوب") else runTask(body)
                    "image" -> if (body.isBlank()) say("اكتب وصف الصورة بعد /image") else generateImage(body)
                    "video" -> if (body.isBlank()) say("اكتب وصف الفيديو بعد /video") else generateVideo(body)
                    else -> chatOnly(body)
                }
            } catch (e: CancellationException) { say("تم الإيقاف."); throw e
            } catch (e: Exception) { say("خطأ: ${e.message}")
            } finally {
                th.finished = true; if (th.steps.isEmpty()) messages.remove(th); if (thinkingMsg === th) thinkingMsg = null
                if (job === me || job == null) { running = false; paused = false; status = "Idle"; pendingConfirm = null; cursorVisible = false; awaitingAnswer = false; phoneActive = false }
                persistNow()
                chats.firstOrNull { it.id == currentChatId }?.let { if (it.auto) autoTitle(it.id) }
            }
        }
    }

    private val CMD = Regex("^/(work|image|video)(?=\\s|$)\\s*", RegexOption.IGNORE_CASE)
    private val VOICE_WORK = Regex("^\\s*(work|وورك|ورك)\\s+", RegexOption.IGNORE_CASE)

    private fun directBackend(): DirectBackend? =
        if (apiKeyList.isNotEmpty() || geminiKey.isNotBlank()) DirectBackend(aiBaseUrl, aiModel, apiKeyList, if (useVision) visionModel else "", geminiKey, provider, geminiModel) { aiModel = it } else null

    /** Images attached to the current message (or a very recent one), downscaled to JPEG base64 for the vision model. */
    private suspend fun imagesForChat(): List<String> = withContext(Dispatchers.IO) {
        val src = messages.takeLast(8).lastOrNull { it.fromUser && it.atts.isNotEmpty() }?.atts.orEmpty()
            .filter { it.mime.startsWith("image") }.takeLast(3)
        src.mapNotNull { a ->
            runCatching {
                val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                android.graphics.BitmapFactory.decodeFile(a.path, o)
                var ss = 1
                while (maxOf(o.outWidth, o.outHeight) / ss > 1280 && ss < 64) ss *= 2
                val bmp = android.graphics.BitmapFactory.decodeFile(a.path, android.graphics.BitmapFactory.Options().apply { inSampleSize = ss })
                if (bmp == null) null else {
                    val bo = java.io.ByteArrayOutputStream()
                    bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, bo)
                    android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP)
                }
            }.getOrNull()
        }
    }

    /** Plain conversation with the personality: no phone control, no overlay, works without the accessibility service. */
    private suspend fun chatOnly(goal: String) {
        val direct = directBackend() ?: run { say("ما في مفتاح ذكاء اصطناعي. أضف مفتاح Groq أو Gemini من الإعدادات."); return }
        status = "أفكر…"
        val images = imagesForChat()
        val hist = convo.toList().map { (it.startsWith("user: ")) to it.substringAfter(": ") }
        val reply = retrying { direct.converse(hist, images, speakBack) }
        if (reply.isBlank()) { say("ما طلع عندي رد، جرّب مرة ثانية."); return }
        say(reply); remember("assistant: $reply"); if (speakBack) Voice.speak(reply)
    }

    private suspend fun generateImage(prompt: String) {
        status = "أولّد الصورة…"
        val r = MediaGen.image(appCtx, prompt, geminiKey) { p ->
            directBackend()?.let { d -> runCatching { d.ask("Translate the user's image description to a short, vivid English prompt. Return only the prompt.", p, 120) }.getOrNull() }
        }
        say("تفضل، هي صورتك.", listOf(Attachment(r.name, r.mime, r.file.absolutePath)))
        remember("assistant: [صورة مولّدة: ${prompt.take(60)}]")
    }

    private suspend fun generateVideo(prompt: String) {
        status = "أولّد الفيديو… (ممكن ياخد دقائق)"
        val r = MediaGen.video(appCtx, prompt, geminiKey) { status = it }
        say("تفضل، هذا الفيديو.", listOf(Attachment(r.name, r.mime, r.file.absolutePath)))
        remember("assistant: [فيديو مولّد: ${prompt.take(60)}]")
    }

    /** Called once the message is known to be a phone command: shows the notification controls and the floating panel. The cursor appears at the first action. */
    private fun beginPhoneWork() {
        phoneActive = true
        runCatching { ContextCompat.startForegroundService(appCtx, Intent(appCtx, OverlayService::class.java)) }
    }

    private suspend fun ask(q: String): Boolean {
        val d = CompletableDeferred<Boolean>(); confirmation = d; pendingConfirm = q
        val r = d.await(); pendingConfirm = null; return r
    }

    private fun validate(a: AgentAction, s: ScreenSnapshot): String? {
        if (a.type !in ALLOWED) return "unknown action type ${a.type}"
        if ((a.type == "click" || a.type == "set_text") && s.nodes.none { it.id == a.nodeId }) return "node ${a.nodeId} not on screen"
        if (a.type == "set_text" && a.text.isNullOrEmpty()) return "missing text"
        if (a.type == "send_file" && a.target.isNullOrBlank()) return "send_file needs target = app name"
        if (a.type == "voice_note" && (a.text.isNullOrBlank() || s.nodes.none { it.id == a.nodeId })) return "voice_note needs nodeId of the mic button on screen and text"
        if (a.type == "tap_at" && a.target?.split(",")?.size != 2) return "tap_at needs target \"x,y\""
        return null
    }

    private fun execute(svc: AgentAccessibilityService, a: AgentAction): ActionResult = when (a.type) {
        "open_app" -> {
            val target = a.target.orEmpty().trim()
            // Models may return a human app name ("Claude", "Chrome") instead of a package ID.
            val direct = if (target.contains('.') && !target.contains(' ')) svc.launchApp(target)
                else ActionResult(false, null, "not a package id")
            if (direct.dispatched) direct else {
                val resolved = AppResolver.find(appCtx, target, strict = false)
                if (resolved != null) svc.launchApp(resolved)
                else if (target.startsWith("https://", true) || target.startsWith("http://", true)) svc.openUrl(target)
                else ActionResult(false, null, "App '$target' is not installed or could not be matched. Try its website URL.")
            }
        }
        "open_url" -> svc.openUrl(a.target)
        "send_file" -> sendFile(svc, a)
        "click" -> svc.click(a.nodeId!!)
        "set_text" -> svc.setText(a.nodeId!!, a.text!!)
        "scroll" -> svc.scroll(a.text != "backward")
        "back" -> svc.back()
        "enter" -> svc.imeEnter()
        "home" -> svc.home()
        else -> { val p = a.target!!.split(","); svc.tapAt(p[0].trim().toFloatOrNull() ?: -1f, p[1].trim().toFloatOrNull() ?: -1f) }
    }

    private fun verifyAction(a: AgentAction, before: ScreenSnapshot, after: ScreenSnapshot): Boolean = when (a.type) {
        "set_text" -> after.nodes.any { it.text.contains(a.text.orEmpty()) }
        // Browsers often keep the same package while navigating to another URL/page.
        "open_app" -> after.pkg != before.pkg
        "voice_note" -> true
        "open_url" -> after.pkg != before.pkg || after.signature() != before.signature()
        else -> after.signature() != before.signature()
    }

    private fun cursorFor(a: AgentAction, s: ScreenSnapshot): Pair<Float, Float>? = when (a.type) {
        "click", "set_text", "voice_note" -> s.nodes.firstOrNull { it.id == a.nodeId }?.let { ((it.left + it.right) / 2f) to ((it.top + it.bottom) / 2f) }
        "scroll" -> s.nodes.firstOrNull { it.scrollable }?.let { ((it.left + it.right) / 2f) to ((it.top + it.bottom) / 2f) }
        "tap_at" -> a.target?.split(",")?.let { p ->
            val x = p.getOrNull(0)?.trim()?.toFloatOrNull(); val y = p.getOrNull(1)?.trim()?.toFloatOrNull()
            if (x != null && y != null) x to y else null
        }
        else -> null
    }

    /** Waits until the screen stops changing (lists load, animations end) before judging the result of an action. */
    private suspend fun settle(svc: AgentAccessibilityService, first: Long): ScreenSnapshot {
        if (first > 0) delay(first)
        var prev = snap(svc)
        repeat(4) {
            delay(250)
            val cur = snap(svc)
            if (cur.signature() == prev.signature()) return cur
            prev = cur
        }
        return prev
    }

    private suspend fun snap(svc: AgentAccessibilityService): ScreenSnapshot = withContext(Dispatchers.Default) { svc.snapshot() }

    private var note = ""
    private var voiceFails = 0
    private var voiceApproved = false
    private val LIVE_RE = Regex("go live|start live|live video|بث مباشر|ابدأ البث|بدء البث|canlı yayın", RegexOption.IGNORE_CASE)

    private fun digest(s: ScreenSnapshot): String =
        s.nodes.map { it.text.ifBlank { it.desc }.take(40) }.filter { it.isNotBlank() }.distinct().take(14).joinToString(" | ") { it.take(32) }

    /** Retries transient provider errors. Rate limits are already handled by switching models; this only covers short waits. */
    private suspend fun <T> retrying(block: suspend () -> T): T {
        var attempt = 0
        while (true) {
            try { return block() }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                val m = e.message.orEmpty()
                val limited = isRateLimit(m) || m.contains("503")
                val timeout = m.contains("timeout", true) || m.contains("timed out", true)
                if ((limited || timeout) && attempt < 5) {
                    attempt++
                    val hint = retryAfterMs(m)
                    if (hint != null && hint > 20_000L) {
                        if (hint >= 300_000L) TokenBudget.blockFor(hint)
                        throw IllegalStateException("كل النماذج والمفاتيح (${apiKeyList.size}) وصلت حدها المجاني. أقرب فتح بعد ${if (hint >= 90_000L) "${hint / 60_000} دقيقة" else "${hint / 1000} ثانية"}." + if (geminiKey.isBlank()) " أضف مفتاح Gemini المجاني، أو مفاتيح Groq من حسابات مختلفة، من الإعدادات." else "")
                    }
                    val wait = when { hint != null -> hint + 150L; timeout -> 300L; else -> 1200L * attempt }.coerceIn(300L, 8000L)
                    status = "إعادة المحاولة خلال ${wait / 100 / 10.0} ث"
                    delay(wait)
                } else throw e
            }
        }
    }

    private suspend fun runTask(goal: String) {
        val local = LocalBackend(appCtx, goal)
        val ai: AgentBackend? = when {
            apiKeyList.isNotEmpty() || geminiKey.isNotBlank() -> DirectBackend(aiBaseUrl, aiModel, apiKeyList, if (useVision) visionModel else "", geminiKey, provider, geminiModel) { aiModel = it }
            backendUrl.isNotBlank() -> HttpBackend(backendUrl, backendToken)
            else -> null
        }
        val backend: AgentBackend = if (ai != null && (useAi || !local.understood)) ai else local
        if (backend === ai) status = "أفكر…"
        val svc = service() ?: run { say("خدمة إمكانية الوصول غير مفعّلة. فعّلها من بطاقة الإعداد."); return }
        PURE_OPEN.matchEntire(goal.trim())?.groupValues?.get(1)?.trim()?.takeIf { !CONJ.containsMatchIn(it) }?.let { name ->
            val pkg = AppResolver.find(appCtx, name, strict = false)
            if (pkg != null && svc.launchApp(pkg).dispatched) { say("فتحت $name."); talk("فتحت $name"); return }
        }
        beginPhoneWork()
        talk(ACKS.random())
        val history = mutableListOf<String>()
        var invalid = 0
        var audits = 0
        note = ""
        var carry: ScreenSnapshot? = null   // the post-action snapshot doubles as the next step's screen (no second read)
        var wantLook = false
        var lastUnverified = false
        var justOpened = false
        var stuck = 0            // consecutive actions whose result could not be verified
        var repeats = 0          // same action proposed again and again
        var lastKey = ""
        var forceSmart = false
        var planText = ""
        var acted = false
        val recentKeys = java.util.ArrayDeque<String>()   // spots A-B-A-B loops
        var loops = 0
        val completed = mutableListOf<String>()           // sends/uploads already performed: never repeat
        val sentTexts = mutableSetOf<String>()
        var lastTyped = ""
        val attachNote = if (attachments.isEmpty()) "" else "\nATTACHED FILES: " + attachments.mapIndexed { i, f -> "${i + 1}) ${f.name} (${f.mime})" }.joinToString("; ")
        // One planning call with the smartest model, then the fast model only executes the plan.
        if (backend === ai && goal.length > 60) {   // short commands skip the extra planning call
            status = "أخطط للمهمة"
            val p = try { retrying { backend.plan(goal + attachNote) } } catch (e: CancellationException) { throw e } catch (e: Exception) { null }
            if (p != null) {
                planText = p.steps.mapIndexed { i, st -> "${i + 1}) $st" }.joinToString(" ; ")
                log("الخطة:\n" + p.steps.mapIndexed { i, st -> "${i + 1}. $st" }.joinToString("\n"))
                val app = p.firstApp
                if (app != null && AppResolver.find(appCtx, app) != null) {
                    status = "فتح $app"
                    // Opening the first app needs no model turn at all.
                    execute(svc, AgentAction(type = "open_app", target = app, reason = "فتح $app"))
                    delay(700)
                    carry = snap(svc)
                    justOpened = true
                    history += "open_app [$app] -> done before step 1 (first step of the plan). SYSTEM: the app may have restored an old state; ignore it unless it blocks the next step, never pause media. If the whole request was only to open this app, return done=true now."
                }
            }
        }
        for (step in 1..MAX_STEPS) {
            while (paused) delay(300)
            status = "الخطوة $step: قراءة الشاشة"
            val visionOn = backend === ai && useVision
            val c0 = carry; carry = null
            var shot: Shot? = null
            val base: ScreenSnapshot
            if (visionOn && (wantLook || lastUnverified || justOpened)) {
                // Read the tree and take the screenshot at the same time.
                val got = coroutineScope {
                    val sn = if (c0 == null) async { snap(svc) } else null
                    val sh = async { svc.screenshot() }
                    Pair(c0 ?: sn!!.await(), sh.await())
                }
                base = got.first; shot = got.second
            } else {
                base = c0 ?: snap(svc)
                // Sparse tree (canvas/webview app): the picture is the only way to read it.
                val labeled = base.nodes.count { it.text.isNotBlank() || it.desc.isNotBlank() }
                if (visionOn && labeled < 10) shot = svc.screenshot()
            }
            if (base.pkg == appCtx.packageName) shot = null
            justOpened = false
            val before = if (shot != null) base.copy(image = shot.b64, imgW = shot.w, imgH = shot.h) else base
            // Smart model only when the fast one is struggling (and the tree is readable); otherwise fast.
            val informative = before.nodes.count { it.text.isNotBlank() || it.desc.isNotBlank() } >= 10
            val smart = backend === ai && informative && (forceSmart || stuck >= 2 || repeats >= 2)
            forceSmart = false
            if (smart) {
                status = "الخطوة $step: أفكر بعمق"
                if (stuck >= 2 || repeats >= 2) history += "SYSTEM: earlier attempts did not work; choose a different approach (another element, scroll, back, or tap_at)."
            }
            val recent = history.takeLast(6).map { it.take(260) }
            val head = buildList {
                val ctx = convo.toList().dropLast(1).takeLast(6).joinToString(" | ")
                if (backend === ai && ctx.isNotBlank()) add("RECENT CHAT (context only): ${ctx.take(700)}")
                if (backend === ai && completed.isNotEmpty()) add("ALREADY DONE (never repeat, just verify and finish): " + completed.takeLast(5).joinToString(" ; "))
                if (backend === ai && attachNote.isNotBlank()) add(attachNote.trim().replace("ATTACHED FILES:", "ATTACHED FILES (deliver with send_file):"))
                if (planText.isNotBlank()) add("PLAN (fixed, follow in order): $planText")
                if (backend === ai && note.isNotBlank()) add("NOTES SO FAR: $note")
            }
            val hist = head + recent
            val reply = try { retrying { if (smart) backend.nextSmart(goal, hist, before) else backend.next(goal, hist, before) } }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                val m = e.message.orEmpty()
                if ((m.contains("JSON", true) || m.contains("did not return", true)) && ++invalid < 4) {
                    history += "SYSTEM: your previous reply was not valid JSON. Reply with exactly one JSON object and nothing else."
                    continue
                }
                say("خطأ: $m"); talk("صار عندي خطأ، جرّب مرة ثانية"); return
            }
            reply.note?.let { note = it }
            wantLook = reply.look
            val q = reply.askUser
            if (q != null) {
                reply.say?.let(::log)
                say(q)
                if (speakBack) Voice.speak(q) { if (backend === ai) bringAppToFront(svc) }
                if (backend !== ai) return
                // AI mode: wait for the person's answer in the chat, then continue the same task.
                val d = CompletableDeferred<String>(); answerDeferred = d
                awaitingAnswer = true; status = "بانتظار إجابتك"
                val ans = d.await()
                awaitingAnswer = false
                history += "asked the person: $q | they answered: $ans"
                continue
            }
            if (reply.done && backend === ai && audits < 1 && step <= 5 && planText.isNotBlank()) {
                audits++
                forceSmart = true
                history += "SYSTEM CHECK: you returned done. Re-read the ORIGINAL request and list every subgoal with the on-screen evidence that it really happened. If any subgoal is not verifiably finished, return the next action instead. Return done=true only if all are finished and visible."
                continue
            }
            if (reply.done && !acted) {   // plain conversation: the answer itself is the message
                val ans = reply.say?.takeIf { it.isNotBlank() }
                if (ans != null) { say(ans); remember("assistant: $ans"); if (speakBack) Voice.speak(ans) }
                return
            }
            if (reply.done) {
                val fin = reply.say?.takeIf { it.isNotBlank() } ?: "تم تنفيذ طلبك."
                say(fin); remember("assistant: $fin")
                talk(fin.takeIf { it.length <= 160 } ?: "تم")
                clearAttachments()
                return
            }
            reply.say?.let(::log)
            val a = reply.action ?: run { say("لم يرجع النموذج أي إجراء."); return }
            val err = validate(a, before)
            if (err != null) {
                history += "rejected action: $err. Valid node ids on this screen: 0..${before.nodes.size - 1}"
                stuck++
                if (++invalid >= 4) { say("توقفت: النموذج يقترح إجراءات غير صالحة باستمرار."); talk("ما قدرت أكمل المهمة"); return }
                continue
            }
            if (before.pkg == appCtx.packageName && a.type in setOf("click", "set_text", "scroll", "enter", "tap_at")) {
                history += "refused: this app's own window is in front, not the target app; open the target app first or wait"
                delay(800); continue
            }
            if (a.type == "wait") {
                delay((a.text?.toLongOrNull() ?: 1L).coerceIn(1L, 30L) * 1000)
                history += "waited ${a.text}s"
                log("الخطوة $step: ${a.reason.ifEmpty { "انتظار" }}")
                continue
            }
            val key = "${a.type}|${a.nodeId}|${a.text}|${a.target}"
            repeats = if (key == lastKey) repeats + 1 else 0
            lastKey = key
            if (a.type == "set_text" && a.text?.let { it in sentTexts } == true) {
                history += "refused: \"${a.text.orEmpty().take(40)}\" was already sent (see ALREADY DONE). Do not send it again; check the chat shows it and return done=true."
                stuck++; continue
            }
            recentKeys.addLast("${a.type}|${before.nodes.firstOrNull { it.id == a.nodeId }?.let { it.text + it.desc }.orEmpty().take(20)}|${a.text}|${a.target}")
            while (recentKeys.size > 9) recentKeys.removeFirst()
            val ks = recentKeys.toList()
            fun cycle(p: Int) = ks.size >= p * 3 && ks.takeLast(p * 3).toSet().size > 1 && (ks.size - p * 3 until ks.size - p).all { ks[it] == ks[it + p] }
            if (cycle(2) || cycle(3)) {
                recentKeys.clear()
                if (++loops >= 2) { say("توقفت: صرت أكرر نفس الخطوات بدون تقدّم. اشرح لي أين أنا أو جرّب أمرًا أدق."); talk("ما قدرت أكمل المهمة"); return }
                history += "SYSTEM: you are going in circles (the same actions again and again). Do not reopen anything. If a video player, popup or ad hides the controls you need, dismiss it or press back once, or jump with open_url; otherwise take the next FORWARD step. Never ask the user how to operate the UI; only ask for information you are missing."
                forceSmart = true; stuck++
                continue
            }
            val node = before.nodes.firstOrNull { it.id == a.nodeId }
            val label = node?.let { it.text + " " + it.desc }.orEmpty()
            if ((a.type == "click" || a.type == "tap_at") && LIVE_RE.containsMatchIn(label) && !LIVE_RE.containsMatchIn(goal)) {
                history += "SYSTEM: refused: never start a live stream, post, story or call unless the user asked. Press back to leave that screen. Messages/DMs are the paper-plane icon in the bottom bar (or the top right); open it and pick or search the person there."
                forceSmart = true
                continue
            }
            val sensitive = a.sensitive || a.type == "voice_note" || SENSITIVE.containsMatchIn(label + " " + (a.text ?: ""))
            if (sensitive && !(a.type == "voice_note" && voiceApproved)) {
                talk("بدي موافقتك قبل ما أكمل")
                if (!ask("يريد المساعد تنفيذ: ${a.type} ${label.trim()} ${a.text ?: ""}\nالسبب: ${a.reason}")) { say("تم إلغاء هذا الإجراء."); return }
                if (a.type == "voice_note") voiceApproved = true
            }
            status = "الخطوة $step: ${a.type}"
            cursorFor(a, before)?.let { (x, y) -> cursorX = x; cursorY = y; cursorVisible = true; delay(120) }
            acted = true
            val res = if (a.type == "voice_note") voiceNote(svc, a, before) else execute(svc, a)
            if (a.type == "voice_note") {
                if (res.dispatched) voiceFails = 0
                else if (++voiceFails >= 2) {
                    say("ما قدرت أسجّل الرسالة الصوتية: ${res.message}")
                    talk("ما قدرت أسجل الرسالة الصوتية")
                    return
                }
            }
            if (a.type == "click" || a.type == "tap_at" || a.type == "set_text") cursorClick++
            // Adaptive settle: short for taps, longer for app launches; re-read once before declaring "no change".
            var after = settle(svc, if (a.type == "open_app" || a.type == "open_url" || a.type == "send_file") 800L else 250L)
            var res2 = res
            var verified = verifyAction(a, before, after)
            if (!verified) { delay(500); after = settle(svc, 0L); verified = verifyAction(a, before, after) }
            var retried = ""
            if (!verified && a.type == "click" && !sensitive) {   // never re-tap a send/confirm button: it could fire twice
                cursorFor(a, before)?.let { (x, y) ->
                    res2 = svc.tapAt(x, y); cursorClick++; retried = " (retried with a coordinate tap)"
                    delay(600); after = snap(svc)
                    verified = verifyAction(a, before, after)
                }
            }
            if (!verified && a.type == "set_text") {
                res2 = svc.pasteText(a.nodeId!!, a.text!!); retried = " (retried with paste)"
                delay(700); after = snap(svc)
                verified = verifyAction(a, before, after)
            }
            if (a.type == "set_text") lastTyped = a.text.orEmpty()
            if (res2.dispatched && (a.type == "voice_note" || a.type == "send_file" || (sensitive && a.type in setOf("click", "tap_at", "enter")))) {
                completed += "step $step: ${a.type} ${label.trim().take(24)} ${(a.text ?: lastTyped).take(40)}".trim()
                if (lastTyped.isNotBlank() && SEND_LABEL.containsMatchIn(label)) { sentTexts += lastTyped; lastTyped = "" }
            }
            history += "${a.type} ${a.nodeId ?: ""} [${label.trim().take(30)}] -> dispatched=${res2.dispatched}, screenChanged/verified=$verified (${res2.message})$retried. Screen now: pkg=${after.pkg} :: ${digest(after)}"
            log("الخطوة $step: ${a.reason.ifEmpty { a.type }} — ${if (verified) "✓ تغيّرت الشاشة" else "✗ لم أتحقق من النتيجة"}")
            if (a.type == "set_text" && a.thenEnter && verified) {
                val r3 = execute(svc, AgentAction(type = "enter", reason = "Enter"))
                cursorClick++
                delay(600)
                after = snap(svc)
                history += "enter -> dispatched=${r3.dispatched} (chained right after set_text). Screen now: pkg=${after.pkg} :: ${digest(after)}"
            }
            if (a.type == "open_app" || a.type == "open_url")
                history += "SYSTEM: the app was just opened and may have restored an old state. Ignore it unless it blocks the next step; do not pause media; never press back out of the app. If the whole request was only to open this app, return done=true now."
            if (!res2.dispatched) history += "action failed; choose a different approach or ask the user"
            stuck = if (verified) 0 else stuck + 1
            lastUnverified = !verified
            justOpened = a.type == "open_app" || a.type == "open_url"
            carry = after
        }
        say("توقفت بعد $MAX_STEPS خطوة دون إنهاء المهمة."); talk("ما قدرت أكمل المهمة")
    }

    /** Built-in test: opens system Settings, scrolls, and verifies the screen changed. No AI involved. */
    private suspend fun selfTest() {
        val svc = service() ?: run { say("Enable the accessibility service first."); return }
        status = "Self-test"
        say("Self-test: opening system Settings, scrolling once, checking whether the screen changed.")
        val open = svc.startIntent(Intent(Settings.ACTION_SETTINGS))
        if (!open.dispatched) { say("Could not open Settings: ${open.message}"); return }
        delay(1800)
        val before = snap(svc)
        say("Observed package '${before.pkg}' with ${before.nodes.size} visible nodes. ${before.note}")
        val r = svc.scroll(true)
        delay(900)
        val after = snap(svc)
        val changed = after.signature() != before.signature()
        say("Scroll dispatched: ${r.dispatched} (${r.message}). Screen changed: $changed." +
            if (!changed) " Unverified: the page may fit on one screen or expose no scrollable node." else " Verified.")
    }
}
