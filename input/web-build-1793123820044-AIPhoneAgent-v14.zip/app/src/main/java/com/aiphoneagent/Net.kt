package com.aiphoneagent

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Live internet state. [online] is false when the phone has no network with real internet access. */
object Net {
    var online by mutableStateOf(true)
        private set
    private var cm: ConnectivityManager? = null
    private var started = false

    private fun check(): Boolean {
        val m = cm ?: return true
        val c = m.getNetworkCapabilities(m.activeNetwork) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun init(ctx: Context) {
        if (started) return
        started = true
        val m = ctx.applicationContext.getSystemService(ConnectivityManager::class.java) ?: return
        cm = m
        online = check()
        runCatching {
            m.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { online = check() }
                override fun onLost(network: Network) { online = check() }
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { online = check() }
            })
        }
    }
}
