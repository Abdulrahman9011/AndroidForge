package com.aiphoneagent

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicInteger

/**
 * Keeps long jobs (app builds, downloads) alive while the app is in the background: a foreground service with a live
 * notification and a CPU wake lock. Several jobs can share it; it stops when the last one ends.
 */
class JobService : Service() {
    companion object {
        private const val CH = "agent_jobs"
        private const val CH_DONE = "agent_done"
        private const val NID = 61
        private const val NID_DONE = 62
        private val count = AtomicInteger(0)
        @Volatile private var title = "AI Phone Agent"
        @Volatile private var text = ""
        @Volatile private var lastPost = 0L

        private fun channels(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "مهام جارية", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_DONE, "نتائج المهام", NotificationManager.IMPORTANCE_DEFAULT))
        }

        private fun open(ctx: Context) = PendingIntent.getActivity(ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        private fun build(ctx: Context): Notification {
            channels(ctx)
            return NotificationCompat.Builder(ctx, CH).setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(title).setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open(ctx)).build()
        }

        private fun post(ctx: Context) {
            runCatching { ctx.getSystemService(NotificationManager::class.java).notify(NID, build(ctx)) }
        }

        fun begin(ctx: Context, t: String, s: String) {
            title = t; text = s
            if (count.getAndIncrement() == 0) runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, JobService::class.java)) }
            else post(ctx)
        }

        fun update(ctx: Context, s: String) {
            text = s
            val now = SystemClock.elapsedRealtime()
            if (now - lastPost > 1500L) { lastPost = now; post(ctx) }
        }

        fun end(ctx: Context) {
            if (count.decrementAndGet() <= 0) { count.set(0); ctx.stopService(Intent(ctx, JobService::class.java)) }
        }

        /** A normal (dismissable) notification with the result, tappable to return to the app. */
        fun done(ctx: Context, t: String, s: String) {
            runCatching {
                channels(ctx)
                val n = NotificationCompat.Builder(ctx, CH_DONE).setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle(t).setContentText(s).setStyle(NotificationCompat.BigTextStyle().bigText(s))
                    .setAutoCancel(true).setContentIntent(open(ctx)).build()
                ctx.getSystemService(NotificationManager::class.java).notify(NID_DONE, n)
            }
        }
    }

    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = build(this)
        if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(NID, n)
        if (wl == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aiagent:job").also { it.acquire(40 * 60 * 1000L) }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        wl?.let { if (it.isHeld) it.release() }
        wl = null
        super.onDestroy()
    }
}
