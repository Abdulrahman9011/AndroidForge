package com.aiphoneagent

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** /image and /video: generated files are kept in filesDir/media (shown in the chat) and copied to the gallery. */
object MediaGen {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    const val IMAGE_MODEL = "gemini-3.1-flash-image"
    private const val IMAGE_MODEL_OLD = "gemini-2.5-flash-image"
    const val VIDEO_MODEL = "veo-3.1-generate-preview"

    class Result(val file: File, val mime: String, val name: String)

    private fun mediaDir(ctx: Context) = File(ctx.filesDir, "media").apply { mkdirs() }

    private fun http(url: String, key: String, body: String?, readMs: Int): Pair<Int, ByteArray> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000; c.readTimeout = readMs; c.instanceFollowRedirects = true
        if (key.isNotBlank()) c.setRequestProperty("x-goog-api-key", key)
        if (body != null) {
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val bytes = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes() } ?: ByteArray(0)
        c.disconnect()
        return code to bytes
    }

    /** Saves a copy in Pictures/Movies so it also shows up in the phone gallery. */
    private fun toGallery(ctx: Context, f: File, mime: String) {
        if (Build.VERSION.SDK_INT < 29) return
        runCatching {
            val video = mime.startsWith("video")
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, f.name); put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, (if (video) "Movies/" else "Pictures/") + "AIPhoneAgent")
            }
            val uri = ctx.contentResolver.insert(if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
            ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
        }
    }

    /** Gemini image model when a Gemini key exists; otherwise (or if it refuses) a free keyless service. */
    suspend fun image(ctx: Context, prompt: String, geminiKey: String, translate: suspend (String) -> String?): Result = withContext(Dispatchers.IO) {
        var geminiError = ""
        if (geminiKey.isNotBlank()) {
            // Current image model first; the old 2.5 one only as a fallback (Google may answer 404 for it on new keys).
            for (model in listOf(IMAGE_MODEL, IMAGE_MODEL_OLD)) {
                try {
                    val body = JSONObject()
                        .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                        .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
                    val (code, bytes) = http("$BASE/models/$model:generateContent", geminiKey, body.toString(), 90_000)
                    val txt = String(bytes)
                    if (code in 200..299) {
                        val parts = JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                        for (i in 0 until parts.length()) {
                            val p = parts.getJSONObject(i)
                            val inl = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data") ?: continue
                            val data = Base64.decode(inl.getString("data"), Base64.DEFAULT)
                            val mime = inl.optString("mimeType", inl.optString("mime_type", "image/png"))
                            val f = File(mediaDir(ctx), "img_${System.currentTimeMillis()}." + (if (mime.contains("jpeg")) "jpg" else "png"))
                            f.writeBytes(data); toGallery(ctx, f, mime)
                            return@withContext Result(f, mime, f.name)
                        }
                        geminiError = "Gemini ما رجّع صورة"
                        break
                    } else {
                        geminiError = "Gemini: HTTP $code " + txt.take(160)
                        if (code != 404 && code != 400) break      // quota / key problems: the other model would fail the same way
                    }
                } catch (e: kotlinx.coroutines.CancellationException) { throw e
                } catch (e: Exception) { geminiError = "Gemini: " + (e.message ?: ""); break }
            }
        }
        // Free fallback (no key). Works best with English prompts, so the text is translated first.
        val en = runCatching { translate(prompt) }.getOrNull()?.takeIf { it.isNotBlank() } ?: prompt
        val url = "https://image.pollinations.ai/prompt/" + URLEncoder.encode(en.take(600), "UTF-8") + "?width=1024&height=1024&nologo=true&seed=" + (System.currentTimeMillis() % 100000)
        val (code, bytes) = http(url, "", null, 120_000)
        if (code !in 200..299 || bytes.size < 2000) throw IllegalStateException("تعذّر توليد الصورة" + (if (geminiError.isNotBlank()) " ($geminiError)" else "") + " — الخدمة المجانية رجّعت HTTP $code")
        val f = File(mediaDir(ctx), "img_${System.currentTimeMillis()}.jpg")
        f.writeBytes(bytes); toGallery(ctx, f, "image/jpeg")
        Result(f, "image/jpeg", f.name)
    }

    /** Veo through the Gemini API. It is a paid feature of Google's API: a free key usually answers with an error, which is shown as is. */
    suspend fun video(ctx: Context, prompt: String, geminiKey: String, onStatus: (String) -> Unit): Result = withContext(Dispatchers.IO) {
        if (geminiKey.isBlank()) throw IllegalStateException("توليد الفيديو يحتاج مفتاح Gemini (من الإعدادات).")
        val body = JSONObject().put("instances", JSONArray().put(JSONObject().put("prompt", prompt)))
        val (code, bytes) = http("$BASE/models/$VIDEO_MODEL:predictLongRunning", geminiKey, body.toString(), 60_000)
        val txt = String(bytes)
        if (code !in 200..299) throw IllegalStateException("رفض Google توليد الفيديو (HTTP $code): " + txt.take(220))
        val op = JSONObject(txt).getString("name")
        var uri: String? = null
        for (i in 1..60) {                       // up to ~10 minutes
            delay(10_000)
            onStatus("أولّد الفيديو… ${i * 10} ث")
            val (c2, b2) = http("$BASE/$op", geminiKey, null, 30_000)
            if (c2 !in 200..299) continue
            val j = JSONObject(String(b2))
            if (!j.optBoolean("done")) continue
            j.optJSONObject("error")?.let { throw IllegalStateException("فشل توليد الفيديو: " + it.optString("message")) }
            uri = j.getJSONObject("response").getJSONObject("generateVideoResponse").getJSONArray("generatedSamples")
                .getJSONObject(0).getJSONObject("video").getString("uri")
            break
        }
        if (uri == null) throw IllegalStateException("انتهى الوقت قبل ما يجهز الفيديو.")
        onStatus("أنزّل الفيديو…")
        val (c3, vb) = http(uri, geminiKey, null, 180_000)
        if (c3 !in 200..299 || vb.size < 5000) throw IllegalStateException("تعذّر تنزيل الفيديو (HTTP $c3)")
        val f = File(mediaDir(ctx), "vid_${System.currentTimeMillis()}.mp4")
        f.writeBytes(vb); toGallery(ctx, f, "video/mp4")
        Result(f, "video/mp4", f.name)
    }
}
