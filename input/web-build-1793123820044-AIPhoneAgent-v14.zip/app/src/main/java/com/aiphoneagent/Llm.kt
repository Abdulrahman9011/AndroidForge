package com.aiphoneagent

import android.content.Context
import android.net.Uri
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Optional on-device model (MediaPipe LLM Inference). It is used ONLY to translate a free-form sentence
 * into the app's step commands; execution, waiting, verification and confirmations stay deterministic.
 * Expects a Gemma-style instruction-tuned .task model chosen by the user in Settings.
 */
object LlmPlanner {
    private lateinit var appCtx: Context
    @Volatile private var llm: LlmInference? = null

    fun init(c: Context) { appCtx = c.applicationContext }
    private fun file() = File(appCtx.filesDir, "model.task")
    fun isReady() = ::appCtx.isInitialized && file().exists()
    fun sizeMb(): Long = if (isReady()) file().length() / (1024 * 1024) else 0L
    fun deleteModel() { runCatching { llm?.close() }; llm = null; if (::appCtx.isInitialized) file().delete() }

    suspend fun importModel(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            runCatching { llm?.close() }; llm = null
            val tmp = File(appCtx.filesDir, "model.tmp")
            appCtx.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 1 shl 20) } }
            file().delete()
            tmp.renameTo(file())
        }.getOrDefault(false)
    }

    private fun prompt(sentence: String) = """<start_of_turn>user
You translate a phone command (Arabic or English) into steps. Output ONLY lines from this list, one per line, nothing else:
open: <app name>
search: <text>
tap: <button or label text>
type: <text>
scroll: down <times>   (or: scroll: up <times>)
nth: <number>
back
home
wait: <seconds>

Command: ادخل على يوتيوب وابحث عن طبخ المعكرونة وافتح الثاني
open: YouTube
search: طبخ المعكرونة
nth: 2

Command: open settings and scroll down 3 times
open: Settings
scroll: down 3

Command: ارجع ثم انزل مرتين
back
scroll: down 2

Command: $sentence<end_of_turn>
<start_of_turn>model
"""

    /** Returns the model's output lines, or null if the model failed to load or run. Can take tens of seconds on a mid-range phone. */
    suspend fun translate(sentence: String): List<String>? = withContext(Dispatchers.Default) {
        runCatching {
            val m = llm ?: LlmInference.createFromOptions(appCtx,
                LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(file().absolutePath).setMaxTokens(1024).build()).also { llm = it }
            m.generateResponse(prompt(sentence)).lines().map { it.trim().trimStart('-', '*', ' ') }.filter { it.isNotEmpty() }
        }.getOrNull()
    }

    fun toSteps(lines: List<String>): MutableList<Step>? {
        val out = mutableListOf<Step>()
        for (l in lines) {
            if (l.startsWith("Command:", true)) break
            val k = l.substringBefore(':').trim().lowercase()
            val v = l.substringAfter(':', "").trim()
            val n = v.filter { it.isDigit() }.toIntOrNull()
            when {
                k == "open" && v.isNotEmpty() -> out += Step.Open(v)
                k == "search" && v.isNotEmpty() -> out += Step.Search(v)
                k == "tap" && v.isNotEmpty() -> out += Step.Tap(listOf(v))
                k == "type" && v.isNotEmpty() -> out += Step.Type(v)
                k == "nth" && n != null -> out += Step.Nth(n)
                k == "wait" -> out += Step.Wait(n ?: 2)
                k == "scroll" -> out += Step.Scroll(!v.lowercase().startsWith("up"), (n ?: 1).coerceIn(1, 20))
                k == "back" -> out += Step.Back
                k == "home" -> out += Step.Home
            }
        }
        return out.takeIf { it.isNotEmpty() }
    }
}
