package com.aiphoneagent

import android.content.Context
import android.content.Intent
import android.content.res.Resources

/** Arabic/English text normalisation. Mapping is 1:1 per character so indices stay aligned. */
object Norm {
    private val TASHKEEL = Regex("[\\u064B-\\u065F\\u0670\\u0640]")
    private val SPACES = Regex("\\s+")
    private val AR = mapOf('ب' to "b", 'ت' to "t", 'ث' to "t", 'ج' to "j", 'ح' to "h", 'خ' to "k", 'د' to "d", 'ذ' to "d",
        'ر' to "r", 'ز' to "z", 'س' to "s", 'ش' to "s", 'ص' to "s", 'ض' to "d", 'ط' to "t", 'ظ' to "z", 'غ' to "g",
        'ف' to "f", 'ق' to "k", 'ك' to "k", 'ل' to "l", 'م' to "m", 'ن' to "n", 'ه' to "h", 'پ' to "b", 'ڤ' to "f", 'چ' to "j")
    fun clean(s: String) = TASHKEEL.replace(s, "")
    fun map(s: String): String = buildString(s.length) {
        s.forEach { ch -> append(when (ch) { 'أ', 'إ', 'آ', 'ٱ' -> 'ا'; 'ة' -> 'ه'; 'ى' -> 'ي'; else -> ch }) }
    }
    fun key(s: String) = SPACES.replace(map(clean(s)).lowercase(), " ").trim()

    /** Consonant skeleton comparable across Arabic and English spelling (تيك توك ~ TikTok). */
    fun sk(s: String): String {
        val t = map(clean(s)).lowercase().replace("ph", "f").replace("ck", "k").replace("x", "ks")
            .replace("q", "k").replace("c", "k").replace("p", "b").replace("v", "f")
        val out = StringBuilder()
        for (ch in t) {
            val m = AR[ch] ?: if (ch in 'a'..'z' && ch !in "aeiouyw") ch.toString() else null
            if (m != null && (out.isEmpty() || out.last() != m[0])) out.append(m)
        }
        return out.toString()
    }
    /** Arabic skeleton without long vowels, for fuzzy verb matching. */
    fun arSk(s: String) = map(clean(s)).filter { it !in "اويىءئؤة" }

    fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val t = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = t
            }
        }
        return d[b.length]
    }
    fun similarity(a: String, b: String): Double = if (a.isEmpty() && b.isEmpty()) 1.0 else 1.0 - lev(a, b).toDouble() / maxOf(a.length, b.length)
}

object AppResolver {
    private val alias = mapOf(
        "روبلوكس" to "roblox", "يوتيوب" to "youtube", "واتساب" to "whatsapp", "كروم" to "chrome",
        "الاعدادات" to "settings", "اعدادات" to "settings", "الكاميره" to "camera", "كاميره" to "camera",
        "انستغرام" to "instagram", "انستا" to "instagram", "فيسبوك" to "facebook",
        "تلغرام" to "telegram", "سناب" to "snapchat", "خرائط" to "maps", "الصور" to "photos",
        "ماسنجر" to "messenger", "ديسكورد" to "discord", "سبوتيفاي" to "spotify", "جوجل" to "google"
    )
    private val filler = setOf("على", "الي", "ع", "في", "تطبيق", "برنامج", "app", "the")

    private val extra = mapOf(
        "ملاحظات" to listOf("notes", "note", "keep", "ملاحظات"),
        "الملاحظات" to listOf("notes", "note", "keep", "ملاحظات"),
        "مذكرات" to listOf("notes", "note", "keep"),
        "جنسبارك" to listOf("genspark")
    )

    /** Package of an installed launcher app matching [name]. strict=true accepts only alias/exact/same-skeleton matches. */
    fun find(ctx: Context, name: String, strict: Boolean = false): String? {
        val raw = Norm.key(name).split(" ").dropWhile { it in filler }.joinToString(" ")
        if (raw.isEmpty()) return null
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Norm.key(it.loadLabel(pm).toString()) to it.activityInfo.packageName }
        val cands = (listOfNotNull(alias[raw]) + (extra[raw] ?: emptyList()) + raw).distinct()
        for (q in cands) findOne(apps, q, strict)?.let { return it }
        return null
    }

    private fun findOne(apps: List<Pair<String, String>>, q: String, strict: Boolean): String? {
        fun best(ok: (String, String) -> Boolean) = apps.filter { ok(it.first, it.second) }.minByOrNull { it.first.length }?.second
        best { l, _ -> l == q }?.let { return it }
        val qs = Norm.sk(q)
        if (qs.isNotEmpty()) best { l, _ -> Norm.sk(l) == qs }?.let { return it }
        if (strict) return null
        best { l, _ -> l.contains(q) }?.let { return it }
        best { _, p -> p.lowercase().contains(q.replace(" ", "")) }?.let { return it }
        if (qs.length >= 3) {
            best { l, _ -> Norm.sk(l).contains(qs) }?.let { return it }
            apps.map { it to Norm.similarity(Norm.sk(it.first), qs) }.filter { it.second >= 0.75 }
                .maxByOrNull { it.second }?.let { return it.first.second }
        }
        return null
    }
}

sealed class Step {
    data class Open(val app: String) : Step()
    data class Search(val q: String, var stage: Int = 0, var tries: Int = 0) : Step()
    data class Tap(val labels: List<String>, var tries: Int = 0) : Step()
    data class Nth(val n: Int) : Step()
    data class Pct(val x: Int, val y: Int) : Step()
    data class Type(val text: String) : Step()
    data class Scroll(val forward: Boolean, var times: Int) : Step()
    object Back : Step()
    object Home : Step()
    data class Wait(val sec: Int) : Step()
}

class Plan(val steps: MutableList<Step>, val unknown: List<String>)

/** Rule-based command parser (no AI). Understands a fixed set of Arabic/English commands joined by "ثم", "و", commas, "then". */
object LocalPlanner {
    private const val V = "افتح|ابحث|اضغط|انقر|اكتب|انزل|مرر|ارجع|انتظر|ادخل|فوت|فيت|العب|اطلع|رجوع|open|search|tap|click|type|scroll|back|wait|play|go"
    private val SPLIT = Regex(
        "\\s*[،,;\\n]\\s*|\\s+(?:ثم|وبعدين|بعدين|بعد ذلك|بعدها|and then|then)\\s+|\\s+(?:و|and\\s+)(?=(?:$V))",
        RegexOption.IGNORE_CASE)
    private val I = RegexOption.IGNORE_CASE
    private val R_BACK = Regex("^(?:ارجع|رجوع|للخلف|back|go back)$", I)
    private val R_HOME = Regex("^(?:الرئيسيه|الشاشه الرئيسيه|home|go home)$", I)
    private val R_WAIT = Regex("^(?:انتظر|استنى|wait)\\s*(\\d+)?\\s*(?:ثانيه|ثواني|sec|seconds|s)?$", I)
    private val R_SCROLL = Regex("^(?:(انزل|مرر لتحت|مرر للاسفل|scroll down|down)|(اطلع|مرر لفوق|مرر للاعلى|scroll up|up))\\s*(\\d+)?(?:\\s*(?:مره|مرات|times|x))?$", I)
    private val R_PCT = Regex("^(?:اضغط|انقر|tap|click)\\s*(?:(?:عند|على|at)\\s+)?(\\d{1,3})\\s*%\\s*[, ]\\s*(\\d{1,3})\\s*%$", I)
    private val ORD = mapOf("اول" to 1, "الاول" to 1, "first" to 1, "ثاني" to 2, "الثاني" to 2, "second" to 2, "ثالث" to 3, "الثالث" to 3, "third" to 3, "رابع" to 4, "الرابع" to 4, "fourth" to 4, "خامس" to 5, "الخامس" to 5, "fifth" to 5)
    private val R_NTH = Regex("^(?:افتح|اضغط|انقر|شغل|open|tap|click|play)\\s*(?:(?:على|علي|ع)\\s+)?(اول|الاول|ثاني|الثاني|ثالث|الثالث|رابع|الرابع|خامس|الخامس|first|second|third|fourth|fifth|\\d)\\s*(?:نتيجه|فيديو|واحد|result|video|one)?$", I)
    private val VERBS = listOf("افتح", "ابحث", "اضغط", "انقر", "اكتب", "انزل", "مرر", "ارجع", "انتظر", "ادخل", "شغل", "روح", "العب", "اطلع", "دوس", "كبس", "دور")
    private val R_GAME = Regex("^(?:ادخل|فوت|فيت|دخول|دخلني|روح|افتح|العب|شغل)\\s*(?:(?:الي|على|ع|ل)\\s+)?(?:لعبه|game)\\s+(.+)$", I)
    private val R_SEARCH = Regex("^(?:ابحث|دور|بحث|search)\\s*(?:(?:عن|for|about)\\s+)?(.+?)(?:\\s+(?:في|على|on|in)\\s+(.+))?$", I)
    private val R_TYPE = Regex("^(?:اكتب|type|write)\\s+(.+)$", I)
    private val R_TAP = Regex("^(?:اضغط|انقر|كبس|دوس|tap|click|press)\\s*(?:(?:على|علي|ع|on)\\s+)?(.+)$", I)
    private val R_OPEN = Regex("^(?:افتح|شغل|روح الي|ادخل الي|ادخل على|ادخل|فوت على|فوت|فيت على|فيت|دخول على|دخول|روح|open|launch|start|go to)\\s*(?:(?:الي|على|ع)\\s+)?(?:(?:تطبيق|app)\\s+)?(.+)$", I)

    /** Fixes a misspelled leading verb (e.g. دخزل -> ادخل) by comparing consonant skeletons. */
    private fun fixVerb(o: String, n: String): Pair<String, String> {
        val sp = n.indexOf(' ')
        if (sp <= 0) return o to n
        val first = n.substring(0, sp)
        if (first.length < 3 || first.any { it in 'a'..'z' || it in 'A'..'Z' }) return o to n
        if (VERBS.any { Norm.map(it) == first }) return o to n
        val fs = Norm.arSk(first)
        val hit = VERBS.firstOrNull { v -> val vs = Norm.arSk(v); vs.length >= 3 && fs.length >= 3 && Norm.lev(fs, vs) <= 1 } ?: return o to n
        val vk = Norm.map(hit)
        return (vk + o.substring(sp)) to (vk + n.substring(sp))
    }

    private fun g(m: MatchResult, i: Int, o: String): String? =
        m.groups[i]?.let { o.substring(it.range) }?.trim()?.trimEnd('.', '!', '؟', '?')

    fun parse(input: String, isApp: (String) -> Boolean = { false }): Plan {
        val orig = Norm.clean(input).trim()
        val norm = Norm.map(orig)
        val ranges = mutableListOf<IntRange>()
        var start = 0
        SPLIT.findAll(norm).forEach { m ->
            if (m.range.first > start) ranges += start until m.range.first
            start = m.range.last + 1
        }
        if (start < norm.length) ranges += start until norm.length

        val steps = mutableListOf<Step>()
        val unknown = mutableListOf<String>()
        var robloxOpened = false
        for (r in ranges) {
            val o0 = orig.substring(r).trim(); val n0 = norm.substring(r).trim()
            if (n0.isEmpty()) continue
            val (o, n) = fixVerb(o0, n0)
            var m: MatchResult?
            if (R_BACK.matchEntire(n) != null) { steps += Step.Back; continue }
            if (R_HOME.matchEntire(n) != null) { steps += Step.Home; continue }
            val mWait = R_WAIT.matchEntire(n)
            if (mWait != null) { steps += Step.Wait(g(mWait, 1, o)?.toIntOrNull() ?: 2); continue }
            val mScroll = R_SCROLL.matchEntire(n)
            if (mScroll != null) { steps += Step.Scroll(mScroll.groups[1] != null, (g(mScroll, 3, o)?.toIntOrNull() ?: 1).coerceIn(1, 20)); continue }
            val mPct = R_PCT.matchEntire(n)
            if (mPct != null) { steps += Step.Pct(g(mPct, 1, o)!!.toInt().coerceIn(0, 100), g(mPct, 2, o)!!.toInt().coerceIn(0, 100)); continue }
            val mNth = R_NTH.matchEntire(n)
            if (mNth != null) { val w = Norm.key(g(mNth, 1, o)!!); steps += Step.Nth(ORD[w] ?: w.toIntOrNull() ?: 1); continue }
            m = R_GAME.matchEntire(n)
            if (m != null) {
                val game = g(m, 1, o)!!
                if (!robloxOpened) { steps += Step.Open("roblox"); steps += Step.Wait(4); robloxOpened = true }
                steps += Step.Search(game); steps += Step.Wait(3)
                steps += Step.Tap(listOf(game)); steps += Step.Wait(4)
                steps += Step.Tap(listOf("play", "العب", "لعب"))
                continue
            }
            m = R_SEARCH.matchEntire(n)
            if (m != null) {
                g(m, 2, o)?.let { app -> steps += Step.Open(app); steps += Step.Wait(3) }
                steps += Step.Search(g(m, 1, o)!!)
                continue
            }
            m = R_TYPE.matchEntire(n)
            if (m != null) { steps += Step.Type(g(m, 1, o)!!); continue }
            m = R_TAP.matchEntire(n)
            if (m != null) { steps += Step.Tap(listOf(g(m, 1, o)!!)); continue }
            m = R_OPEN.matchEntire(n)
            if (m != null) {
                val app = g(m, 1, o)!!
                if (Norm.key(app).let { it.contains("roblox") || it.contains("روبلوكس") }) robloxOpened = true
                steps += Step.Open(app)
                continue
            }
            // A bare app name, possibly with filler words (e.g. "على يوتيوب", "Tiktok") means "open it".
            val nt = n.split(Regex("\\s+")); val ot = o.split(Regex("\\s+"))
            var asApp = false
            if (nt.size <= 4) for (k in 0..minOf(2, nt.size - 1)) {
                val cand = ot.drop(k).joinToString(" ")
                if (isApp(cand)) { steps += Step.Open(cand); asApp = true; break }
            }
            if (!asApp) unknown += o
        }
        return Plan(steps, unknown)
    }
}

/** Executes a parsed plan one action per call, reading the live screen to resolve targets. No network, no AI. */
class LocalBackend(private val ctx: Context, goal: String) : AgentBackend {
    private var plan = LocalPlanner.parse(goal) { AppResolver.find(ctx, it, strict = true) != null }
    private var steps = plan.steps
    private var llmPlan = false
    private var pendingSay: String? = null
    private var i = 0
    private var announced = false
    private var expectedPkg: String? = null
    private var pkgWaits = 0
    private var lastType = ""
    private var lastReason = ""
    private val dm get() = Resources.getSystem().displayMetrics

    /** True when every part of the sentence matched a known command. */
    val understood: Boolean get() = plan.unknown.isEmpty() && plan.steps.isNotEmpty()

    private fun act(a: AgentAction): BackendReply { lastType = a.type; lastReason = a.reason; return BackendReply(a, pendingSay.also { pendingSay = null }) }
    private fun ask(q: String) = BackendReply(null, null, false, q)
    private fun label(n: UiNode) = n.text.ifBlank { n.desc }
    private fun describe(s: ScreenSnapshot) =
        s.nodes.map { label(it) }.filter { it.isNotBlank() }.distinct().take(8).joinToString(" | ").ifEmpty { "لا نص ظاهر" }

    private fun findNode(s: ScreenSnapshot, labels: List<String>): UiNode? {
        val keys = labels.map { Norm.key(it) }.filter { it.isNotEmpty() }
        val c = s.nodes.filter { !it.editable && keys.any { k -> Norm.key(it.text + " " + it.desc).contains(k) } }
        return c.firstOrNull { it.clickable } ?: c.firstOrNull()
    }

    override suspend fun next(goal: String, history: List<String>, screen: ScreenSnapshot): BackendReply {
        if (!announced) {
            announced = true
            if (!understood && LlmPlanner.isReady()) {
                AgentController.status = "النموذج المحلي يحلّل الأمر…"
                val st = LlmPlanner.translate(goal)?.let { LlmPlanner.toSteps(it) }
                if (!st.isNullOrEmpty()) { steps = st; llmPlan = true; pendingSay = "فهمتُ الأمر بالنموذج المحلي (${st.size} خطوات)." }
            }
            if (!llmPlan && !understood)
                return ask("ما فهمت: «${plan.unknown.joinToString(" | ").ifEmpty { goal }}». أمثلة: افتح يوتيوب ثم ابحث عن X ثم اضغط على Y — انزل 3 مرات — ارجع. (لفهم أي جملة حرة ثبّت نموذجاً محلياً من Settings أو أضف مفتاح AI.)")
        }
        if ((lastType == "click" || lastType == "set_text") && history.lastOrNull()?.contains("verified=false") == true) {
            val why = lastReason; lastType = ""
            return ask("لم أتحقق من نجاح «$why» (الشاشة لم تتغير). الظاهر الآن: ${describe(screen)}")
        }
        val step = steps.getOrNull(i)
            ?: return BackendReply(null, "انتهت كل الخطوات. تحقق من الشاشة للتأكد من النتيجة، فأنا لا أستطيع الجزم بها.", done = true)

        // Never act on this app's own window: wait until the target app is really in front.
        if (step !is Step.Open && step !is Step.Wait && step !is Step.Home && step !is Step.Back) {
            val pkgOk = screen.pkg.isNotEmpty() && screen.pkg != ctx.packageName
            val matches = expectedPkg == null || screen.pkg == expectedPkg
            if (pkgOk && (matches || pkgWaits >= 12)) { pkgWaits = 0; expectedPkg = null }
            else if (pkgWaits < 14) { pkgWaits++; return act(AgentAction("wait", text = "1", reason = "انتظار ظهور التطبيق")) }
            else return ask("التطبيق المطلوب ليس في المقدمة (الظاهر: ${screen.pkg.ifEmpty { "لا شيء" }}). ابدأ الأمر بـ «افتح ...» أو افتح التطبيق بنفسك ثم أعد الأمر.")
        }

        return when (step) {
            is Step.Open -> {
                val pkg = AppResolver.find(ctx, step.app) ?: return ask("ما لقيت تطبيقاً باسم «${step.app}» على الهاتف.")
                i++; expectedPkg = pkg; pkgWaits = 0
                if (steps.getOrNull(i) !is Step.Wait) steps.add(i, Step.Wait(2))
                act(AgentAction("open_app", target = pkg, reason = "فتح ${step.app}"))
            }
            is Step.Wait -> { i++; act(AgentAction("wait", text = step.sec.toString(), reason = "انتظار ${step.sec} ثانية")) }
            is Step.Back -> { i++; act(AgentAction("back", reason = "رجوع")) }
            is Step.Home -> { i++; act(AgentAction("home", reason = "الشاشة الرئيسية")) }
            is Step.Scroll -> {
                if (step.times <= 1) i++ else step.times--
                act(AgentAction("scroll", text = if (step.forward) "forward" else "backward", reason = if (step.forward) "تمرير لأسفل" else "تمرير لأعلى"))
            }
            is Step.Pct -> {
                i++
                act(AgentAction("tap_at", target = "${dm.widthPixels * step.x / 100f},${dm.heightPixels * step.y / 100f}", reason = "ضغط عند ${step.x}% ${step.y}%"))
            }
            is Step.Type -> {
                val ed = screen.nodes.firstOrNull { it.editable } ?: return ask("ما لقيت خانة كتابة على الشاشة.")
                i++
                act(AgentAction("set_text", nodeId = ed.id, text = step.text, reason = "كتابة النص"))
            }
            is Step.Nth -> {
                val top = dm.heightPixels * 0.15
                val cands = screen.nodes.filter { it.clickable && !it.editable && it.text.length >= 6 && it.top > top }
                val n = cands.getOrNull(step.n - 1) ?: return ask("ما لقيت النتيجة رقم ${step.n}. الشاشة الحالية: ${describe(screen)}")
                i++
                act(AgentAction("click", nodeId = n.id, reason = "فتح النتيجة رقم ${step.n} «${label(n).take(30)}»"))
            }
            is Step.Tap -> {
                val n = findNode(screen, step.labels)
                if (n != null) { i++; act(AgentAction("click", nodeId = n.id, reason = "الضغط على «${label(n).take(30)}»")) }
                else {
                    step.tries++
                    when {
                        step.tries == 1 -> act(AgentAction("wait", text = "2", reason = "انتظار ظهور «${step.labels.first()}»"))
                        step.tries <= 4 -> act(AgentAction("scroll", text = "forward", reason = "تمرير بحثاً عن «${step.labels.first()}»"))
                        else -> ask("ما لقيت «${step.labels.first()}» على الشاشة. الظاهر الآن: ${describe(screen)}")
                    }
                }
            }
            is Step.Search -> {
                val ed = screen.nodes.firstOrNull { it.editable }
                if (step.stage == 1) {
                    // Prefer tapping the visible search suggestion (more reliable than the keyboard's enter key).
                    val sug = findNode(screen, listOf(step.q))
                    i++
                    if (sug != null) act(AgentAction("click", nodeId = sug.id, reason = "اختيار اقتراح البحث «${label(sug).take(30)}»"))
                    else act(AgentAction("enter", reason = "تنفيذ البحث"))
                } else if (ed != null) {
                    step.stage = 1
                    act(AgentAction("set_text", nodeId = ed.id, text = step.q, reason = "كتابة «${step.q}» في البحث"))
                } else {
                    val btn = findNode(screen, listOf("search", "بحث"))
                    if (btn != null && step.tries < 3) { step.tries++; act(AgentAction("click", nodeId = btn.id, reason = "فتح خانة البحث")) }
                    else ask("ما لقيت خانة بحث على الشاشة. الظاهر الآن: ${describe(screen)}")
                }
            }
        }
    }
}
