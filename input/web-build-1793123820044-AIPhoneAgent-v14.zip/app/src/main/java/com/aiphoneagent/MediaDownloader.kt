package com.aiphoneagent

import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Downloads a video / audio / image from a link (TikTok, Instagram, Facebook, Pinterest, X, YouTube, ... anything yt-dlp knows)
 * at the best quality the site offers, and saves it to the phone gallery.
 * Engine: yt-dlp + ffmpeg bundled by the youtubedl-android library. Fallback for image posts: the page's own og:image / og:video.
 */
object MediaDownloader {
    class Req(val url: String, val kind: String)   // kind: video | audio | image

    var busy by mutableStateOf(false)
        private set
    var progress by mutableStateOf(0f)
        private set
    var status by mutableStateOf("")
        private set
    /** A supported link found on the clipboard when the app came to the front (null = nothing to offer). */
    var clipUrl by mutableStateOf<String?>(null)
        private set

    private var dismissed = ""
    private var ready = false
    private var counter = 0

    private val HOSTS = listOf(
        "tiktok.com", "instagram.com", "facebook.com", "fb.watch", "fb.com", "fb.me", "pinterest.", "pin.it",
        "twitter.com", "x.com", "youtube.com", "youtu.be", "snapchat.com", "reddit.com", "vimeo.com", "twitch.tv",
        "threads.net", "likee.video", "kwai.com", "dailymotion.com", "soundcloud.com"
    )
    private val DL_VERBS = listOf("نزل", "حمل", "تنزيل", "تحميل", "سحب", "احفظ", "download", "save", "grab")
    private val AUDIO_WORDS = listOf("صوت", "اغنيه", "اغنية", "موسيقي", "مقطع صوتي", "mp3", "audio", "music", "song")
    private val IMAGE_WORDS = listOf("صوره", "صورة", "image", "photo", "picture", "pic ")
    private val HINT_WORDS = listOf("رابط", "link", "فيديو", "video", "صوره", "ريل", "reel", "منسوخ", "نسخت", "copied", "tiktok", "تيك", "انستا", "insta", "فيس", "facebook", "بنترست", "pinterest", "صوت", "mp3")

    private fun norm(s: String): String = s.lowercase()
        .replace(Regex("[\\u064B-\\u065F\\u0640]"), "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ة', 'ه').replace('ى', 'ي')

    fun findUrl(text: String): String? =
        Regex("https?://[^\\s<>\"']+").find(text)?.value?.trimEnd('.', ',', ')', '،', '؟', '!', ']')

    fun isSupported(url: String): Boolean {
        val h = runCatching { URL(url).host.lowercase() }.getOrDefault("")
        return HOSTS.any { if (it.endsWith(".")) h.contains(it) else (h == it || h.endsWith(".$it")) }
    }

    fun hostLabel(url: String): String {
        val h = runCatching { URL(url).host.lowercase() }.getOrDefault(url)
        return when {
            h.contains("tiktok") -> "تيك توك"
            h.contains("instagram") -> "إنستغرام"
            h.contains("facebook") || h.contains("fb.") -> "فيسبوك"
            h.contains("pinterest") || h.contains("pin.it") -> "بنترست"
            h.contains("twitter") || h == "x.com" || h.endsWith(".x.com") -> "X"
            h.contains("youtu") -> "يوتيوب"
            else -> h.removePrefix("www.")
        }
    }

    private fun kindLabel(k: String) = when (k) { "audio" -> "الصوت"; "image" -> "الصورة"; else -> "الفيديو" }

    private fun clipboardUrl(ctx: Context): String? = runCatching {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val c = cm.primaryClip ?: return null
        if (c.itemCount == 0) return null
        findUrl(c.getItemAt(0).coerceToText(ctx).toString())
    }.getOrNull()

    /** Called when the app window gets focus (Android only lets a focused app read the clipboard). */
    private var lastClipStamp = 0L
    fun checkClipboard(ctx: Context) {
        // Reading the clipboard makes Android show its own "pasted from clipboard" toast, so read it only when there is text
        // and it is a clip we have not examined yet. (That toast is the system's, not a message of this app.)
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val d = runCatching { cm.primaryClipDescription }.getOrNull()
        if (d == null || !runCatching { cm.hasPrimaryClip() }.getOrDefault(false) || !d.hasMimeType("text/*")) { clipUrl = null; return }
        val stamp = if (android.os.Build.VERSION.SDK_INT >= 26) d.timestamp else 0L
        if (stamp != 0L && stamp == lastClipStamp) return
        lastClipStamp = stamp
        val u = clipboardUrl(ctx)
        clipUrl = if (u != null && isSupported(u) && u != dismissed) u else null
    }

    fun dismiss() { dismissed = clipUrl ?: dismissed; clipUrl = null }

    /** Decides whether a chat message is a download request. Plain rules, so it is instant and never hijacks other questions. */
    fun parse(text: String, ctx: Context): Req? {
        val t = norm(text)
        val verb = DL_VERBS.any { t.contains(it) }
        val kind = when {
            AUDIO_WORDS.any { t.contains(it) } -> "audio"
            IMAGE_WORDS.any { t.contains(it) } -> "image"
            else -> "video"
        }
        val url = findUrl(text)
        if (url != null) {
            val only = text.trim() == url
            return if (verb || (only && isSupported(url))) Req(url, kind) else null
        }
        if (verb && HINT_WORDS.any { t.contains(it) }) {
            val c = clipboardUrl(ctx) ?: return null
            return Req(c, kind)
        }
        return null
    }

    fun importCookies(ctx: Context, uri: Uri): Boolean = runCatching {
        ctx.contentResolver.openInputStream(uri)!!.use { i -> File(ctx.filesDir, "cookies.txt").outputStream().use { o -> i.copyTo(o) } }
        true
    }.getOrDefault(false)

    fun hasCookies(ctx: Context) = File(ctx.filesDir, "cookies.txt").exists()
    fun deleteCookies(ctx: Context) { File(ctx.filesDir, "cookies.txt").delete() }

    // ------------------------------------------------------------------ run

    suspend fun run(ctx: Context, req: Req, say: (String) -> Unit) {
        if (busy) { say("في تنزيل جاري. استنى لين يخلص."); return }
        busy = true; progress = 0f; status = "يبدأ…"
        JobService.begin(ctx, "تنزيل من " + hostLabel(req.url), "يبدأ…")
        val work = File(ctx.cacheDir, "dl/" + System.currentTimeMillis()).apply { mkdirs() }
        try {
            say("أنزّل ${kindLabel(req.kind)} من ${hostLabel(req.url)} بأعلى جودة متاحة…")
            val files = withContext(Dispatchers.IO) { fetch(ctx, req, work) }
            if (files.isEmpty()) throw IllegalStateException("ما لقيت وسائط بالرابط.")
            val saved = withContext(Dispatchers.IO) { files.map { save(ctx, it) } }
            dismissed = req.url
            clipUrl = null
            say("✓ تم التنزيل والحفظ بالمعرض:\n" + saved.joinToString("\n"))
            JobService.done(ctx, "✓ تم التنزيل", saved.first().substringAfterLast('/'))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val m = explain(e.message.orEmpty())
            say("تعذّر التنزيل: $m")
            JobService.done(ctx, "تعذّر التنزيل", m.take(120))
        } finally {
            busy = false
            JobService.end(ctx)
            withContext(kotlinx.coroutines.NonCancellable) { work.deleteRecursively() }
        }
    }

    private fun explain(m: String): String = when {
        m.contains("login", true) || m.contains("cookies", true) || m.contains("log in", true) || m.contains("rate-limit", true) ->
            "الموقع يطلب تسجيل دخول لهالمحتوى. صدّر ملف cookies.txt من متصفحك واستورده من الإعدادات، وأعد المحاولة."
        m.contains("private", true) -> "المحتوى خاص."
        m.contains("Unsupported URL", true) -> "الرابط غير مدعوم أو ما فيه وسائط."
        m.contains("404") || m.contains("not available", true) || m.contains("removed", true) -> "المحتوى محذوف أو غير متاح."
        m.contains("Unable to resolve host", true) || m.contains("UnknownHost", true) -> "ما في إنترنت."
        else -> m.lines().lastOrNull { it.isNotBlank() }?.take(220) ?: "خطأ غير معروف."
    }

    // ------------------------------------------------------------------ engine

    private fun ensureEngine(ctx: Context) {
        val app = ctx.applicationContext
        if (!ready) {
            YoutubeDL.getInstance().init(app)
            runCatching { FFmpeg.getInstance().init(app) }
            ready = true
        }
        val p = app.getSharedPreferences("dl", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - p.getLong("upd", 0L) > 24 * 3_600_000L) {
            p.edit().putLong("upd", now).apply()
            runCatching { updateEngine(app) }   // sites change often: refresh yt-dlp once a day (best effort, API differs per library version)
        }
    }

    private fun updateEngine(app: Context) {
        val yt = YoutubeDL.getInstance()
        val m = yt.javaClass.methods.firstOrNull { it.name == "updateYoutubeDL" } ?: return
        val args = ArrayList<Any?>()
        for (t in m.parameterTypes) {
            args.add(when {
                Context::class.java.isAssignableFrom(t) -> app
                t.isEnum -> t.enumConstants?.firstOrNull { (it as Enum<*>).name.contains("STABLE") } ?: t.enumConstants?.firstOrNull()
                else -> runCatching { t.getField("STABLE").get(null) }.getOrNull()
                    ?: runCatching { t.getField("_STABLE").get(null) }.getOrNull()
                    ?: runCatching { Class.forName(t.name + "\$STABLE").getField("INSTANCE").get(null) }.getOrNull()
            })
        }
        m.invoke(yt, *args.toTypedArray())
    }

    private fun fetch(ctx: Context, req: Req, work: File): List<File> {
        if (req.kind == "image") {
            val s = scrape(req.url, true, work)
            if (s.isNotEmpty()) return s
        }
        ensureEngine(ctx)
        val tiktok = req.url.contains("tiktok.com")
        val plain = "bv*+ba/b"
        val formats = if (req.kind == "audio") listOf("ba/b")
            else if (tiktok) listOf("bv*[format_note!*=?watermarked]+ba/b[format_note!*=?watermarked]/bv*+ba/b", plain)
            else listOf(plain)
        var last: Exception? = null
        for (fmt in formats) {
            try {
                val r = YoutubeDLRequest(req.url)
                r.addOption("-o", work.absolutePath + "/%(id)s.%(ext)s")
                r.addOption("--no-mtime")
                r.addOption("--retries", "3")
                r.addOption("--socket-timeout", "30")
                r.addOption("--concurrent-fragments", "4")
                val ck = File(ctx.filesDir, "cookies.txt")
                if (ck.exists()) r.addOption("--cookies", ck.absolutePath)
                r.addOption("-f", fmt)
                if (req.kind == "audio") {
                    r.addOption("-x"); r.addOption("--audio-format", "mp3"); r.addOption("--audio-quality", "0")
                } else {
                    r.addOption("--merge-output-format", "mp4")
                    r.addOption("-S", "res,fps,vcodec:h264,acodec:aac")
                }
                YoutubeDL.getInstance().execute(r) { p, _, _ ->
                    if (p >= 0f) { progress = p / 100f; status = "تنزيل " + p.toInt() + "%"; JobService.update(ctx, status) }
                }
                val out = work.listFiles()?.filter { it.isFile && it.length() > 0 && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }.orEmpty()
                if (out.isNotEmpty()) return out
            } catch (e: Exception) {
                last = e
                if (!e.message.orEmpty().contains("format", true)) break   // only a format problem is worth retrying with the plain selector
            }
        }
        // Not a video (image post, gallery, ...) or yt-dlp could not read it: use the page's own media tags.
        val s = runCatching { scrape(req.url, req.kind == "image", work) }.getOrDefault(emptyList())
        if (s.isNotEmpty()) return s
        throw last ?: IllegalStateException("ما لقيت وسائط بالرابط.")
    }

    // ------------------------------------------------------------------ og:image / og:video fallback

    private fun httpText(url: String): String? = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000; c.readTimeout = 20_000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36")
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.8")
        c.inputStream.use { it.readBytes().take(2_000_000).toByteArray().toString(Charsets.UTF_8) }
    }.getOrNull()

    private fun metaValues(html: String, names: List<String>): List<String> {
        val out = ArrayList<String>()
        for (n in names) {
            val a = Regex("<meta[^>]+(?:property|name)=[\"']" + Regex.escape(n) + "[\"'][^>]*content=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
            val b = Regex("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]*(?:property|name)=[\"']" + Regex.escape(n) + "[\"']", RegexOption.IGNORE_CASE)
            a.findAll(html).forEach { out.add(it.groupValues[1].replace("&amp;", "&")) }
            b.findAll(html).forEach { out.add(it.groupValues[1].replace("&amp;", "&")) }
        }
        return out.filter { it.startsWith("http") }
    }

    private fun scrape(url: String, imageFirst: Boolean, work: File): List<File> {
        val html = httpText(url) ?: return emptyList()
        val vids = metaValues(html, listOf("og:video:secure_url", "og:video", "og:video:url"))
        var imgs = metaValues(html, listOf("og:image", "twitter:image"))
        if (url.contains("pinterest") || url.contains("pin.it") || imgs.any { it.contains("pinimg.com") })
            imgs = imgs.map { it.replace(Regex("/(\\d+x\\d*|\\d+x)/"), "/originals/") }
        val pick = (if (imageFirst) imgs + vids else vids + imgs).distinct()
        for (m in pick) {
            val f = runCatching { download(m, work) }.getOrNull()
            if (f != null) return listOf(f)
            // the "originals" guess can 404 for some pins: retry the unmodified link
        }
        val fallback = metaValues(html, listOf("og:image"))
        for (m in fallback) { val f = runCatching { download(m, work) }.getOrNull(); if (f != null) return listOf(f) }
        return emptyList()
    }

    private fun download(url: String, work: File): File {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000; c.readTimeout = 60_000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36")
        if (c.responseCode !in 200..299) throw IllegalStateException("HTTP " + c.responseCode)
        val ct = (c.contentType ?: "").lowercase()
        val ext = when {
            ct.contains("png") -> "png"; ct.contains("webp") -> "webp"; ct.contains("gif") -> "gif"
            ct.contains("jpeg") || ct.contains("jpg") -> "jpg"; ct.contains("mp4") || ct.contains("video") -> "mp4"
            else -> URL(url).path.substringAfterLast('.', "jpg").lowercase().take(4).ifBlank { "jpg" }
        }
        val f = File(work, "media_" + (++counter) + "." + ext)
        c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
        if (f.length() < 1000) { f.delete(); throw IllegalStateException("tiny file") }
        return f
    }

    // ------------------------------------------------------------------ save to the gallery

    private fun save(ctx: Context, f: File): String {
        val ext = f.extension.lowercase()
        val kind = when (ext) {
            "jpg", "jpeg", "png", "webp", "gif", "heic" -> "image"
            "mp3", "m4a", "opus", "aac", "ogg", "wav", "flac" -> "audio"
            else -> "video"
        }
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (kind) { "image" -> "image/jpeg"; "audio" -> "audio/mpeg"; else -> "video/mp4" }
        val name = "AIAgent_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + "_" + (++counter) + "." + ext
        if (Build.VERSION.SDK_INT >= 29) {
            val base = when (kind) { "image" -> Environment.DIRECTORY_PICTURES; "audio" -> Environment.DIRECTORY_MUSIC; else -> Environment.DIRECTORY_MOVIES }
            val col = when (kind) {
                "image" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                else -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            }
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, "$base/AIAgent")
            v.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val uri = ctx.contentResolver.insert(col, v) ?: throw IllegalStateException("تعذّر الحفظ بالمعرض.")
            ctx.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o, 1 shl 16) } }
            val done = ContentValues()
            done.put(MediaStore.MediaColumns.IS_PENDING, 0)
            ctx.contentResolver.update(uri, done, null, null)
            return "$base/AIAgent/$name"
        }
        val dir = File(ctx.getExternalFilesDir(null), "AIAgent").apply { mkdirs() }
        f.copyTo(File(dir, name), true)
        return dir.absolutePath + "/" + name
    }
}
