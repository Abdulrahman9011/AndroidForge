package com.aiphoneagent

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * On-screen controls + guaranteed notification controls.
 * - Runs as a foreground service, so its notification (Pause / Stop / Hide) always works, even if a window can't be touched.
 * - Windows are added through the accessibility service (TYPE_ACCESSIBILITY_OVERLAY, trusted by Android 12+), falling back to
 *   TYPE_APPLICATION_OVERLAY only when the accessibility service is not running.
 * - The service stops itself a few seconds after the task ends, so nothing is left floating over other apps.
 */
class OverlayService : Service() {
    companion object {
        const val ACTION_STOP = "com.aiphoneagent.STOP"
        const val ACTION_PAUSE = "com.aiphoneagent.PAUSE"
        const val ACTION_HIDE = "com.aiphoneagent.HIDE"
        private const val CH = "agent_controls"
        private const val NID = 41
        private val INK = 0xFFE6E3DC.toInt()
        private val INK_DIM = 0xFFA09E97.toInt()
        private val DANGER = 0xFFE29C95.toInt()
    }

    private var wm: WindowManager? = null
    private var panel: LinearLayout? = null
    private var cursor: CursorView? = null
    private var cursorLp: WindowManager.LayoutParams? = null
    private var anim: ValueAnimator? = null
    private var lastCx = -1f
    private var lastCy = -1f
    private var lastClick = 0
    private var idleSince = 0L
    private val h = Handler(Looper.getMainLooper())
    private var tick: () -> Unit = {}
    private val loop = object : Runnable { override fun run() { tick(); h.postDelayed(this, 250) } }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        when (i?.action) {
            ACTION_STOP -> AgentController.stop()
            ACTION_PAUSE -> AgentController.togglePause()
            ACTION_HIDE -> stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null)
            nm.createNotificationChannel(NotificationChannel(CH, "AI Phone Agent", NotificationManager.IMPORTANCE_LOW))
        fun act(a: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, OverlayService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("AI Phone Agent")
            .setContentText("المساعد يعمل — اضغط إيقاف في أي وقت")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف مؤقت", act(ACTION_PAUSE, 1))
            .addAction(android.R.drawable.ic_delete, "إيقاف", act(ACTION_STOP, 2))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إخفاء", act(ACTION_HIDE, 3))
            .build()
    }

    private fun glass(fill: Int, stroke: Int, r: Float) = GradientDrawable().apply {
        cornerRadius = r; setColor(fill); setStroke(2, stroke)
    }

    override fun onCreate() {
        super.onCreate()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NID, n)

        val a11y = AgentAccessibilityService.instance
        if (a11y == null && !Settings.canDrawOverlays(this)) return   // notification controls only
        val host: Context = a11y ?: this
        val type = if (a11y != null) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                   else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val manager = host.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = manager
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        fun pill(label: String, color: Int, onTap: () -> Unit) = TextView(host).apply {
            text = label; setTextColor(color); textSize = 13f; gravity = Gravity.CENTER
            setPadding(px(10), 0, px(10), 0)
            background = glass(0x2EFFFFFF, 0x40FFFFFF, 14 * dp)
            isClickable = true
            // Manual tap detection (down + up inside the view) works on every OEM, unlike relying on performClick.
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { v.alpha = 0.6f; true }
                    MotionEvent.ACTION_UP -> {
                        v.alpha = 1f
                        if (e.x >= 0f && e.x <= v.width && e.y >= 0f && e.y <= v.height) onTap()
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> { v.alpha = 1f; true }
                    else -> true
                }
            }
            layoutParams = LinearLayout.LayoutParams(0, px(46), 1f).apply { marginStart = px(3); marginEnd = px(3) }
        }

        val status = TextView(host).apply { setTextColor(INK); textSize = 13f; setPadding(px(4), px(2), px(4), px(8)) }
        val confirmText = TextView(host).apply { setTextColor(INK); textSize = 13f; visibility = View.GONE; setPadding(px(4), 0, px(4), px(8)) }
        val pause = pill("إيقاف مؤقت", INK) { AgentController.togglePause() }
        val stop = pill("إيقاف", DANGER) { AgentController.stop() }
        val hide = pill("إخفاء", INK_DIM) { stopSelf() }
        val allow = pill("سماح", INK) { AgentController.answer(true) }
        val deny = pill("رفض", DANGER) { AgentController.answer(false) }
        val row1 = LinearLayout(host).apply { addView(pause); addView(stop); addView(hide) }
        val row2 = LinearLayout(host).apply { visibility = View.GONE; addView(allow); addView(deny); setPadding(0, px(6), 0, 0) }
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; minimumWidth = px(280)
            setPadding(px(12), px(10), px(12), px(12))
            background = glass(0xEB1B1B1E.toInt(), 0x40FFFFFF, 22 * dp)
            addView(status); addView(confirmText); addView(row1); addView(row2)
        }
        panel = box

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = px(12); y = px(110) }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        val dragger = View.OnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = (ox + dx).toInt().coerceAtLeast(0); lp.y = (oy + dy).toInt().coerceAtLeast(0)
                        runCatching { manager.updateViewLayout(box, lp) }
                    }
                }
            }
            true
        }
        status.setOnTouchListener(dragger); box.setOnTouchListener(dragger)

        // Visual-only pointer in its own tiny window (no full-screen overlay that could swallow touches).
        val arrow = CursorView(host, px(18)).apply { visibility = View.GONE; pivotX = 0f; pivotY = 0f }
        cursor = arrow
        val clp = WindowManager.LayoutParams(
            px(18), px(28), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }
        cursorLp = clp

        fun moveCursor(tx: Float, ty: Float, first: Boolean) {
            val loc = IntArray(2); arrow.getLocationOnScreen(loc)
            val offX = loc[0] - clp.x; val offY = loc[1] - clp.y        // compensates status bar / cutout offsets
            val endX = (tx - offX - arrow.tipPx).toInt(); val endY = (ty - offY - arrow.tipPx).toInt()
            anim?.cancel()
            val fromX = clp.x; val fromY = clp.y
            if (first) { clp.x = endX; clp.y = endY; runCatching { manager.updateViewLayout(arrow, clp) }; return }
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 240
                addUpdateListener { a ->
                    val f = a.animatedFraction
                    clp.x = (fromX + (endX - fromX) * f).toInt(); clp.y = (fromY + (endY - fromY) * f).toInt()
                    runCatching { manager.updateViewLayout(arrow, clp) }
                }
                start()
            }
        }

        tick = {
            val c = AgentController
            val q = c.pendingConfirm
            val active = (c.running && c.phoneActive) || q != null
            val st = if (c.running && c.phoneActive) (if (c.paused) "متوقف مؤقتاً — " else "") + c.status else ""
            if (status.text.toString() != st) status.text = st
            val pt = if (c.paused) "متابعة" else "إيقاف مؤقت"
            if (pause.text.toString() != pt) pause.text = pt
            val cv = if (q != null) View.VISIBLE else View.GONE
            if (row2.visibility != cv) row2.visibility = cv
            if (confirmText.visibility != cv) confirmText.visibility = cv
            if (q != null && confirmText.text.toString() != q) confirmText.text = q
            val pv = if (active) View.VISIBLE else View.GONE
            if (box.visibility != pv) box.visibility = pv

            if (active) idleSince = 0L
            else if (idleSince == 0L) idleSince = SystemClock.uptimeMillis()
            else if (SystemClock.uptimeMillis() - idleSince > 6000) stopSelf()

            if (c.cursorVisible) {
                if (arrow.visibility != View.VISIBLE) arrow.visibility = View.VISIBLE
                if (c.cursorX != lastCx || c.cursorY != lastCy) {
                    moveCursor(c.cursorX, c.cursorY, lastCx < 0f)
                    lastCx = c.cursorX; lastCy = c.cursorY
                }
                if (c.cursorClick != lastClick) {
                    lastClick = c.cursorClick
                    arrow.animate().scaleX(0.7f).scaleY(0.7f).setDuration(90).withEndAction {
                        arrow.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    }.start()
                }
            } else {
                if (arrow.visibility != View.GONE) arrow.visibility = View.GONE
                lastCx = -1f; lastCy = -1f
            }
        }
        runCatching { manager.addView(arrow, clp) }
        runCatching { manager.addView(box, lp) }
        h.post(loop)
    }

    override fun onDestroy() {
        h.removeCallbacks(loop)
        anim?.cancel()
        val m = wm
        cursor?.let { v -> runCatching { m?.removeView(v) } }
        panel?.let { v -> runCatching { m?.removeView(v) } }
        cursor = null; panel = null
        super.onDestroy()
    }
}

class CursorView(ctx: Context, private val wPx: Int) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 2f; strokeJoin = Paint.Join.ROUND }
    private val path = Path()
    /** Offset of the arrow tip inside this view, so the tip lands exactly on the target. */
    val tipPx: Float get() = wPx / 17f
    override fun onDraw(c: Canvas) {
        val s = wPx / 17f
        path.reset()
        path.moveTo(1 * s, 1 * s); path.lineTo(1 * s, 22 * s); path.lineTo(6 * s, 17.5f * s)
        path.lineTo(9.5f * s, 25 * s); path.lineTo(13 * s, 23.5f * s); path.lineTo(9.5f * s, 16.5f * s)
        path.lineTo(16 * s, 16.5f * s); path.close()
        c.drawPath(path, fill); c.drawPath(path, stroke)
    }
}
