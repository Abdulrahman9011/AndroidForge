package com.aiphoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.graphics.Bitmap
import android.os.Build
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume
import android.view.accessibility.AccessibilityNodeInfo

class Shot(val b64: String, val w: Int, val h: Int)

class AgentAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: AgentAccessibilityService? = null }

    private var cache: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Reads only visible, non-password nodes (text trimmed). Nothing is stored. */
    fun snapshot(): ScreenSnapshot {
        var found = rootInActiveWindow
        var tries = 0
        while (found == null && tries < 4) { Thread.sleep(250); found = rootInActiveWindow; tries++ }
        val root = found ?: return ScreenSnapshot("", emptyList(), "No accessible window (secure or custom-rendered screen?)")
        val dm = resources.displayMetrics
        val nodes = mutableListOf<UiNode>()
        val infos = mutableListOf<AccessibilityNodeInfo>()
        var visited = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || nodes.size >= 250 || depth > 30 || visited > 700) return
            visited++
            if (!n.isVisibleToUser) return   // hidden / off-screen subtree: skip it entirely (big speed-up)
            run {
                val txt = if (n.isPassword) "" else n.text?.toString().orEmpty().take(120)
                val desc = n.contentDescription?.toString().orEmpty().take(120)
                if (txt.isNotEmpty() || desc.isNotEmpty() || n.isClickable || n.isScrollable || n.isEditable) {
                    val r = Rect(); n.getBoundsInScreen(r)
                    nodes += UiNode(nodes.size, txt, desc, n.viewIdResourceName.orEmpty(),
                        n.className?.toString().orEmpty(), n.isClickable, n.isScrollable, n.isEditable,
                        r.left, r.top, r.right, r.bottom)
                    infos += n
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        cache = infos
        return ScreenSnapshot(root.packageName?.toString().orEmpty(), nodes, "", dm.widthPixels, dm.heightPixels)
    }

    /** Screenshot via the accessibility service (Android 11+), scaled to 720px wide JPEG. Null if blocked/unsupported. */
    suspend fun screenshot(): Shot? {
        if (Build.VERSION.SDK_INT < 30) return null
        return suspendCancellableCoroutine { cont ->
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                        val out: Shot? = try {
                            val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                            val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            r.hardwareBuffer.close()
                            if (bmp == null) null else {
                                val tw = 640
                                val th = (bmp.height * tw.toFloat() / bmp.width).toInt()
                                val sc = Bitmap.createScaledBitmap(bmp, tw, th, true)
                                val bo = ByteArrayOutputStream()
                                sc.compress(Bitmap.CompressFormat.JPEG, 62, bo)
                                Shot(Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP), tw, th)
                            }
                        } catch (e: Throwable) { null }
                        if (cont.isActive) cont.resume(out)
                    }
                    override fun onFailure(errorCode: Int) { if (cont.isActive) cont.resume(null) }
                })
            } catch (e: Throwable) { if (cont.isActive) cont.resume(null) }
        }
    }

    private fun node(id: Int): AccessibilityNodeInfo? = cache.getOrNull(id)?.takeIf { it.refresh() }

    fun click(id: Int): ActionResult {
        var cur: AccessibilityNodeInfo? = node(id) ?: return ActionResult(false, null, "Node $id no longer on screen")
        var depth = 0
        while (cur != null && !cur.isClickable && depth < 5) { cur = cur.parent; depth++ }
        if (cur == null) return ActionResult(false, null, "No clickable element found")
        return ActionResult(cur.performAction(AccessibilityNodeInfo.ACTION_CLICK), null, "ACTION_CLICK")
    }

    fun setText(id: Int, text: String): ActionResult {
        val n = node(id) ?: return ActionResult(false, null, "Node $id no longer on screen")
        if (n.isPassword) return ActionResult(false, null, "Refused: password field")
        if (!n.isEditable) return ActionResult(false, null, "Node is not editable")
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return ActionResult(n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args), null, "ACTION_SET_TEXT")
    }

    /** Fallback when ACTION_SET_TEXT is ignored: focus the field and paste via the clipboard. */
    fun pasteText(id: Int, text: String): ActionResult {
        val n = node(id) ?: return ActionResult(false, null, "Node $id no longer on screen")
        if (n.isPassword) return ActionResult(false, null, "Refused: password field")
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("agent", text))
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        return ActionResult(n.performAction(AccessibilityNodeInfo.ACTION_PASTE), null, "paste fallback")
    }

    fun scroll(forward: Boolean): ActionResult {
        // Largest visible scrollable container = the main content list (not a small tab strip).
        val n = cache.filter { it.isScrollable && it.refresh() }.maxByOrNull { c -> Rect().also { c.getBoundsInScreen(it) }.let { r -> r.width().toLong() * r.height() } }
            ?: return ActionResult(false, null, "No scrollable container exposed")
        val a = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return ActionResult(n.performAction(a), null, "scroll")
    }

    fun home() = ActionResult(performGlobalAction(GLOBAL_ACTION_HOME), null, "GLOBAL_ACTION_HOME")

    fun imeEnter(): ActionResult {
        if (android.os.Build.VERSION.SDK_INT < 30) return ActionResult(false, null, "IME enter needs Android 11+")
        val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return ActionResult(false, null, "No focused input")
        return ActionResult(n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id), null, "IME_ENTER")
    }

    fun back() = ActionResult(performGlobalAction(GLOBAL_ACTION_BACK), null, "GLOBAL_ACTION_BACK")

    fun tapAt(x: Float, y: Float): ActionResult {
        val m = resources.displayMetrics
        if (x < 0 || y < 0 || x >= m.widthPixels || y >= m.heightPixels)
            return ActionResult(false, null, "Coordinates outside screen")
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return ActionResult(dispatchGesture(g, null, null), null, "gesture at ($x,$y)")
    }

    /** Touch and hold at a point (e.g. the record button of a chat app) for [ms] milliseconds, then release. */
    suspend fun hold(x: Float, y: Float, ms: Long): ActionResult {
        val m = resources.displayMetrics
        if (x < 0 || y < 0 || x >= m.widthPixels || y >= m.heightPixels) return ActionResult(false, null, "Coordinates outside screen")
        val d = ms.coerceIn(300L, GestureDescription.getMaxGestureDuration())
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(Path().apply { moveTo(x, y) }, 0, d)).build()
        return suspendCancellableCoroutine { cont ->
            val ok = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { if (cont.isActive) cont.resume(ActionResult(true, null, "held ${d}ms at ($x,$y)")) }
                override fun onCancelled(gestureDescription: GestureDescription?) { if (cont.isActive) cont.resume(ActionResult(false, null, "hold was cancelled")) }
            }, null)
            if (!ok && cont.isActive) cont.resume(ActionResult(false, null, "hold was not dispatched"))
        }
    }

    private suspend fun dispatchAwait(g: GestureDescription): Boolean = suspendCancellableCoroutine { cont ->
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { if (cont.isActive) cont.resume(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!ok && cont.isActive) cont.resume(false)
    }

    /**
     * Presses a point and keeps the finger down for exactly as long as [whileHeld] runs, then lifts (for "hold to record" buttons).
     * The finger goes down with a stroke that "will continue"; the lift is the continuation, so the hold length is not guessed in advance.
     */
    suspend fun holdWhile(x: Float, y: Float, whileHeld: suspend () -> Unit): ActionResult {
        val m = resources.displayMetrics
        if (x < 0 || y < 0 || x >= m.widthPixels || y >= m.heightPixels) return ActionResult(false, null, "Coordinates outside screen")
        val down = GestureDescription.StrokeDescription(Path().apply { moveTo(x, y) }, 0L, 350L, true)
        if (!dispatchAwait(GestureDescription.Builder().addStroke(down).build())) return ActionResult(false, null, "press was cancelled or not dispatched")
        var lifted = false
        try {
            whileHeld()
        } finally {
            withContext(NonCancellable) {
                val up = down.continueStroke(Path().apply { moveTo(x, y) }, 0L, 80L, false)
                lifted = dispatchAwait(GestureDescription.Builder().addStroke(up).build())
            }
        }
        return ActionResult(lifted, null, if (lifted) "held and released at ($x,$y)" else "release was not delivered")
    }

    fun startIntent(i: Intent): ActionResult = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); ActionResult(true, null, "started")
    } catch (e: Exception) { ActionResult(false, null, e.message ?: "launch failed") }

    fun launchApp(pkg: String?): ActionResult {
        val i = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
            ?: return ActionResult(false, null, "App not installed or not visible: $pkg")
        return startIntent(i)
    }

    fun openUrl(url: String?): ActionResult {
        val u = url?.let { Uri.parse(it) }
        if (u == null || (u.scheme != "https" && u.scheme != "http")) return ActionResult(false, null, "Only http(s) URLs allowed")
        return startIntent(Intent(Intent.ACTION_VIEW, u))
    }
}
