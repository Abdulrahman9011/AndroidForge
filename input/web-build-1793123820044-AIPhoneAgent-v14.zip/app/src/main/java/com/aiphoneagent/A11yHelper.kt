package com.aiphoneagent

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Process
import android.provider.Settings

object A11yHelper {
    private const val SERVICE = "com.aiphoneagent/com.aiphoneagent.AgentAccessibilityService"

    fun canSelfEnable(c: Context) =
        c.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    /** Works only after the user granted WRITE_SECURE_SETTINGS via ADB. User-initiated, visible in system settings. */
    fun selfEnable(c: Context): Boolean = runCatching {
        val r = c.contentResolver
        val cur = Settings.Secure.getString(r, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        if (!cur.split(":").contains(SERVICE))
            Settings.Secure.putString(r, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, if (cur.isEmpty()) SERVICE else "$cur:$SERVICE")
        Settings.Secure.putInt(r, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
        true
    }.getOrDefault(false)

    /** "yes" / "no" / "unknown" — best-effort check of Android's restricted-settings app-op. */
    fun restricted(c: Context): String = runCatching {
        val a = c.getSystemService(AppOpsManager::class.java)
        when (a.unsafeCheckOpNoThrow("android:access_restricted_settings", Process.myUid(), c.packageName)) {
            AppOpsManager.MODE_ALLOWED -> "no"
            AppOpsManager.MODE_IGNORED -> "yes"
            else -> "unknown"
        }
    }.getOrDefault("unknown")
}
