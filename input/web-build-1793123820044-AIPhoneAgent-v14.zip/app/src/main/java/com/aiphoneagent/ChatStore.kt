package com.aiphoneagent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** One saved conversation in the list. [auto] = the title is still the quick one taken from the first message. */
data class ChatMeta(val id: String, val title: String, val updated: Long, val auto: Boolean = true)

/** Conversations on disk: filesDir/chats/index.json (the list) + one <id>.json per conversation. */
object ChatStore {
    private var dir: File? = null

    fun init(c: Context) {
        if (dir == null) dir = File(c.filesDir, "chats").apply { mkdirs() }
    }

    private fun file(name: String): File? {
        val d = dir ?: return null
        return File(d, name)
    }

    fun loadIndex(): List<ChatMeta> {
        return try {
            val a = JSONArray(file("index.json")?.readText() ?: return emptyList())
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                ChatMeta(o.getString("id"), o.optString("title"), o.optLong("updated"), o.optBoolean("auto", true))
            }
        } catch (e: Exception) { emptyList() }
    }

    @Synchronized
    fun saveIndex(l: List<ChatMeta>) {
        try {
            val a = JSONArray()
            l.forEach { m -> a.put(JSONObject().put("id", m.id).put("title", m.title).put("updated", m.updated).put("auto", m.auto)) }
            file("index.json")?.writeText(a.toString())
        } catch (e: Exception) { }
    }

    @Synchronized
    fun save(id: String, msgs: JSONArray) {
        try { file("$id.json")?.writeText(msgs.toString()) } catch (e: Exception) { }
    }

    fun load(id: String): JSONArray? {
        return try { JSONArray(file("$id.json")?.readText() ?: return null) } catch (e: Exception) { null }
    }

    fun delete(id: String) {
        try { file("$id.json")?.delete() } catch (e: Exception) { }
    }
}
