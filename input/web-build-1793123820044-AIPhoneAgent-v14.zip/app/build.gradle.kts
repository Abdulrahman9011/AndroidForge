import java.util.Properties

val aiProps = Properties().apply {
    val f = rootProject.file("ai.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val aiKey: String = (System.getenv("AI_API_KEY") ?: aiProps.getProperty("AI_API_KEY") ?: "").trim()
// Several keys: AI_API_KEYS="k1,k2,k3" (env var or ai.properties). They are merged with AI_API_KEY.
val aiKeysRaw: String = (System.getenv("AI_API_KEYS") ?: aiProps.getProperty("AI_API_KEYS") ?: "").trim()
val aiKeys: String = (aiKeysRaw.split(Regex("[,;\\s]+")) + aiKey).map { it.trim() }.filter { it.length > 8 }.distinct().joinToString(",")

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.aiphoneagent"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.aiphoneagent"
        minSdk = 26
        targetSdk = 34
        // Always increasing: GitHub run number in CI, minutes since epoch locally. Android refuses updates when versionCode does not grow.
        val vc = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: (System.currentTimeMillis() / 60000L).toInt())
        versionCode = vc
        versionName = "0.9.$vc"
        ndk { abiFilters += "arm64-v8a" }
        buildConfigField("String", "DEFAULT_API_KEY", "\"$aiKey\"")
        buildConfigField("String", "DEFAULT_API_KEYS", "\"$aiKeys\"")
    }
    // Same signing key on every build, so a new APK installs OVER the old one (CI would otherwise generate a new debug key each run).
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android"
        }
    }
    buildTypes {
        // Still "assembleDebug" and the same signing key, but not debuggable: a debuggable build runs Compose noticeably slower.
        getByName("debug") { isDebuggable = false }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    // yt-dlp / python / ffmpeg binaries must be extracted to disk to be executable.
    packaging { jniLibs { useLegacyPackaging = true } }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("io.github.junkfood02.youtubedl-android:library:0.17.2")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.17.2")
}
