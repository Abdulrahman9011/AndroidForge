# AI Phone Agent (Stage 1 foundation)

**Status: source written but NOT compiled or run on a device by the author.** Expect possible build errors; send them back verbatim.

## Build a debug APK (no local tools)
1. Push this folder to a GitHub repo. The included workflow (`.github/workflows/build.yml`) builds `app-debug.apk` and uploads it as an artifact (Actions tab).
2. Or open in Android Studio (Koala+, JDK 17) and run Build > Build APK(s). The Gradle wrapper JAR is not included; Android Studio/`gradle wrapper --gradle-version 8.7` provides it.

## Permissions
- `BIND_ACCESSIBILITY_SERVICE` (on the service, not requested at runtime): read visible screen text, tap/scroll/type/back.
- `SYSTEM_ALERT_WINDOW`: optional floating "AI" bubble with Pause/Stop/Hide and confirmations. Separate from accessibility.
- `INTERNET`: talk to your AI backend (HTTPS only).
- `<queries>` for launcher apps: lets the agent launch installed apps (Android 11+ package visibility).

## Android 14 "Setting restricted" fix
This is Android's restricted-settings policy for apps installed outside a store, not a manifest bug. The manifest/XML here are correct, but they cannot remove the restriction.
1. Install the APK. Open Settings > Accessibility > AI Phone Agent and tap it once (it shows the restriction).
2. Settings > Apps > AI Phone Agent > ⋮ (top right) > **Allow restricted settings** (confirm with PIN/biometrics).
3. Return to Accessibility and enable the service. The ⋮ item only appears after step 1.
Installing via a different installer (or ADB) can change whether the restriction applies. OEM skins (e.g. XOS) may word menus differently.

## Backend contract (Stage 2; server not included)
POST HTTPS, `Authorization: Bearer <token>`:
`{"goal":"...","history":["..."],"screen":{"package":"...","nodes":[{"id":0,"text":"","desc":"","viewId":"","clickable":true,"scrollable":false,"editable":false}]}}`
Response: `{"say":"...","askUser":"...","done":false,"action":{"type":"click|set_text|scroll|back|open_app|open_url|tap_at","nodeId":3,"text":"...","target":"...","reason":"...","sensitive":false}}`
The backend holds the model API key, builds the prompt, validates the model's JSON, and returns one action per call. Hosting (e.g. a serverless function) is cheap to run; model usage is billed per token and each step sends the screen text, so costs scale with steps.

## Test report
Verified: nothing (not built, not run).
Untested assumptions: compiles; service can be enabled; `/selftest` opens Settings and scrolls; overlay drag/panel; launching apps from the service context in the background; YouTube flow (needs Stage 2 backend).
Not implemented: backend server, MediaProjection screen analysis, voice input, persistent task history, multi-provider config, encrypted credential storage.

## Offline commands (no AI, default)
Chain with «ثم» / «و» / comma / "then": `افتح X` · `ابحث عن X [في تطبيق]` · `اضغط على <نص>` · `اكتب <نص>` · `انزل [N]` / `اطلع [N]` · `ارجع` · `الرئيسية` · `انتظر N` · `افتح أول نتيجة` · `اضغط عند 50% 80%` · `ادخل لعبة X` (Roblox: open, search, tap result, tap Play).
Limits: fixed grammar, not free-form understanding; cannot read custom-rendered screens (games) — only coordinate taps there. AI mode defaults to on when a cloud AI key/backend is configured. Without a cloud provider or imported local model, the app still uses the limited local command parser; it does not magically contain a ChatGPT-class model.

## Smart mode
Commands the offline parser understands run locally. Anything else goes to the AI model automatically if a key is saved in Settings (optional, paid). Without a key the app says it did not understand. The floating pointer is the mouse cursor itself: draggable when idle, and it moves to each target while a task runs (visual only; the click comes from the element's bounds).

## Notes (latest)
App names are matched across Arabic/English spelling (تيك توك = TikTok), misspelled leading verbs are corrected, and "افتح الثاني/أول فيديو" picks the Nth visible result. The mouse pointer is visible only while a task runs; the small control panel (pause/stop/confirm) appears with it and can be dragged by its status text.

## Local on-device model (optional, offline)
Settings > "Choose model file (.task)": pick a Gemma-style instruction-tuned MediaPipe `.task` model you downloaded yourself (typically from Kaggle or Hugging Face; some require accepting a licence). It is copied into the app and used only to translate a free-form sentence into steps; it runs on the phone's CPU, so expect tens of seconds per command on a mid-range device. It remains a small on-device text-to-steps translator, not a full reasoning model; it does not provide reliable per-screen reasoning, conditional branches, or long cross-app planning by itself.


## Improved agent reasoning prompt
The cloud agent now receives an expanded planning policy for multi-stage tasks: decompose the goal, keep progress in `note`, inspect and verify each step, handle conditional quota checks without inventing values, and stop at authentication/permission barriers. It treats sending/uploading/submitting as sensitive and requires confirmation. This is prompt engineering and workflow guidance, **not fine-tuning/training the underlying language model**. The app still needs a configured cloud model/backend for strong open-ended reasoning; the local `.task` model is optional and limited.

## Changes in build 10
- **Agent reliability**: the model now receives each node's position (`pos`), pixel `bounds` and the screen size, so icon-only buttons (the ☰ menu) can be told apart; the history records which element was clicked plus a digest of the screen that followed; values read from the screen are kept in `note` across app switches; the first `done` is audited once ("list each subgoal with evidence"); rate-limit/JSON errors are retried instead of ending the task. Accessibility config now includes not-important views.
- **Overlay**: windows are added through the accessibility service (`TYPE_ACCESSIBILITY_OVERLAY`, trusted on Android 12+), the full-screen cursor window is gone (the pointer is a tiny window), taps are detected manually, and the service is a foreground service with a notification offering Pause / Stop / Hide. It removes itself ~6 s after the task ends.
- **UI**: liquid-glass dark theme (Arabic, RTL). Keyboard: `adjustNothing` + a single `imePadding()`.
- Backend contract: node objects now omit false/empty fields and add `pos`, `bounds`, `cls`; the screen object adds `w`, `h`.
- Not compiled here (no Gradle/network): send build errors back verbatim.

## Build 11: vision
Each AI step now also sends a 720px JPEG screenshot (AccessibilityService.takeScreenshot, Android 11+, `canTakeScreenshot`) to a vision model (default `meta-llama/llama-4-scout-17b-16e-instruct`, editable in Settings; switch off with "رؤية الشاشة بالصور"). If the vision call is rejected, it falls back to the text-only model. After installing, switch the accessibility service off and on once so Android grants the new screenshot capability.

## Build 12: voice, recovery, icon
- **Voice in**: mic button (shown when the box is empty). Android SpeechRecognizer, language `ar-SY` by default (Settings). Say "توقف" to stop a running task. Conversation mode re-listens after every reply while the app is in front.
- **Voice out**: neural voice via an OpenAI-compatible `/audio/speech` endpoint; default Groq `canopylabs/orpheus-arabic-saudi` (voices noura, lulwa, aisha, fahad, sultan), same API key, cached on disk, fallback to the phone's TextToSpeech. Replies are spoken when the command was spoken (or "رد صوتي دائماً" is on). When the agent asks a question by voice it brings this app to the front and listens for the answer.
- **Starting state**: after opening an app, the agent is told the app may have restored an old state (playing video, open menu, dialog, editor) and must reach the main screen first without pausing media.
- **Icon**: new graphite glass icon (adaptive + monochrome themed icon).
- Needs permissions: RECORD_AUDIO (asked on first mic tap).

## Build 13: speed
- Screen read once per step (the post-action snapshot is reused), hidden subtrees skipped, accessibility "not-important views" flag removed (far fewer nodes).
- Screenshot only when needed (model sets `look`, previous step unverified, app just opened, or sparse tree) and read in parallel with the tree; 640px JPEG.
- One fast model (vision model, default Llama 4 Scout) for every step; `max_tokens` 400; compact node JSON (bounds only for unlabeled nodes), 10 history entries, fewer nodes -> far fewer tokens, so fewer 429 waits. 429 waits use the provider's own "try again in X" time.
- Shorter settle delays (adaptive) and pointer animation; the completion audit only runs in the first 5 steps.

## Build 14: smart planner + fast executor
- `plan()`: one call to the smart model (Settings > "النموذج الذكي") turns the request into ordered subgoals + the first app; the plan is shown in the chat and injected every step as a fixed PLAN line.
- The first app is opened directly by the controller (no model turn); `thenEnter` chains type+Enter in one turn.
- The fast model (Settings > "النموذج السريع") executes every step; `nextSmart()` (smart model, text-only) takes over when stuck (2 unverified actions, repeated action, rejected actions) or to verify completion, only if the screen tree is readable.
- If both fields hold the same model, or the fast mode is switched off, planning is skipped.

## Build 15: no more "waiting for server"
- Groq rate limits are per model. On a 429 the app now switches instantly to another model (fast → smart → llama-3.1-8b-instant) instead of sleeping; it waits only if every model is limited, and never more than 8 s (a limit longer than 20 s is reported at once, not waited out).
- The "try again in 7m12s" format is parsed correctly (before, minutes were misread and caused 30 s waits).
- Short commands (≤ 60 chars) skip the planning call; the completion audit only runs when a plan exists. Both consumed the 70B model's small per-minute quota.
- Fewer tokens per step: 40 nodes with a screenshot (60 without), 12 history entries, max_tokens 350, request timeout 25 s.
- Shorter settle delays (taps 300 ms, app launch 800 ms, pointer 120 ms).
- Not compiled here: send build errors back verbatim.

## Build 16: never stops + voice picker
- Provider pool: Groq fast → Gemini Flash-Lite → Groq smart → Gemini Flash → Groq 8B. Each pair has its own quota; a limited one is skipped instantly (its own retry hint is honoured, including Gemini's "retry in 26s" / retryDelay format). Invalid-key (401/403) slots are skipped for 10 min.
- Multiple Groq keys: Settings > "مفاتيح API" (one per line) and/or build-time `AI_API_KEYS=k1,k2,...` (ai.properties or CI secret). Every (model, key) pair is its own slot; the same model is tried across all keys before the next model, and block times persist between commands. Groq free quotas are per organization, so keys only add capacity when they come from different accounts. A 401/403 blocks every slot of that key for 10 min.
- Settings: optional free Gemini key (aistudio.google.com/apikey), stored encrypted. Without it the app still works on Groq only and says so when every model is limited.
- Voice picker on first mic press: 5 Groq voices + Arabic voices installed on the phone, each with a "listen" button. Also in Settings.
- Not compiled here: send build errors back verbatim.

## Build 17: compile fixes
- `Voice.setHandsFree()` clashed with the JVM setter generated for the `handsFree` property: renamed to `applyHandsFree()` (Voice.kt, MainActivity.kt).
- `continue` inside `?.let { }` lambdas in Local.kt (needs the experimental BreakContinueInInlineLambdas flag on older Kotlin): rewritten as plain `if` blocks, so no compiler flag is needed.

## Build 15: fixes from the in-app APK builder
- **Gemini 404** ("gemini-2.5-flash is no longer available to new users"): the model picker, defaults and fallbacks now use `gemini-3.8-flash`, `gemini-3.6-flash`, `gemini-3.5-flash-lite`, `gemini-3.1-pro-preview`; a saved 2.5 choice is migrated automatically. Image generation uses `gemini-3.1-flash-image` (old 2.5 image model only as fallback).
- A 404 / "no longer available" answer now skips only that model (the next provider is tried) instead of aborting the whole task.
- **Builder**: the Node.js 20 notice is a runner warning, not a build error. The log parser ignores `##[warning]` lines and now picks up `##[error]`, Gradle "Execution failed / Could not resolve" and `FAILURE:` lines, so the model receives the real error. Generated workflows set `FORCE_JAVASCRIPT_ACTIONS_TO_NODE24`.
- Not compiled here (no Gradle/network): send build errors back verbatim.
