package com.aiphoneagent

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.StartOffset
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import kotlin.reflect.KProperty
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.core.content.FileProvider
import java.io.File
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch

// Palette: dark graphite + slightly dimmed off-white. No accent hue on purpose.
private val Ink = Color(0xFFE4E1DA)
private val InkDim = Color(0xFF9C9A93)
private val Danger = Color(0xFFDB9A93)
private val Ok = Color(0xFF93AE9A)

/** True while the app window is in front (the microphone can only be used then). */
object AppVisible { var value by mutableStateOf(false) }

private val STOP_WORDS by lazy { listOf("توقف", "وقف", "قف", "stop", "ستوب", "اسكت", "كفى", "خلص").map { Norm.key(it) }.toSet() }

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        AgentController.init(applicationContext)
        AppBuilder.init(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Ink, onPrimary = Color(0xFF131315), background = Color(0xFF131315), surface = Color(0xFF131315), onSurface = Ink)) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { HomeScreen(tick) }
            }
        }
    }
    override fun onResume() { super.onResume(); AppVisible.value = true; tick++ }
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) MediaDownloader.checkClipboard(this)
    }
    override fun onPause() { AppVisible.value = false; AgentController.persistNow(); super.onPause() }
}

/** Frosted-glass surface: translucent gradient fill + light-catching edge. Brushes and outline are cached (cheap to redraw). */
private fun Modifier.glass(shape: Shape, strength: Float = 1f): Modifier = this
    .clip(shape)
    .drawWithCache {
        val fill = Brush.linearGradient(listOf(
            Color.White.copy(alpha = (0.13f * strength).coerceAtMost(0.4f)),
            Color.White.copy(alpha = (0.04f * strength).coerceAtMost(0.4f)),
            Color.White.copy(alpha = (0.08f * strength).coerceAtMost(0.4f))))
        val edge = Brush.linearGradient(listOf(Color.White.copy(alpha = 0.34f), Color.White.copy(alpha = 0.04f), Color.White.copy(alpha = 0.16f)))
        val path = when (val o = shape.createOutline(size, layoutDirection, this)) {
            is Outline.Rounded -> Path().apply { addRoundRect(o.roundRect) }
            is Outline.Generic -> o.path
            is Outline.Rectangle -> Path().apply { addRect(o.rect) }
        }
        val st = Stroke(2.dp.toPx())   // half of it is clipped: 1 dp edge
        onDrawBehind { drawPath(path, fill); drawPath(path, edge, style = st) }
    }

/** Click with a visible press: the control darkens a little while the finger is down. */
@Composable
private fun Modifier.pressable(enabled: Boolean = true, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val dark by animateFloatAsState(if (pressed) 0.40f else 0f, tween(90), label = "press")
    return this.drawBehind { if (dark > 0f) drawRect(Color.Black.copy(alpha = dark)) }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

/** Text field state whose cursor goes to the end when the text is set from code (e.g. tapping a /command chip). */
private class InputState { var tfv by mutableStateOf(TextFieldValue("")) }
private operator fun InputState.getValue(t: Any?, p: KProperty<*>): String = tfv.text
private operator fun InputState.setValue(t: Any?, p: KProperty<*>, v: String) { tfv = TextFieldValue(v, TextRange(v.length)) }

private fun Modifier.sheet(shape: Shape): Modifier = this
    .clip(shape).background(Color(0xF21E1E21)).glass(shape, 0.9f)

@Composable
private fun GlassButton(label: String, modifier: Modifier = Modifier, enabled: Boolean = true, strong: Boolean = false, tint: Color = Ink, onClick: () -> Unit) {
    Box(
        modifier.alpha(if (enabled) 1f else 0.4f)
            .glass(RoundedCornerShape(14.dp), if (strong) 1.8f else 1f)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = tint, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
}

@Composable
private fun GlassField(label: String, value: String, onChange: (String) -> Unit, secret: Boolean = false, lines: Int = 1) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, color = InkDim, fontSize = 12.sp)
        BasicTextField(
            value, onChange,
            Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp), 0.7f).padding(horizontal = 12.dp, vertical = 11.dp),
            singleLine = lines == 1,
            minLines = lines, maxLines = if (lines == 1) 1 else 8,
            textStyle = TextStyle(color = Ink, fontSize = 14.sp, textDirection = TextDirection.Ltr),
            cursorBrush = SolidColor(Ink),
            visualTransformation = when { !secret -> VisualTransformation.None; lines > 1 -> MaskKeepBreaks; else -> PasswordVisualTransformation() }
        )
    }
}

/** Masks characters but keeps line breaks, so several keys stay readable as separate lines. */
private val MaskKeepBreaks = object : VisualTransformation {
    override fun filter(text: AnnotatedString) = TransformedText(
        AnnotatedString(text.text.map { if (it == '\n' || it == ' ' || it == ',') it else '\u2022' }.joinToString("")),
        OffsetMapping.Identity)
}

@Composable
private fun TuneIcon() = Canvas(Modifier.size(18.dp)) {
    val s = size.width; val sw = 1.6.dp.toPx()
    drawLine(Ink, Offset(0f, s * 0.3f), Offset(s, s * 0.3f), sw, StrokeCap.Round)
    drawLine(Ink, Offset(0f, s * 0.7f), Offset(s, s * 0.7f), sw, StrokeCap.Round)
    drawCircle(Ink, s * 0.15f, Offset(s * 0.65f, s * 0.3f))
    drawCircle(Ink, s * 0.15f, Offset(s * 0.35f, s * 0.7f))
}

@Composable
private fun SendIcon() = Canvas(Modifier.size(20.dp)) {
    val s = size.width; val sw = 2.dp.toPx()
    drawLine(Ink, Offset(s / 2, s * 0.88f), Offset(s / 2, s * 0.14f), sw, StrokeCap.Round)
    drawLine(Ink, Offset(s * 0.2f, s * 0.42f), Offset(s / 2, s * 0.12f), sw, StrokeCap.Round)
    drawLine(Ink, Offset(s * 0.8f, s * 0.42f), Offset(s / 2, s * 0.12f), sw, StrokeCap.Round)
}

@Composable
private fun MicIcon() = Canvas(Modifier.size(22.dp)) {
    val s = size.width; val sw = 1.8.dp.toPx()
    drawRoundRect(Ink, Offset(s * 0.36f, s * 0.08f), Size(s * 0.28f, s * 0.5f), CornerRadius(s * 0.14f))
    drawArc(Ink, 0f, 180f, false, Offset(s * 0.2f, s * 0.28f), Size(s * 0.6f, s * 0.48f), style = Stroke(sw, cap = StrokeCap.Round))
    drawLine(Ink, Offset(s * 0.5f, s * 0.76f), Offset(s * 0.5f, s * 0.92f), sw, StrokeCap.Round)
    drawLine(Ink, Offset(s * 0.34f, s * 0.92f), Offset(s * 0.66f, s * 0.92f), sw, StrokeCap.Round)
}

@Composable
private fun Bubble(m: ChatMsg, canAct: Boolean, showRetry: Boolean, onLongPress: () -> Unit, onMore: () -> Unit, onRetry: () -> Unit, onGrow: () -> Unit) {
    val ctx = LocalContext.current
    // New AI replies appear progressively (loading animation of the text); old ones are shown at once.
    var shown by remember(m.id) { mutableIntStateOf(if (!m.fromUser && m.animate) 0 else m.text.length) }
    LaunchedEffect(m.id) {
        if (!m.fromUser && m.animate) {
            m.animate = false
            val len = m.text.length
            val step = maxOf(1, len / 90)
            var n = 0
            while (shown < len) { shown = minOf(len, shown + step); delay(16); if (++n % 6 == 0) onGrow() }
            onGrow()
        }
    }
    val done = shown >= m.text.length
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (m.fromUser) Alignment.Start else Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Box(
            Modifier.widthIn(max = 300.dp)
                .glass(RoundedCornerShape(20.dp), if (m.fromUser) 1.7f else 0.75f)
                .pointerInput(m.id) { detectTapGestures(onLongPress = { onLongPress() }) }
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (m.fromUser) m.atts.chunked(3).forEach { rowAtts ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { rowAtts.forEach { AttachThumb(it, 84.dp) } }
                } else m.atts.forEach { a -> AttachThumb(a, 230.dp) { openMedia(ctx, a) } }
                if (m.text.isNotBlank()) Text(m.text.take(shown), color = if (m.fromUser) Ink else Ink.copy(alpha = 0.92f), fontSize = 15.sp, lineHeight = 22.sp)
            }
        }
        if (!m.fromUser && m.text.isNotBlank() && done) ReplyActions(m, canAct && showRetry, onMore, onRetry)
    }
}

private fun openMedia(ctx: Context, a: Attachment) {
    runCatching {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(a.path))
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, a.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

@Composable
private fun SmallIconBtn(enabled: Boolean = true, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.size(34.dp).alpha(if (enabled) 1f else 0.4f).clip(CircleShape).clickable(enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) { content() }
}

/** The reply actions, always visible under the answer (no long press needed): more, share, speak, dislike, like, copy, retry. */
@Composable
private fun ReplyActions(m: ChatMsg, canRetry: Boolean, onMore: () -> Unit, onRetry: () -> Unit) {
    val ctx = LocalContext.current
    val dim = InkDim
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.padding(start = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            SmallIconBtn(onClick = onMore) { LineIcon(17.dp) { s, _ -> icDots(dim, s) } }
            SmallIconBtn(onClick = { ctx.shareText(m.text) }) { LineIcon(17.dp) { s, sw -> icShare(dim, s, sw) } }
            SmallIconBtn(onClick = { if (Voice.speaking) Voice.stopSpeaking() else Voice.speak(m.text) }) {
                LineIcon(17.dp) { s, sw -> icSpeaker(if (Voice.speaking) Ok else dim, s, sw) }
            }
            SmallIconBtn(onClick = { m.reaction = if (m.reaction == -1) 0 else -1 }) {
                LineIcon(17.dp) { s, sw -> icThumb(if (m.reaction == -1) Danger else dim, s, sw, up = false, filled = m.reaction == -1) }
            }
            SmallIconBtn(onClick = { m.reaction = if (m.reaction == 1) 0 else 1 }) {
                LineIcon(17.dp) { s, sw -> icThumb(if (m.reaction == 1) Ok else dim, s, sw, up = true, filled = m.reaction == 1) }
            }
            SmallIconBtn(onClick = { ctx.copyText(m.text) }) { LineIcon(17.dp) { s, sw -> icCopy(dim, s, sw) } }
            if (canRetry) SmallIconBtn(onClick = onRetry) { LineIcon(17.dp) { s, sw -> icRetry(dim, s, sw) } }
        }
    }
}

// ---------------------------------------------------------------- message actions (long press)

private val MONTHS_AR = listOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")

/** "٢٣ أكتوبر ٢٠٢٦ ١:٥٧ م": exact send time, Arabic-Indic digits, independent of the phone's locale. */
private fun stamp(ms: Long): String {
    val c = java.util.Calendar.getInstance().apply { timeInMillis = ms }
    val h24 = c.get(java.util.Calendar.HOUR_OF_DAY)
    val h = if (h24 % 12 == 0) 12 else h24 % 12
    val mm = c.get(java.util.Calendar.MINUTE).toString().padStart(2, '0')
    val s = "${c.get(java.util.Calendar.DAY_OF_MONTH)} ${MONTHS_AR[c.get(java.util.Calendar.MONTH)]} ${c.get(java.util.Calendar.YEAR)} $h:$mm ${if (h24 < 12) "ص" else "م"}"
    return s.map { if (it in '0'..'9') '\u0660' + (it - '0') else it }.joinToString("")
}

private fun Context.copyText(t: String) {
    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("message", t))
    Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show()
}

private fun Context.shareText(t: String) {
    runCatching {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), null)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

// Line icons drawn on a canvas, same style as the rest of the app (no emoji, no icon library).
private fun DrawScope.strokeOf(sw: Float) = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round)

private fun DrawScope.icDots(c: Color, s: Float) { listOf(0.2f, 0.5f, 0.8f).forEach { drawCircle(c, s * 0.075f, Offset(s * 0.5f, s * it)) } }

private fun DrawScope.icShare(c: Color, s: Float, sw: Float) {
    val st = strokeOf(sw)
    drawCircle(c, s * 0.12f, Offset(s * 0.78f, s * 0.2f), style = st)
    drawCircle(c, s * 0.12f, Offset(s * 0.22f, s * 0.5f), style = st)
    drawCircle(c, s * 0.12f, Offset(s * 0.78f, s * 0.8f), style = st)
    drawLine(c, Offset(s * 0.33f, s * 0.44f), Offset(s * 0.67f, s * 0.26f), sw, StrokeCap.Round)
    drawLine(c, Offset(s * 0.33f, s * 0.56f), Offset(s * 0.67f, s * 0.74f), sw, StrokeCap.Round)
}

private fun DrawScope.icSpeaker(c: Color, s: Float, sw: Float) {
    val st = strokeOf(sw)
    val p = Path().apply {
        moveTo(s * 0.08f, s * 0.4f); lineTo(s * 0.26f, s * 0.4f); lineTo(s * 0.46f, s * 0.2f)
        lineTo(s * 0.46f, s * 0.8f); lineTo(s * 0.26f, s * 0.6f); lineTo(s * 0.08f, s * 0.6f); close()
    }
    drawPath(p, c, style = st)
    drawArc(c, -45f, 90f, false, Offset(s * 0.4f, s * 0.3f), Size(s * 0.3f, s * 0.4f), style = st)
    drawArc(c, -50f, 100f, false, Offset(s * 0.33f, s * 0.15f), Size(s * 0.55f, s * 0.7f), style = st)
}

private fun DrawScope.icThumb(c: Color, s: Float, sw: Float, up: Boolean, filled: Boolean) {
    val body = Path().apply {
        moveTo(s * 0.34f, s * 0.46f); lineTo(s * 0.47f, s * 0.14f)
        cubicTo(s * 0.62f, s * 0.12f, s * 0.64f, s * 0.30f, s * 0.58f, s * 0.42f)
        lineTo(s * 0.80f, s * 0.42f)
        cubicTo(s * 0.90f, s * 0.42f, s * 0.93f, s * 0.50f, s * 0.91f, s * 0.58f)
        lineTo(s * 0.85f, s * 0.78f)
        cubicTo(s * 0.82f, s * 0.86f, s * 0.77f, s * 0.88f, s * 0.70f, s * 0.88f)
        lineTo(s * 0.34f, s * 0.88f); close()
    }
    scale(1f, if (up) 1f else -1f, Offset(s / 2, s / 2)) {
        if (filled) {
            drawPath(body, c)
            drawRoundRect(c, Offset(s * 0.08f, s * 0.46f), Size(s * 0.18f, s * 0.42f), CornerRadius(s * 0.05f), style = Fill)
        } else {
            drawPath(body, c, style = strokeOf(sw))
            drawRoundRect(c, Offset(s * 0.08f, s * 0.46f), Size(s * 0.18f, s * 0.42f), CornerRadius(s * 0.05f), style = strokeOf(sw))
        }
    }
}

private fun DrawScope.icCopy(c: Color, s: Float, sw: Float) {
    val st = strokeOf(sw)
    drawRoundRect(c, Offset(s * 0.12f, s * 0.3f), Size(s * 0.5f, s * 0.58f), CornerRadius(s * 0.09f), style = st)
    val back = Path().apply {
        moveTo(s * 0.32f, s * 0.22f); quadraticBezierTo(s * 0.32f, s * 0.12f, s * 0.42f, s * 0.12f)
        lineTo(s * 0.78f, s * 0.12f); quadraticBezierTo(s * 0.88f, s * 0.12f, s * 0.88f, s * 0.22f)
        lineTo(s * 0.88f, s * 0.58f); quadraticBezierTo(s * 0.88f, s * 0.68f, s * 0.78f, s * 0.68f)
        lineTo(s * 0.7f, s * 0.68f)
    }
    drawPath(back, c, style = st)
}

private fun DrawScope.icRetry(c: Color, s: Float, sw: Float) {
    val st = strokeOf(sw)
    drawArc(c, -60f, 290f, false, Offset(s * 0.18f, s * 0.18f), Size(s * 0.64f, s * 0.64f), style = st)
    val a = Math.toRadians(230.0)
    val r = s * 0.32f
    val tx = s * 0.5f + r * Math.cos(a).toFloat(); val ty = s * 0.5f + r * Math.sin(a).toFloat()
    val dx = (-Math.sin(a)).toFloat(); val dy = Math.cos(a).toFloat()   // direction of travel at the arc end
    for (deg in listOf(35.0, -35.0)) {
        val t = Math.toRadians(deg)
        val bx = -dx * Math.cos(t).toFloat() + dy * Math.sin(t).toFloat()
        val by = -dy * Math.cos(t).toFloat() - dx * Math.sin(t).toFloat()
        drawLine(c, Offset(tx, ty), Offset(tx + bx * s * 0.2f, ty + by * s * 0.2f), sw, StrokeCap.Round)
    }
}

private fun DrawScope.icEdit(c: Color, s: Float, sw: Float) {
    val p = Path().apply {
        moveTo(s * 0.18f, s * 0.84f); lineTo(s * 0.22f, s * 0.62f); lineTo(s * 0.66f, s * 0.18f)
        lineTo(s * 0.82f, s * 0.34f); lineTo(s * 0.38f, s * 0.78f); close()
    }
    drawPath(p, c, style = strokeOf(sw))
    drawLine(c, Offset(s * 0.58f, s * 0.26f), Offset(s * 0.74f, s * 0.42f), sw, StrokeCap.Round)
}

private fun DrawScope.icClip(c: Color, s: Float, sw: Float) {
    val p = Path().apply {
        moveTo(s * 0.40f, s * 0.70f); lineTo(s * 0.40f, s * 0.30f)
        cubicTo(s * 0.40f, s * 0.10f, s * 0.70f, s * 0.10f, s * 0.70f, s * 0.30f)
        lineTo(s * 0.70f, s * 0.72f)
        cubicTo(s * 0.70f, s * 0.92f, s * 0.30f, s * 0.92f, s * 0.30f, s * 0.72f)
        lineTo(s * 0.30f, s * 0.38f)
    }
    drawPath(p, c, style = strokeOf(sw))
}

private fun DrawScope.icChevron(c: Color, s: Float, sw: Float, up: Boolean) {
    val y1 = if (up) 0.65f else 0.35f; val y2 = if (up) 0.35f else 0.65f
    drawLine(c, Offset(s * 0.2f, s * y1), Offset(s * 0.5f, s * y2), sw, StrokeCap.Round)
    drawLine(c, Offset(s * 0.5f, s * y2), Offset(s * 0.8f, s * y1), sw, StrokeCap.Round)
}

private fun DrawScope.icSelect(c: Color, s: Float, sw: Float) {
    drawRoundRect(c, Offset(s * 0.08f, s * 0.14f), Size(s * 0.84f, s * 0.72f), CornerRadius(s * 0.1f),
        style = Stroke(sw, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(sw * 2.2f, sw * 1.8f))))
    drawLine(c, Offset(s * 0.5f, s * 0.3f), Offset(s * 0.5f, s * 0.7f), sw, StrokeCap.Round)
    drawLine(c, Offset(s * 0.4f, s * 0.3f), Offset(s * 0.6f, s * 0.3f), sw, StrokeCap.Round)
    drawLine(c, Offset(s * 0.4f, s * 0.7f), Offset(s * 0.6f, s * 0.7f), sw, StrokeCap.Round)
}

/** One tappable strip per run: live status while working, the full step log when expanded. */
@Composable
private fun TypingDots(label: String?) {
    val t = rememberInfiniteTransition(label = "dots")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Row(
            Modifier.glass(RoundedCornerShape(18.dp), 0.75f).padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            repeat(3) { i ->
                val a by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(480), RepeatMode.Reverse, initialStartOffset = StartOffset(i * 160)), label = "dot$i")
                Box(Modifier.size(7.dp).graphicsLayer { alpha = a; val sc = 0.75f + 0.25f * a; scaleX = sc; scaleY = sc }.clip(CircleShape).background(Ink))
            }
            if (label != null) Text(label, color = InkDim, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp))
        }
    }
}

@Composable
private fun ThinkingCard(m: ChatMsg, status: String, pulse: () -> Float) {
    var open by remember(m.id) { mutableStateOf(false) }
    val live = !m.finished
    val n = m.steps.size
    if (live && n == 0 && !AgentController.phoneActive) {
        TypingDots(status.takeIf { it.isNotBlank() && it != "Idle" && it != "أفكر…" })
        return
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Column(
            Modifier.widthIn(max = 320.dp).glass(RoundedCornerShape(18.dp), 0.6f)
                .clickable { open = !open }.padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(8.dp).graphicsLayer { alpha = if (live) pulse() else 0.6f }.clip(CircleShape).background(if (live) Ok else InkDim))
                Text(
                    if (live) status.takeIf { it.isNotBlank() && it != "Idle" } ?: "يفكّر…" else "تم التفكير · $n ${if (n == 1) "خطوة" else "خطوات"}",
                    Modifier.weight(1f, fill = false), color = InkDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                LineIcon(14.dp) { s, sw -> icChevron(InkDim, s, sw, open) }
            }
            if (open) {
                Column(Modifier.padding(top = 8.dp).heightIn(max = 240.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (m.steps.isEmpty()) Text("لا توجد خطوات بعد.", color = InkDim, fontSize = 12.sp)
                    m.steps.toList().forEach { Text(it, color = InkDim, fontSize = 12.sp, lineHeight = 17.sp) }
                }
            }
        }
    }
}

@Composable
private fun LineIcon(dp: Dp = 20.dp, draw: DrawScope.(Float, Float) -> Unit) =
    Canvas(Modifier.size(dp)) { draw(this.size.width, 1.7.dp.toPx()) }

@Composable
private fun IconBtn(enabled: Boolean = true, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.size(42.dp).alpha(if (enabled) 1f else 0.4f).clip(CircleShape).clickable(enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) { content() }
}

@Composable
private fun PillAction(label: String, enabled: Boolean = true, icon: @Composable () -> Unit, onClick: () -> Unit) {
    Row(
        Modifier.alpha(if (enabled) 1f else 0.4f).glass(RoundedCornerShape(16.dp), 1.3f)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) { icon(); Text(label, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
}

/** The whole text pre-selected (handles + system toolbar appear), so "select text" is one tap. */
@Composable
private fun SelectAllText(text: String) {
    val fr = remember { FocusRequester() }
    var v by remember { mutableStateOf(TextFieldValue(text, TextRange(0, text.length))) }
    BasicTextField(
        v, { if (it.text == text) v = it }, Modifier.focusRequester(fr), readOnly = true,
        textStyle = TextStyle(color = Ink, fontSize = 15.sp, lineHeight = 22.sp), cursorBrush = SolidColor(Ink)
    )
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
}

@Composable
private fun MessageActions(m: ChatMsg, canAct: Boolean, onDismiss: () -> Unit, onEdit: () -> Unit, onRetry: () -> Unit) {
    val ctx = LocalContext.current
    var selectAll by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = if (m.fromUser) Alignment.Start else Alignment.End
        ) {
            if (m.fromUser) Text(stamp(m.time), Modifier.padding(horizontal = 6.dp), color = Ink, fontSize = 12.sp)
            Box(Modifier.widthIn(max = 320.dp).sheet(RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 10.dp)) {
                if (selectAll) SelectAllText(m.text)
                else SelectionContainer { Text(m.text, color = Ink, fontSize = 15.sp, lineHeight = 22.sp) }
            }
            if (m.fromUser) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillAction("تعديل", canAct, { LineIcon(18.dp) { s, sw -> icEdit(Ink, s, sw) } }) { onEdit() }
                    PillAction("نسخ", true, { LineIcon(18.dp) { s, sw -> icCopy(Ink, s, sw) } }) { ctx.copyText(m.text); onDismiss() }
                    PillAction("تحديد النص", true, { LineIcon(18.dp) { s, sw -> icSelect(Ink, s, sw) } }) { selectAll = true }
                }
            } else {
                // Icon order matches the reference: more, share, speak, dislike, like, copy (+ retry).
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(Modifier.glass(RoundedCornerShape(24.dp), 1.1f).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBtn(onClick = { selectAll = true }) { LineIcon { s, _ -> icDots(Ink, s) } }
                        IconBtn(onClick = { ctx.shareText(m.text); onDismiss() }) { LineIcon { s, sw -> icShare(Ink, s, sw) } }
                        IconBtn(onClick = { if (Voice.speaking) Voice.stopSpeaking() else Voice.speak(m.text) }) {
                            LineIcon { s, sw -> icSpeaker(if (Voice.speaking) Ok else Ink, s, sw) }
                        }
                        IconBtn(onClick = { m.reaction = if (m.reaction == -1) 0 else -1 }) {
                            LineIcon { s, sw -> icThumb(if (m.reaction == -1) Danger else Ink, s, sw, up = false, filled = m.reaction == -1) }
                        }
                        IconBtn(onClick = { m.reaction = if (m.reaction == 1) 0 else 1 }) {
                            LineIcon { s, sw -> icThumb(if (m.reaction == 1) Ok else Ink, s, sw, up = true, filled = m.reaction == 1) }
                        }
                        IconBtn(onClick = { ctx.copyText(m.text); onDismiss() }) { LineIcon { s, sw -> icCopy(Ink, s, sw) } }
                        IconBtn(enabled = canAct, onClick = onRetry) { LineIcon { s, sw -> icRetry(Ink, s, sw) } }
                    }
                }
            }
        }
    }
}

@Composable
private fun SetupRow(title: String, body: String, action: String, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(body, color = InkDim, fontSize = 12.sp, lineHeight = 17.sp)
        }
        GlassButton(action, strong = true, onClick = onClick)
    }
}

private val OrbColors = listOf(
    listOf(Color(0xFFEAF6FF), Color(0xFF8FB4F0), Color(0xFFCFE8FF)),
    listOf(Color(0xFFFFEFD0), Color(0xFFF7C873), Color(0xFFFFE6BC)),
    listOf(Color(0xFFB7C9F6), Color(0xFF6F7BD0), Color(0xFF93A8EA)),
    listOf(Color(0xFFFFD9E4), Color(0xFFEE8FB0), Color(0xFFFFC2D6)),
    listOf(Color(0xFFD6F5E4), Color(0xFF6FCB9C), Color(0xFFBDEBD3))
)

/** A soft moving pill; it moves faster and swells slightly while the voice is speaking. */
@Composable
private fun VoiceOrb(colors: List<Color>, speaking: Boolean) {
    val t = rememberInfiniteTransition(label = "orb")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(if (speaking) 1500 else 5000, easing = LinearEasing), RepeatMode.Restart), label = "orbP")
    val grow by animateFloatAsState(if (speaking) 1.07f else 1f, tween(300), label = "orbGrow")
    Canvas(Modifier.size(225.dp, 125.dp).graphicsLayer { scaleX = grow; scaleY = grow }.clip(RoundedCornerShape(50))) {
        val w = size.width; val h = size.height
        val a = p * 2f * PI.toFloat()
        drawRect(colors[0])
        val c1 = Offset(w * (0.30f + 0.22f * sin(a)), h * (0.50f + 0.30f * cos(a)))
        drawCircle(Brush.radialGradient(listOf(colors[1], Color.Transparent), center = c1, radius = w * 0.42f), radius = w * 0.42f, center = c1)
        val c2 = Offset(w * (0.72f + 0.20f * cos(a + 1f)), h * (0.42f + 0.30f * sin(a + 2f)))
        drawCircle(Brush.radialGradient(listOf(colors[2], Color.Transparent), center = c2, radius = w * 0.38f), radius = w * 0.38f, center = c2)
    }
}

/** Swipe between voices: each one plays by itself, shows its name while it speaks, and the button says "مختار" for the saved one. */
@Composable
private fun VoicePicker(onDone: (listen: Boolean) -> Unit) {
    var confirmed by remember { mutableStateOf(Voice.voiceName) }
    var didConfirm by remember { mutableStateOf(false) }
    var sys by remember { mutableStateOf(emptyList<Pair<String, String>>()) }
    LaunchedEffect(Unit) {
        repeat(10) {
            sys = Voice.systemVoices()
            if (sys.isNotEmpty()) return@LaunchedEffect
            kotlinx.coroutines.delay(400)
        }
    }
    // (display name, id, short description)
    val all = listOf(
        Triple("نورة", "noura", "صوت أنثوي"), Triple("لولوة", "lulwa", "صوت أنثوي"), Triple("عائشة", "aisha", "صوت أنثوي"),
        Triple("فهد", "fahad", "صوت ذكوري"), Triple("سلطان", "sultan", "صوت ذكوري")
    ) + sys.map { Triple(it.second, "sys:${it.first}", "صوت الهاتف") }
    val pager = rememberPagerState(initialPage = all.indexOfFirst { it.second == Voice.voiceName }.coerceAtLeast(0)) { all.size }
    var firstPage by remember { mutableStateOf(true) }
    LaunchedEffect(pager.settledPage) {
        if (firstPage) { firstPage = false; return@LaunchedEffect }
        all.getOrNull(pager.settledPage)?.let { Voice.preview(it.second) }
    }
    fun close() { Voice.stopSpeaking(); Voice.voiceName = confirmed; Voice.voiceChosen = true; onDone(didConfirm) }
    val current = all.getOrNull(pager.currentPage)
    val isSel = current != null && current.second == confirmed
    Dialog(onDismissRequest = { close() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { close() } }, contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier.fillMaxWidth().fillMaxHeight(0.68f).sheet(TopSheetShape).pointerInput(Unit) { detectTapGestures { } }
                    .navigationBarsPadding().padding(bottom = 16.dp)
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)).clickable { close() }, contentAlignment = Alignment.Center) {
                            LineIcon(18.dp) { s, sw ->
                                drawLine(Ink, Offset(s * 0.2f, s * 0.2f), Offset(s * 0.8f, s * 0.8f), sw, StrokeCap.Round)
                                drawLine(Ink, Offset(s * 0.8f, s * 0.2f), Offset(s * 0.2f, s * 0.8f), sw, StrokeCap.Round)
                            }
                        }
                        Text("صوت", Modifier.weight(1f), color = Ink, fontSize = 18.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.width(40.dp))
                    }
                    HorizontalPager(pager, Modifier.weight(1f).fillMaxWidth()) { page ->
                        val v = all[page]
                        val talking = Voice.speaking && pager.currentPage == page
                        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            VoiceOrb(OrbColors[page % OrbColors.size], talking)
                            Spacer(Modifier.height(26.dp))
                            Text(v.first, color = Ink, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(4.dp))
                            Text(if (talking) "يتحدث الآن…" else v.third, color = if (talking) Ok else InkDim, fontSize = 16.sp)
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        all.indices.forEach { i ->
                            Box(Modifier.padding(horizontal = 4.dp).size(8.dp).clip(CircleShape).background(if (i == pager.currentPage) Color(0xFF4F7CF7) else Color.White.copy(alpha = 0.25f)))
                        }
                    }
                }
                Box(
                    Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth().height(56.dp).clip(RoundedCornerShape(28.dp))
                        .background(if (isSel) Color(0xFF2E7D4F) else Color(0xFF4F7CF7))
                        .clickable(enabled = !isSel && current != null) {
                            current?.let { Voice.stopSpeaking(); Voice.voiceName = it.second; confirmed = it.second; didConfirm = true; Voice.voiceChosen = true }
                        },
                    contentAlignment = Alignment.Center
                ) { Text(if (isSel) "مختار" else "تأكيد", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
    }
}

@Composable
fun HomeScreen(tick: Int) {
    val ctx = LocalContext.current
    val c = AgentController
    val inputState = remember { InputState() }
    var input by inputState
    val kb = LocalSoftwareKeyboardController.current
    val focusMgr = LocalFocusManager.current
    val uiScope = rememberCoroutineScope()
    fun hideKeyboard() { kb?.hide(); focusMgr.clearFocus() }
    var showSettings by remember { mutableStateOf(false) }
    var showVoicePicker by remember { mutableStateOf(false) }
    var pickerFromSettings by remember { mutableStateOf(false) }
    var attachOpen by remember { mutableStateOf(false) }
    var modelOpen by remember { mutableStateOf(false) }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(20_000); nowMs = System.currentTimeMillis() } }
    var helpOpen by remember { mutableStateOf(false) }
    var voiceMode by remember { mutableStateOf(false) }
    var drawerOpen by remember { mutableStateOf(false) }
    var builderOpen by remember { mutableStateOf(false) }
    var delChat by remember { mutableStateOf<ChatMeta?>(null) }
    var micMuted by remember { mutableStateOf(false) }
    var vPaused by remember { mutableStateOf(false) }
    var menuMsg by remember { mutableStateOf<ChatMsg?>(null) }
    var editingId by remember { mutableStateOf<Long?>(null) }
    var a11yOn by remember { mutableStateOf(AgentAccessibilityService.instance != null) }
    LaunchedEffect(Unit) { while (true) { a11yOn = AgentAccessibilityService.instance != null; delay(1000) } }
    val needNotif = remember(tick) {
        Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val attachPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> if (uris.isNotEmpty()) c.addAttachments(uris) }
    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris -> if (uris.isNotEmpty()) c.addAttachments(uris) }
    var camUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    val photoCam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> camUri?.let { if (ok) c.addAttachments(listOf(it)) }; camUri = null }
    val videoCam = rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo()) { ok -> camUri?.let { if (ok) c.addAttachments(listOf(it)) }; camUri = null }
    fun newCamUri(ext: String): Uri {
        val d = File(ctx.cacheDir, "attach").apply { mkdirs() }
        return FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(d, "cam_${System.currentTimeMillis()}.$ext"))
    }
    val restricted = remember(tick) { A11yHelper.restricted(ctx) }
    val canSelf = remember(tick) { A11yHelper.canSelfEnable(ctx) }
    val list = rememberLazyListState()
    LaunchedEffect(c.messages.size) { if (c.messages.isNotEmpty()) list.animateScrollToItem(c.messages.size - 1) }

    // ---- voice ----
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0.45f, 1f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "pulseValue")
    val startVoiceNow: () -> Unit = {
        Voice.listen(ctx, onFinal = { t ->
            Voice.failStreak = 0
            if (Norm.key(t) in STOP_WORDS) c.stop() else c.submit(t, true)
        }, onFail = { m ->
            Voice.failStreak++
            if (voiceMode) {
                if (Voice.failStreak >= 2) micMuted = true   // stop the auto-listen loop; tapping the mic resumes it
            } else if (Voice.handsFree && Voice.failStreak >= 2) {
                Voice.applyHandsFree(false); c.info("أوقفت الاستماع التلقائي. اضغط المايك لما تحب تحكي.")
            } else if (!Voice.handsFree) c.info(m)
        }, continueMs = if (voiceMode) 1800L else 0L)
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startVoiceNow() else c.info("لازم تسمح بالميكروفون عشان أسمعك.")
    }
    val startVoice: () -> Unit = {
        if (!Voice.voiceChosen) { pickerFromSettings = false; showVoicePicker = true }
        else if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoiceNow()
        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
    }
    // The agent asked a question by voice and brought the app to the front: listen for the answer.
    LaunchedEffect(c.awaitingAnswer, tick, Voice.speaking, AppVisible.value) {
        if (c.awaitingAnswer && c.speakBack && AppVisible.value && !Voice.speaking && !Voice.listening && !showSettings && !showVoicePicker) {
            delay(300)
            if (c.awaitingAnswer && AppVisible.value && !Voice.listening && !Voice.speaking) startVoice()
        }
    }
    // Conversation mode: listen again after each reply while the app is in front.
    val autoListen = (Voice.handsFree || voiceMode) && !micMuted && !vPaused && !showSettings && !showVoicePicker
    LaunchedEffect(c.running, c.awaitingAnswer, tick, Voice.speaking, Voice.listening, autoListen, AppVisible.value) {
        if (autoListen && AppVisible.value && !c.running && !c.awaitingAnswer && !Voice.speaking && !Voice.listening) {
            delay(700)
            val still = (Voice.handsFree || voiceMode) && !micMuted && !vPaused && !showSettings && !showVoicePicker
            if (still && AppVisible.value && !c.running && !Voice.speaking && !Voice.listening) startVoice()
        }
    }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E1E21), Color(0xFF111113))))
            .drawBehind {
                // Two very soft gray lights behind the glass so it has something to refract.
                val r1 = size.width * 0.9f
                drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.075f), Color.Transparent), Offset(size.width * 0.85f, size.height * 0.12f), r1), r1, Offset(size.width * 0.85f, size.height * 0.12f))
                val r2 = size.width * 1.0f
                drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.05f), Color.Transparent), Offset(size.width * 0.05f, size.height * 0.78f), r2), r2, Offset(size.width * 0.05f, size.height * 0.78f))
            }
    ) {
        // Single inset handling: status bar + nav bar + keyboard, applied once (manifest uses adjustNothing so the window never resizes on its own).
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding().padding(horizontal = 14.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).glass(CircleShape).clickable { drawerOpen = true }, contentAlignment = Alignment.Center) {
                    LineIcon(20.dp) { s, sw -> listOf(0.28f, 0.5f, 0.72f).forEach { y -> drawLine(Ink, Offset(s * 0.15f, s * y), Offset(s * 0.85f, s * y), sw * 1.2f, StrokeCap.Round) } }
                }
                Spacer(Modifier.width(8.dp))
                CreditsPill(nowMs)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("AI Phone Agent", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).clip(CircleShape).background(if (c.running) Ink else if (a11yOn) Ok else Danger))
                        Spacer(Modifier.width(6.dp))
                        Text(if (c.running) "يعمل" else if (a11yOn) "جاهز" else "الخدمة غير مفعّلة", color = InkDim, fontSize = 12.sp)
                    }
                }
                Box(Modifier.size(42.dp).glass(CircleShape).clickable {
                    if (c.running) Toast.makeText(ctx, "أوقف المهمة الحالية أولاً", Toast.LENGTH_SHORT).show()
                    else { c.newChat(); input = "" }
                }, contentAlignment = Alignment.Center) {
                    LineIcon(20.dp) { s, sw ->
                        drawLine(Ink, Offset(s * 0.5f, s * 0.2f), Offset(s * 0.5f, s * 0.8f), sw * 1.2f, StrokeCap.Round)
                        drawLine(Ink, Offset(s * 0.2f, s * 0.5f), Offset(s * 0.8f, s * 0.5f), sw * 1.2f, StrokeCap.Round)
                    }
                }
            }

            MediaDownloader.clipUrl?.let { u ->
                Column(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp).glass(RoundedCornerShape(22.dp), 0.9f).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("رابط ${MediaDownloader.hostLabel(u)} منسوخ. تنزّله؟", color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(u, color = InkDim, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassButton("فيديو", Modifier.weight(1f), enabled = !MediaDownloader.busy, strong = true) { c.downloadLink(u, "video") }
                        GlassButton("صوت", Modifier.weight(1f), enabled = !MediaDownloader.busy) { c.downloadLink(u, "audio") }
                        GlassButton("صورة", Modifier.weight(1f), enabled = !MediaDownloader.busy) { c.downloadLink(u, "image") }
                        GlassButton("×", Modifier.weight(0.5f)) { MediaDownloader.dismiss() }
                    }
                }
            }
            if (MediaDownloader.busy) {
                Column(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("تنزيل جارٍ… " + MediaDownloader.status, color = InkDim, fontSize = 12.sp)
                    LinearProgressIndicator(progress = { MediaDownloader.progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Ink, trackColor = Color.White.copy(alpha = 0.10f))
                }
            }
            if (!a11yOn || needNotif) {
                Column(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp).glass(RoundedCornerShape(22.dp), 0.9f).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (!a11yOn) {
                        SetupRow("تفعيل خدمة إمكانية الوصول", "تسمح للمساعد بقراءة الشاشة والضغط والكتابة أثناء المهمة فقط.", "فتح") {
                            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                        Text(
                            if (helpOpen) "إخفاء المساعدة ▲" else "تظهر رسالة «إعداد مقيّد»؟ ▼",
                            color = InkDim, fontSize = 12.sp, modifier = Modifier.clickable { helpOpen = !helpOpen })
                        if (helpOpen) {
                            Text("افتح إعدادات التطبيق، ثم قائمة ⋮ أعلى اليمين، واختر «السماح بالإعدادات المقيّدة»، ثم ارجع وفعّل الخدمة.", color = InkDim, fontSize = 12.sp, lineHeight = 18.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                GlassButton("إعدادات التطبيق") {
                                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                                }
                                if (canSelf) GlassButton("تفعيل تلقائي", strong = true) { A11yHelper.selfEnable(ctx) }
                            }
                            Text("حالة الإعداد المقيّد: $restricted", color = InkDim, fontSize = 11.sp)
                            if (!canSelf) Text(
                                "بديل عبر الكمبيوتر: adb shell pm grant com.aiphoneagent android.permission.WRITE_SECURE_SETTINGS",
                                color = InkDim, fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                    if (needNotif) {
                        SetupRow("السماح بالإشعارات", "تعطي أزرار إيقاف مضمونة من شريط الإشعارات.", "سماح") {
                            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }
            }

            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (c.messages.isEmpty()) item { EmptyHero(Modifier.fillParentMaxSize()) }
                val lastAiId = c.messages.lastOrNull { !it.fromUser && !it.thinking }?.id
                items(c.messages, key = { it.id }) { m ->
                    if (m.thinking) ThinkingCard(m, c.status) { pulse }
                    else Bubble(m, canAct = !c.running, showRetry = m.id == lastAiId, onLongPress = { menuMsg = m }, onMore = { menuMsg = m }, onRetry = { c.retry(m) },
                        onGrow = { uiScope.launch { if (list.canScrollForward) list.scrollBy(2500f) } })
                }
            }

            if (c.running) {
                Column(Modifier.fillMaxWidth().padding(top = 8.dp).glass(RoundedCornerShape(18.dp), 0.8f).padding(horizontal = 12.dp, vertical = 10.dp)) {
                    LinearProgressIndicator(Modifier.fillMaxWidth().clip(RoundedCornerShape(2.dp)), color = Ink, trackColor = Color.White.copy(alpha = 0.08f))
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text((if (c.paused) "متوقف مؤقتاً — " else "") + c.status, Modifier.weight(1f), color = InkDim, fontSize = 12.sp, maxLines = 2)
                        GlassButton(if (c.paused) "متابعة" else "إيقاف مؤقت") { c.togglePause() }
                        GlassButton("إيقاف", tint = Danger) { c.stop() }
                    }
                }
            }

            if (editingId != null) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("تعديل الرسالة: سيُحذف ما بعدها ويُنفَّذ الأمر المعدَّل", Modifier.weight(1f), color = InkDim, fontSize = 12.sp, lineHeight = 17.sp)
                    GlassButton("إلغاء", tint = Danger) { editingId = null; input = "" }
                }
            }
            if (c.attachments.isNotEmpty() && !c.attachmentsSent) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    c.attachments.toList().forEach { at ->
                        Box {
                            AttachThumb(at, 68.dp)
                            Box(
                                Modifier.align(Alignment.TopEnd).padding(3.dp).size(22.dp).clip(CircleShape).background(Color(0xCC000000)).clickable { c.removeAttachment(at) },
                                contentAlignment = Alignment.Center
                            ) { Text("×", color = Ink, fontSize = 14.sp) }
                        }
                    }
                }
            }
            val canType = !c.running || c.awaitingAnswer
            val typing = input.isNotBlank()
            val canSend = typing && canType
            val blocked = TokenBudget.exhausted(nowMs)
            val sendStrength by animateFloatAsState(if (typing) 2.4f else 1.6f, tween(220), label = "sendStrength")
            if (!blocked && input.startsWith("/") && !input.contains(' ')) {
                val cmds = listOf("/work" to "تنفيذ مهمة على الهاتف", "/image" to "توليد صورة", "/video" to "توليد فيديو")
                    .filter { it.first.startsWith(input.lowercase()) }
                if (cmds.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    cmds.forEach { (k, d) ->
                        Row(
                            Modifier.glass(RoundedCornerShape(16.dp), 1.3f).pressable { input = "$k " }.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(k, color = Ok, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, style = TextStyle(textDirection = TextDirection.Ltr))
                            Text(d, color = InkDim, fontSize = 12.sp)
                        }
                    }
                }
            }
            if (blocked) {
                val left = (TokenBudget.renewAt(nowMs) - nowMs).coerceAtLeast(0L)
                Column(
                    Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp).glass(RoundedCornerShape(26.dp), 1f).padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("انتهت التوكنز لهذا اليوم", color = Danger, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text("تتجدد بعد " + renewText(left), color = Ink, fontSize = 14.sp)
                    Text("تقدر تضيف مفتاح Gemini المجاني من الإعدادات لتكمل فوراً.", color = InkDim, fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 18.sp)
                    GlassButton("فتح الإعدادات", strong = true) { showSettings = true }
                }
            } else Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp).glass(RoundedCornerShape(28.dp), 1f)) {
                BasicTextField(
                    inputState.tfv, { inputState.tfv = it },
                    Modifier.fillMaxWidth().heightIn(min = 46.dp),
                    enabled = canType,
                    textStyle = TextStyle(color = Ink, fontSize = 16.sp, lineHeight = 22.sp),
                    cursorBrush = SolidColor(Ink),
                    maxLines = 5,
                    decorationBox = { inner ->
                        Box(Modifier.padding(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 6.dp), contentAlignment = Alignment.CenterStart) {
                            if (input.isEmpty()) Text(
                                if (Voice.listening) Voice.partial.ifBlank { "أسمعك…" } else if (c.awaitingAnswer) "اكتب أو احكِ إجابتك…" else "اسأل أي شي، أو اكتب / للأوامر",
                                color = if (Voice.listening) Ink else InkDim, fontSize = 16.sp)
                            inner()
                        }
                    }
                )
                // Buttons keep a fixed physical order whatever the text direction: [+] [model] ........ [mic] [call / send]
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(
                            Modifier.size(40.dp).alpha(if (canType) 1f else 0.4f).glass(CircleShape, 1.4f).pressable(enabled = canType) { hideKeyboard(); attachOpen = true },
                            contentAlignment = Alignment.Center
                        ) {
                            LineIcon(20.dp) { s, sw ->
                                drawLine(Ink, Offset(s * 0.5f, s * 0.18f), Offset(s * 0.5f, s * 0.82f), sw * 1.2f, StrokeCap.Round)
                                drawLine(Ink, Offset(s * 0.18f, s * 0.5f), Offset(s * 0.82f, s * 0.5f), sw * 1.2f, StrokeCap.Round)
                            }
                        }
                        Row(
                            Modifier.widthIn(max = 150.dp).height(34.dp).animateContentSize().glass(RoundedCornerShape(17.dp), 0.9f)
                                .pressable { hideKeyboard(); modelOpen = true }.padding(horizontal = 11.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Text(c.modelLabel, Modifier.weight(1f, fill = false), color = InkDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            LineIcon(12.dp) { s, sw -> icChevron(InkDim, s, sw, false) }
                        }
                        Spacer(Modifier.weight(1f))
                        Box(
                            Modifier.size(40.dp).graphicsLayer { alpha = if (Voice.listening) pulse else if (canType) 1f else 0.4f }
                                .glass(CircleShape, if (Voice.listening) 3.2f else 1.4f)
                                .pressable(enabled = canType || Voice.listening) { if (Voice.listening) Voice.stopListening() else { hideKeyboard(); startVoice() } },
                            contentAlignment = Alignment.Center
                        ) { MicIcon() }
                        Box(
                            Modifier.size(40.dp).alpha(if (typing && !canSend) 0.4f else if (!typing && !canType) 0.4f else 1f)
                                .glass(CircleShape, sendStrength)
                                .pressable(enabled = canSend || (!typing && canType)) {
                                    if (typing) { editingId?.let { c.truncateFrom(it) }; editingId = null; c.submit(input); input = "" }
                                    else { hideKeyboard(); Voice.failStreak = 0; micMuted = false; vPaused = false; voiceMode = true }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            AnimatedContent(
                                typing, label = "callSend",
                                transitionSpec = { (fadeIn(tween(200)) + scaleIn(tween(200), initialScale = 0.5f)) togetherWith (fadeOut(tween(120)) + scaleOut(tween(120), targetScale = 0.5f)) }
                            ) { t -> if (t) SendIcon() else LineIcon(20.dp) { s, sw -> icWave(Ink, s, sw) } }
                        }
                    }
                }
            }
        }
        AnimatedVisibility(drawerOpen, enter = fadeIn(tween(180)), exit = fadeOut(tween(160))) {
            Box(Modifier.fillMaxSize().background(Color(0x99000000)).pointerInput(Unit) { detectTapGestures { drawerOpen = false } })
        }
        AnimatedVisibility(
            drawerOpen, modifier = Modifier.align(Alignment.CenterStart),
            enter = slideInHorizontally(tween(220)) { it }, exit = slideOutHorizontally(tween(200)) { it }
        ) {
            ChatDrawer(
                chats = c.chats, currentId = c.currentChatId,
                onSettings = { drawerOpen = false; showSettings = true },
                onBuilder = { drawerOpen = false; builderOpen = true },
                onNew = {
                    if (c.running) Toast.makeText(ctx, "أوقف المهمة الحالية أولاً", Toast.LENGTH_SHORT).show()
                    else { c.newChat(); input = ""; drawerOpen = false }
                },
                onOpen = { m ->
                    if (c.running) Toast.makeText(ctx, "أوقف المهمة الحالية أولاً", Toast.LENGTH_SHORT).show()
                    else if (c.openChat(m.id)) { input = ""; drawerOpen = false }
                    else Toast.makeText(ctx, "تعذّر فتح المحادثة", Toast.LENGTH_SHORT).show()
                },
                onDelete = { delChat = it })
        }
        BackHandler(drawerOpen) { drawerOpen = false }
        AnimatedVisibility(attachOpen || modelOpen, enter = fadeIn(tween(180)), exit = fadeOut(tween(160))) {
            Box(Modifier.fillMaxSize().background(Color(0x99000000)).pointerInput(Unit) { detectTapGestures { attachOpen = false; modelOpen = false } })
        }
        AnimatedVisibility(
            attachOpen, modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(240)) { it }, exit = slideOutVertically(tween(200)) { it }
        ) {
            AttachSheet(
                onClose = { attachOpen = false },
                onPhoto = { attachOpen = false; val u = newCamUri("jpg"); camUri = u; photoCam.launch(u) },
                onVideo = { attachOpen = false; val u = newCamUri("mp4"); camUri = u; videoCam.launch(u) },
                onGallery = { attachOpen = false; mediaPicker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) },
                onFiles = { attachOpen = false; attachPicker.launch(arrayOf("*/*")) })
        }
        AnimatedVisibility(
            modelOpen, modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(240)) { it }, exit = slideOutVertically(tween(200)) { it }
        ) {
            val geminiReady = remember(modelOpen, tick) { c.geminiKey.isNotBlank() }
            ModelSheet(
                currentProvider = c.provider, currentModel = if (c.provider == "gemini") c.geminiModel else c.aiModel, geminiReady = geminiReady,
                onPick = { p, m ->
                    if (p == "gemini" && !geminiReady) Toast.makeText(ctx, "أضف مفتاح Gemini المجاني من الإعدادات أولاً", Toast.LENGTH_LONG).show()
                    else { c.pickModel(p, m); modelOpen = false }
                },
                onClose = { modelOpen = false })
        }
        BackHandler(attachOpen || modelOpen) { attachOpen = false; modelOpen = false }
        if (builderOpen) {
            BackHandler(true) { builderOpen = false }
            BuilderScreen { builderOpen = false }
        }
        if (voiceMode) {
            val exitVoice: () -> Unit = {
                if (vPaused && c.paused) c.togglePause()
                voiceMode = false; micMuted = false; vPaused = false
                Voice.stopSpeaking(); Voice.stopListening()
            }
            BackHandler(true) { exitVoice() }
            VoiceModeScreen(
                muted = micMuted, paused = vPaused,
                onMute = { micMuted = !micMuted; Voice.failStreak = 0; if (micMuted) Voice.stopListening() },
                onPause = {
                    vPaused = !vPaused
                    if (vPaused) { Voice.stopSpeaking(); Voice.stopListening() }
                    if (c.running && c.paused != vPaused) c.togglePause()
                },
                onExit = exitVoice)
        }
    }

    menuMsg?.let { m ->
        MessageActions(m, canAct = !c.running,
            onDismiss = { menuMsg = null },
            onEdit = { input = m.text; editingId = m.id; menuMsg = null },
            onRetry = { menuMsg = null; c.retry(m) })
    }

    c.pendingConfirm?.let { q ->
        Dialog(onDismissRequest = { c.answer(false) }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).sheet(RoundedCornerShape(26.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("تأكيد الإجراء", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(q, color = Ink.copy(alpha = 0.9f), fontSize = 14.sp, lineHeight = 21.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("سماح", Modifier.weight(1f), strong = true) { c.answer(true) }
                    GlassButton("رفض", Modifier.weight(1f), tint = Danger) { c.answer(false) }
                }
            }
        }
    }

    delChat?.let { m ->
        Dialog(onDismissRequest = { delChat = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).sheet(RoundedCornerShape(26.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("حذف المحادثة", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text("«${m.title}» ستُحذف نهائياً مع صورها وملفاتها.", color = Ink.copy(alpha = 0.9f), fontSize = 14.sp, lineHeight = 21.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("حذف", Modifier.weight(1f), tint = Danger) { c.deleteChat(m.id); delChat = null }
                    GlassButton("إلغاء", Modifier.weight(1f), strong = true) { delChat = null }
                }
            }
        }
    }

    if (showVoicePicker) VoicePicker { listen ->
        showVoicePicker = false
        // Changing the voice from Settings must only save it: it used to start the microphone, which cut the voice off.
        if (listen && !pickerFromSettings) startVoice()
        pickerFromSettings = false
    }

    if (showSettings) {
        var aiUrl by remember { mutableStateOf(c.aiBaseUrl) }
        var aiModel by remember { mutableStateOf(c.aiModel) }
        var aiKey by remember { mutableStateOf(c.apiKeys) }
        var useAi by remember { mutableStateOf(c.useAi) }
        var useVision by remember { mutableStateOf(c.useVision) }
        var visionModel by remember { mutableStateOf(c.visionModel) }
        var vAlways by remember { mutableStateOf(Voice.always) }
        var vHands by remember { mutableStateOf(Voice.handsFree) }
        var gemKey by remember { mutableStateOf(c.geminiKey) }
        var ttsUrl by remember { mutableStateOf(Voice.ttsUrl) }
        var ttsModel by remember { mutableStateOf(Voice.ttsModel) }
        var sttLang by remember { mutableStateOf(Voice.sttLang) }
        var tokLimit by remember { mutableStateOf(TokenBudget.perKeyLimit.toString()) }
        val scope = rememberCoroutineScope()
        var modelMsg by remember { mutableStateOf(if (LlmPlanner.isReady()) "مثبّت (${LlmPlanner.sizeMb()} MB)" else "غير مثبّت") }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                modelMsg = "جارٍ النسخ…"
                scope.launch { modelMsg = if (LlmPlanner.importModel(uri)) "مثبّت (${LlmPlanner.sizeMb()} MB)" else "فشل النسخ" }
            }
        }
        var cookieMsg by remember { mutableStateOf(if (MediaDownloader.hasCookies(ctx)) "مستورد" else "غير موجود") }
        val cookiePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) cookieMsg = if (MediaDownloader.importCookies(ctx, uri)) "مستورد" else "فشل النسخ"
        }
        Dialog(onDismissRequest = { showSettings = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp).heightIn(max = 600.dp).sheet(RoundedCornerShape(28.dp))
                    .verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("الإعدادات", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("استخدم الذكاء الاصطناعي دائماً (وإلا فقط للأوامر التي لا يفهمها التطبيق)", Modifier.weight(1f), color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                    Switch(useAi, { useAi = it }, colors = SwitchDefaults.colors(
                        checkedThumbColor = Ink, checkedTrackColor = Color.White.copy(alpha = 0.28f), checkedBorderColor = Color.Transparent,
                        uncheckedThumbColor = InkDim, uncheckedTrackColor = Color.White.copy(alpha = 0.08f), uncheckedBorderColor = Color.White.copy(alpha = 0.2f)))
                }
                Text("أي خدمة متوافقة مع OpenAI. المفتاح يُحفظ مشفّراً على هذا الهاتف ويُرسل فقط إلى العنوان أدناه.", color = InkDim, fontSize = 12.sp, lineHeight = 18.sp)
                GlassField("عنوان الخدمة", aiUrl, { aiUrl = it })
                GlassField("النموذج الذكي (يخطط ويحل المواقف الصعبة)", aiModel, { aiModel = it })
                GlassField("مفاتيح API (مفتاح بكل سطر)", aiKey, { aiKey = it }, secret = true, lines = 4)
                Text("الحصة المجانية في Groq محسوبة لكل حساب (Organization)، لا لكل مفتاح. المفاتيح تتبدّل تلقائياً عند الوصول للحد، وتنفع فقط إذا كانت من حسابات مختلفة.", color = InkDim, fontSize = 11.sp, lineHeight = 16.sp)
                GlassField("مفتاح Gemini المجاني (احتياطي، اختياري)", gemKey, { gemKey = it }, secret = true)
                Text("من aistudio.google.com/apikey وهو مجاني. يشتغل تلقائياً وفوراً لما تخلص حصة Groq، فما يوقف التطبيق.", color = InkDim, fontSize = 11.sp, lineHeight = 16.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("الوضع السريع: نموذج سريع يشوف الصور لكل خطوة، والنموذج الذكي يخطط أول المهمة ويتدخل لما يتعثر", Modifier.weight(1f), color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                    Switch(useVision, { useVision = it }, colors = SwitchDefaults.colors(
                        checkedThumbColor = Ink, checkedTrackColor = Color.White.copy(alpha = 0.28f), checkedBorderColor = Color.Transparent,
                        uncheckedThumbColor = InkDim, uncheckedTrackColor = Color.White.copy(alpha = 0.08f), uncheckedBorderColor = Color.White.copy(alpha = 0.2f)))
                }
                if (useVision) GlassField("النموذج السريع (كل خطوة + الصور)", visionModel, { visionModel = it })
                Text("الصوت", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("رد صوتي دائماً (وإلا فقط لما تحكي معه)", Modifier.weight(1f), color = Ink, fontSize = 13.sp)
                    Switch(vAlways, { vAlways = it }, colors = SwitchDefaults.colors(
                        checkedThumbColor = Ink, checkedTrackColor = Color.White.copy(alpha = 0.28f), checkedBorderColor = Color.Transparent,
                        uncheckedThumbColor = InkDim, uncheckedTrackColor = Color.White.copy(alpha = 0.08f), uncheckedBorderColor = Color.White.copy(alpha = 0.2f)))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("وضع المحادثة: يستمع تلقائياً بعد كل رد (والتطبيق مفتوح)", Modifier.weight(1f), color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                    Switch(vHands, { vHands = it }, colors = SwitchDefaults.colors(
                        checkedThumbColor = Ink, checkedTrackColor = Color.White.copy(alpha = 0.28f), checkedBorderColor = Color.Transparent,
                        uncheckedThumbColor = InkDim, uncheckedTrackColor = Color.White.copy(alpha = 0.08f), uncheckedBorderColor = Color.White.copy(alpha = 0.2f)))
                }
                GlassButton("اختيار الصوت وتجربته") { Voice.stopListening(); pickerFromSettings = true; showVoicePicker = true }
                GlassField("لغة التعرف على الصوت", sttLang, { sttLang = it })
                GlassField("عنوان الصوت (TTS)", ttsUrl, { ttsUrl = it })
                GlassField("نموذج الصوت", ttsModel, { ttsModel = it })
                Text("الصوت الطبيعي يستخدم نفس مفتاح Groq. إذا ما اشتغل، وافق على شروط النموذج في Groq Playground؛ وفي كل الأحوال يرجع لصوت الهاتف.", color = InkDim, fontSize = 11.sp, lineHeight = 16.sp)
                GlassField("الحد اليومي لكل مفتاح Groq (توكن) لعدّاد الرصيد", tokLimit, { tokLimit = it.filter { ch -> ch.isDigit() }.take(9) })
                Text("المستخدم اليوم: ${QuotaTracker.fmt(TokenBudget.used())} من ${QuotaTracker.fmt(TokenBudget.total())} (${TokenBudget.keyCount()} مفتاح). الرصيد اليومي الحقيقي لا يرسله Groq، فالتطبيق يحسبه من استهلاكك؛ عدّل الحد إذا كان رصيد حسابك مختلفاً.", color = InkDim, fontSize = 11.sp, lineHeight = 16.sp)
                Text("الحصة المتبقية (Groq)", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                QuotaTracker.version.let { _ -> QuotaTracker.all() }.let { qs ->
                    if (qs.isEmpty()) Text("تظهر بعد أول طلب للذكاء الاصطناعي. Gemini ما يرسل هذه المعلومة.", color = InkDim, fontSize = 12.sp, lineHeight = 17.sp)
                    qs.forEach { q ->
                        Text("${q.model.substringAfterLast('/')} · مفتاح …${q.keyTail}: ${QuotaTracker.fmt(q.remTok)} / ${QuotaTracker.fmt(q.limTok)} توكن بالدقيقة" +
                            (if (q.remReq >= 0) " · ${q.remReq} طلب باليوم" else "") + (if (q.resetTok.isNotBlank()) " · يتجدد خلال ${q.resetTok}" else ""),
                            color = if (q.remTok < 1500) Danger else InkDim, fontSize = 12.sp, lineHeight = 17.sp)
                    }
                }
                if (Voice.ttsStatus.isNotBlank()) Text("آخر مشكلة بالصوت الطبيعي: ${Voice.ttsStatus}", color = Danger, fontSize = 12.sp, lineHeight = 17.sp)
                Text("النموذج المحلي (دون إنترنت): $modelMsg", color = InkDim, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("اختيار ملف .task") { picker.launch(arrayOf("*/*")) }
                    GlassButton("حذف النموذج") { LlmPlanner.deleteModel(); modelMsg = "غير مثبّت" }
                }
                Text("تنزيل الفيديوهات: ملف cookies.txt ($cookieMsg). يلزم فقط لمحتوى إنستغرام/فيسبوك اللي يطلب تسجيل دخول.", color = InkDim, fontSize = 12.sp, lineHeight = 17.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("استيراد cookies.txt") { cookiePicker.launch(arrayOf("*/*")) }
                    GlassButton("حذفه") { MediaDownloader.deleteCookies(ctx); cookieMsg = "غير موجود" }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("مسح المحادثة") { c.clearHistory() }
                    GlassButton("حذف المفاتيح", tint = Danger) { aiKey = ""; c.apiKeys = ""; gemKey = ""; c.geminiKey = ""; c.backendUrl = ""; c.backendToken = "" }
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("إغلاق", Modifier.weight(1f)) { showSettings = false }
                    GlassButton("حفظ", Modifier.weight(1f), strong = true) {
                        c.aiBaseUrl = aiUrl; c.aiModel = aiModel; c.apiKeys = aiKey; c.useAi = useAi; c.useVision = useVision; c.visionModel = visionModel; c.geminiKey = gemKey
                        Voice.always = vAlways; Voice.applyHandsFree(vHands)
                        tokLimit.toLongOrNull()?.let { TokenBudget.perKeyLimit = it }
                        Voice.ttsUrl = ttsUrl; Voice.ttsModel = ttsModel; Voice.sttLang = sttLang
                        showSettings = false
                    }
                }
            }
        }
    }
}


// ---------------- logo, intro screen and voice screen ----------------

private fun DrawScope.icWave(c: Color, s: Float, sw: Float) {
    listOf(0.2f to 0.12f, 0.35f to 0.28f, 0.5f to 0.4f, 0.65f to 0.22f, 0.8f to 0.1f).forEach { (x, h) ->
        drawLine(c, Offset(s * x, s * (0.5f - h)), Offset(s * x, s * (0.5f + h)), sw * 1.3f, StrokeCap.Round)
    }
}

/**
 * The app logo: a frosted disc with the pointer inside. The pointer orbits on the disc; [energy] (0..1) widens the orbit and brightens the glow.
 * [appear] (0..1) is the intro scale/fade.
 */
@Composable
private fun AgentLogo(logoSize: Dp, energy: Float, modifier: Modifier = Modifier, appear: Float = 1f) {
    val t by rememberInfiniteTransition(label = "logo").animateFloat(
        0f, (2 * PI).toFloat(), infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "logoT")
    val e by animateFloatAsState(energy.coerceIn(0f, 1f), tween(180), label = "logoE")
    Canvas(modifier.size(logoSize)) {
        val sz = this.size.minDimension
        val a = appear.coerceIn(0f, 1f)
        val u = sz / 72f * (0.55f + 0.45f * a)
        val cx = sz / 2f; val cy = sz / 2f
        val r = 25f * u * (1f + 0.08f * e)
        for (i in 1..3) {
            drawCircle(Color.White.copy(alpha = ((0.11f - 0.03f * i) * (0.35f + e) * a).coerceIn(0f, 1f)),
                r + i * (3f + 7f * e) * u, Offset(cx, cy), style = Stroke(1.2.dp.toPx()))
        }
        val tl = Offset(cx - r, cy - r); val br = Offset(cx + r, cy + r)
        drawCircle(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.26f * a), Color.White.copy(alpha = 0.08f * a), Color.White.copy(alpha = 0.16f * a)), tl, br), r, Offset(cx, cy))
        drawCircle(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.6f * a), Color.White.copy(alpha = 0.08f * a), Color.White.copy(alpha = 0.35f * a)), tl, br), r, Offset(cx, cy), style = Stroke(1.6f * u))
        val rr = 3f + 5f * e
        val ox = cos(t) * rr; val oy = sin(t) * rr
        val ps = 1f + 0.12f * e
        val pts = listOf(-8.5f to -14f, -8.5f to 12f, -2.3f to 6.4f, 1.8f to 15.8f, 6.1f to 13.9f, 2f to 4.6f, 10.1f to 4.6f)
        val p = Path()
        pts.forEachIndexed { i, pt ->
            val x = cx + (pt.first * ps + ox) * u; val y = cy + (pt.second * ps + oy) * u
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        drawPath(p, Ink.copy(alpha = a))
    }
}

/** Replaces the empty chat page: the logo animates in, then "من أين نبدأ؟" is typed under it. */
@Composable
private fun EmptyHero(modifier: Modifier = Modifier) {
    val appear = remember { Animatable(0f) }
    var typed by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        launch { appear.animateTo(1f, tween(1000, easing = FastOutSlowInEasing)) }
        delay(400)
        val full = "من أين نبدأ؟"
        for (i in 1..full.length) { typed = full.take(i); delay(75) }
    }
    Column(modifier, verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        AgentLogo(160.dp, energy = 0.35f, appear = appear.value)
        Spacer(Modifier.height(20.dp))
        Text(typed, color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, modifier = Modifier.heightIn(min = 36.dp))
    }
}

@Composable
private fun VoiceRoundBtn(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.size(66.dp).glass(CircleShape, 1.8f).clickable(onClick = onClick), contentAlignment = Alignment.Center) { content() }
}

/** Full-screen voice conversation: the logo reacts to the voice, the spoken words appear under it. */
@Composable
private fun VoiceModeScreen(muted: Boolean, paused: Boolean, onMute: () -> Unit, onPause: () -> Unit, onExit: () -> Unit) {
    val c = AgentController
    val wob by rememberInfiniteTransition(label = "vw").animateFloat(0f, 1f, infiniteRepeatable(tween(420), RepeatMode.Reverse), label = "vwv")
    val energy = when {
        paused -> 0.05f
        Voice.listening -> ((Voice.level + 2f) / 12f).coerceIn(0.1f, 1f)
        Voice.speaking -> 0.45f + 0.4f * wob
        c.running -> 0.28f
        else -> 0.12f
    }
    var shown by remember { mutableStateOf("") }
    val startTick = remember { Voice.subTick }
    LaunchedEffect(Voice.subTick) {
        if (Voice.subTick == startTick) return@LaunchedEffect
        val words = Voice.subText.split(' ').filter { it.isNotBlank() }
        if (words.isEmpty()) return@LaunchedEffect
        val per = (Voice.subMs / words.size).coerceIn(90L, 600L)
        for (i in words.indices) { shown = words.take(i + 1).joinToString(" "); delay(per) }
    }
    LaunchedEffect(Voice.listening) { if (Voice.listening) shown = "" }
    val status = when {
        paused -> "متوقف مؤقتاً"
        Voice.listening -> "أسمعك…"
        Voice.speaking -> ""
        c.running -> "أفكر وأنفّذ…"
        muted -> "المايك مكتوم"
        else -> ""
    }
    val hearing = Voice.listening && Voice.partial.isNotBlank()
    val line = if (hearing) Voice.partial else shown
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E1E21), Color(0xFF0C0C0E))))
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.weight(1f))
            AgentLogo(230.dp, energy)
            Spacer(Modifier.height(20.dp))
            Text(status, color = InkDim, fontSize = 13.sp, modifier = Modifier.heightIn(min = 20.dp))
            Spacer(Modifier.height(8.dp))
            Box(Modifier.height(140.dp).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                Text(line, color = if (hearing) InkDim else Ink, fontSize = 22.sp, lineHeight = 32.sp, textAlign = TextAlign.Center, maxLines = 4, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.weight(1f))
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(Modifier.padding(bottom = 28.dp), horizontalArrangement = Arrangement.spacedBy(22.dp), verticalAlignment = Alignment.CenterVertically) {
                    VoiceRoundBtn(onMute) {
                        Box(contentAlignment = Alignment.Center) {
                            MicIcon()
                            if (muted) LineIcon(26.dp) { s, sw -> drawLine(Danger, Offset(s * 0.18f, s * 0.14f), Offset(s * 0.82f, s * 0.86f), sw * 1.3f, StrokeCap.Round) }
                        }
                    }
                    VoiceRoundBtn(onPause) {
                        LineIcon(26.dp) { s, _ ->
                            if (paused) {
                                val tp = Path()
                                tp.moveTo(s * 0.32f, s * 0.18f); tp.lineTo(s * 0.32f, s * 0.82f); tp.lineTo(s * 0.8f, s * 0.5f); tp.close()
                                drawPath(tp, Ink)
                            } else {
                                drawRoundRect(Ink, Offset(s * 0.24f, s * 0.16f), Size(s * 0.18f, s * 0.68f), CornerRadius(s * 0.05f))
                                drawRoundRect(Ink, Offset(s * 0.58f, s * 0.16f), Size(s * 0.18f, s * 0.68f), CornerRadius(s * 0.05f))
                            }
                        }
                    }
                    VoiceRoundBtn(onExit) {
                        LineIcon(26.dp) { s, sw ->
                            drawLine(Danger, Offset(s * 0.2f, s * 0.2f), Offset(s * 0.8f, s * 0.8f), sw * 1.3f, StrokeCap.Round)
                            drawLine(Danger, Offset(s * 0.8f, s * 0.2f), Offset(s * 0.2f, s * 0.8f), sw * 1.3f, StrokeCap.Round)
                        }
                    }
                }
            }
        }
    }
}


// ---------------- side menu (conversations), profile, thumbnails ----------------

/** Placeholder profile; later this comes from the signed-in account (Google sign-in or username/password). */
object UserProfile {
    var name by mutableStateOf("ضيف")
    var subtitle by mutableStateOf("تسجيل الدخول قريباً")
    var photoPath: String? = null
}

@Composable
private fun Avatar(d: Dp) {
    Box(Modifier.size(d).glass(CircleShape, 1.8f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(d * 0.62f)) {
            val w = this.size.width
            drawCircle(Ink.copy(alpha = 0.9f), w * 0.2f, Offset(w * 0.5f, w * 0.34f))
            drawArc(Ink.copy(alpha = 0.9f), 180f, 180f, true, Offset(w * 0.14f, w * 0.6f), Size(w * 0.72f, w * 0.7f))
        }
    }
}

private fun shortStamp(ms: Long): String {
    val now = java.util.Calendar.getInstance()
    val c = java.util.Calendar.getInstance().apply { timeInMillis = ms }
    val same = now.get(java.util.Calendar.YEAR) == c.get(java.util.Calendar.YEAR) && now.get(java.util.Calendar.DAY_OF_YEAR) == c.get(java.util.Calendar.DAY_OF_YEAR)
    val s = if (same) {
        val h24 = c.get(java.util.Calendar.HOUR_OF_DAY)
        val h = if (h24 % 12 == 0) 12 else h24 % 12
        "$h:${c.get(java.util.Calendar.MINUTE).toString().padStart(2, '0')} ${if (h24 < 12) "ص" else "م"}"
    } else "${c.get(java.util.Calendar.DAY_OF_MONTH)} ${MONTHS_AR[c.get(java.util.Calendar.MONTH)]}"
    return s.map { if (it in '0'..'9') '\u0660' + (it - '0') else it }.joinToString("")
}

@Composable
private fun ChatDrawer(
    chats: List<ChatMeta>, currentId: String,
    onSettings: () -> Unit, onBuilder: () -> Unit, onNew: () -> Unit, onOpen: (ChatMeta) -> Unit, onDelete: (ChatMeta) -> Unit
) {
    Column(
        Modifier.fillMaxHeight().width(316.dp).background(Color(0xFF151517))
            .pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding().navigationBarsPadding().padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(46.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(UserProfile.name, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(UserProfile.subtitle, color = InkDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(Modifier.size(42.dp).glass(CircleShape).clickable(onClick = onSettings), contentAlignment = Alignment.Center) { TuneIcon() }
        }
        Spacer(Modifier.height(16.dp))
        GlassButton("محادثة جديدة", Modifier.fillMaxWidth(), strong = true, onClick = onNew)
        Spacer(Modifier.height(8.dp))
        GlassButton("ابنِ تطبيق APK", Modifier.fillMaxWidth(), onClick = onBuilder)
        Spacer(Modifier.height(16.dp))
        Text("المحادثات", color = InkDim, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        if (chats.isEmpty()) Text("ما في محادثات محفوظة بعد. ابدأ وحدة وبتظهر هون.", color = InkDim, fontSize = 13.sp, lineHeight = 19.sp)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(chats, key = { it.id }) { m ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(if (m.id == currentId) Color.White.copy(alpha = 0.10f) else Color.Transparent)
                        .clickable { onOpen(m) }
                        .padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(m.title.ifBlank { "محادثة" }, color = Ink, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(shortStamp(m.updated), color = InkDim, fontSize = 11.sp)
                    }
                    Box(Modifier.size(34.dp).clip(CircleShape).clickable { onDelete(m) }, contentAlignment = Alignment.Center) {
                        Text("×", color = InkDim, fontSize = 18.sp)
                    }
                }
            }
        }
    }
}

private object Thumbs {
    private val cache = android.util.LruCache<String, ImageBitmap>(48)
    fun load(path: String, mime: String): ImageBitmap? {
        cache.get(path)?.let { return it }
        val bmp = try {
            if (mime.startsWith("video")) {
                val r = android.media.MediaMetadataRetriever()
                try { r.setDataSource(path); r.getFrameAtTime(1_000_000L, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: r.getFrameAtTime(0L) } finally { runCatching { r.release() } }
            } else if (mime.startsWith("image")) {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, o)
                var ss = 1
                while (o.outWidth / ss > 700 && ss < 64) ss *= 2
                BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = ss })
            } else null
        } catch (e: Exception) { null }
        return bmp?.asImageBitmap()?.also { cache.put(path, it) }
    }
}

/** A picture (or the first frame of a video, with a play badge) instead of the file name; other files show an icon-like tile with the name. */
@Composable
private fun AttachThumb(a: Attachment, d: Dp, onClick: (() -> Unit)? = null) {
    val bmp by produceState<ImageBitmap?>(null, a.path) { value = withContext(Dispatchers.IO) { Thumbs.load(a.path, a.mime) } }
    val shape = RoundedCornerShape(14.dp)
    Box(Modifier.size(d).clip(shape).glass(shape, 1.2f).then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(a.name.take(16), color = InkDim, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(6.dp))
        if (a.mime.startsWith("video")) {
            Box(Modifier.size(d * 0.36f).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(d * 0.16f)) {
                    val w = this.size.width
                    val tp = Path()
                    tp.moveTo(w * 0.1f, 0f); tp.lineTo(w * 0.1f, w); tp.lineTo(w, w * 0.5f); tp.close()
                    drawPath(tp, Ink)
                }
            }
        }
    }
}


// ---------------- app builder screen ----------------

private fun displayName(ctx: Context, uri: Uri): String = runCatching {
    ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    }
}.getOrNull() ?: (uri.lastPathSegment ?: "file")

@Composable
private fun BuilderScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val b = AppBuilder
    val scope = rememberCoroutineScope()
    var token by remember { mutableStateOf("") }
    var editTok by remember { mutableStateOf(b.ghToken.isBlank()) }
    var desc by remember { mutableStateOf("") }
    var picked by remember { mutableStateOf<List<Pair<Uri, String>>>(emptyList()) }
    var cont by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        picked = picked + uris.map { it to displayName(ctx, it) }
    }
    Column(
        Modifier.fillMaxSize().background(Color(0xFF131315)).pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding().navigationBarsPadding().imePadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("بناء تطبيق APK", Modifier.weight(1f), color = Ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            GlassButton("رجوع") { onClose() }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (editTok) {
                Text("مرة وحدة: أنشئ توكن كلاسيكي بصلاحيتي repo و workflow من github.com/settings/tokens ثم الصقه هون. يُحفظ مشفّراً على هاتفك. التطبيق ينشئ مستودعاً خاصاً ويبني فيه.", color = InkDim, fontSize = 12.sp, lineHeight = 18.sp)
                GlassField("توكن GitHub", token, { token = it }, secret = true)
                GlassButton("حفظ التوكن", Modifier.fillMaxWidth(), enabled = token.isNotBlank(), strong = true) { b.ghToken = token; token = ""; editTok = false }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("GitHub متصل", Modifier.weight(1f), color = Ok, fontSize = 13.sp)
                    GlassButton("تغيير التوكن") { editTok = true }
                }
            }
            if (b.hasLast) Row(verticalAlignment = Alignment.CenterVertically) {
                Text("تعديل آخر تطبيق: «${b.appName}»", Modifier.weight(1f), color = Ink, fontSize = 13.sp)
                Switch(cont, { cont = it }, enabled = !b.running, colors = SwitchDefaults.colors(
                    checkedThumbColor = Ink, checkedTrackColor = Color.White.copy(alpha = 0.28f), checkedBorderColor = Color.Transparent,
                    uncheckedThumbColor = InkDim, uncheckedTrackColor = Color.White.copy(alpha = 0.08f), uncheckedBorderColor = Color.White.copy(alpha = 0.2f)))
            }
            GlassField(if (cont) "التعديل المطلوب" else "وصف التطبيق (أو اتركه فاضي مع ملف)", desc, { desc = it }, lines = 5)
            if (!cont) {
                Text("أرفق: ملف HTML أو zip لموقع (يتحول لتطبيق مباشرة)، أو zip لمشروع Gradle (يُبنى كما هو)، أو أي ملفات مرجعية للتطبيق اللي تريد.", color = InkDim, fontSize = 12.sp, lineHeight = 18.sp)
                picked.forEachIndexed { i, p ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(p.second, Modifier.weight(1f), color = Ink, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("×", color = InkDim, fontSize = 20.sp, modifier = Modifier.clickable { picked = picked.filterIndexed { j, _ -> j != i } }.padding(horizontal = 10.dp))
                    }
                }
                GlassButton("إرفاق ملفات", Modifier.fillMaxWidth(), enabled = !b.running) { picker.launch(arrayOf("*/*")) }
            }
            if (b.running) {
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = Ink, trackColor = Color.White.copy(alpha = 0.10f))
                Text(b.status, color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
            }
            b.lastError?.let { Text(it, color = Danger, fontSize = 13.sp, lineHeight = 19.sp) }
            b.log.takeLast(40).forEach { Text(it, color = InkDim, fontSize = 12.sp, lineHeight = 17.sp) }
            if (b.apk != null) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("تثبيت", Modifier.weight(1f), strong = true) { b.install(ctx) }
                GlassButton("مشاركة", Modifier.weight(1f)) { b.share(ctx) }
            }
        }
        if (b.running) GlassButton("إيقاف", Modifier.fillMaxWidth(), tint = Danger) { b.stop() }
        else GlassButton(if (cont) "طبّق التعديل وابنِ" else "ابنِ التطبيق", Modifier.fillMaxWidth(), enabled = !editTok, strong = true) {
            scope.launch {
                val atts = withContext(Dispatchers.IO) {
                    picked.mapNotNull { (u, n) -> runCatching { BuildAtt(n, ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() }) }.getOrNull() }
                }
                b.start(desc, atts, cont)
                if (cont) desc = ""
            }
        }
    }
}


// ---------------- credits pill, + sheet, model sheet ----------------

private fun renewText(ms: Long): String {
    val mins = (ms / 60_000L).coerceAtLeast(1L)
    val h = mins / 60; val m = mins % 60
    return when {
        h > 0 && m > 0 -> "$h س و $m د"
        h > 0 -> "$h س"
        else -> "$m د"
    }
}

/** Remaining tokens of the whole day (all keys together). It drops as the AI is used. */
@Composable
private fun CreditsPill(nowMs: Long) {
    val total = TokenBudget.total()
    val rem = TokenBudget.remaining()
    if (total <= 0L) return
    val low = rem * 10 < total
    val label = if (rem <= 0L) "0 · " + renewText((TokenBudget.renewAt(nowMs) - nowMs).coerceAtLeast(0L)) else QuotaTracker.fmt(rem)
    Row(
        Modifier.height(34.dp).animateContentSize().glass(RoundedCornerShape(17.dp), 0.9f).padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(if (low) Danger else Ok))
        Text(label, color = if (low) Danger else Ink, fontSize = 12.sp, maxLines = 1, style = TextStyle(textDirection = TextDirection.Ltr))
    }
}

private val TopSheetShape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)

private fun DrawScope.icCamera(c: Color, s: Float, sw: Float) {
    val st = strokeOf(sw)
    drawRoundRect(c, Offset(s * 0.1f, s * 0.27f), Size(s * 0.8f, s * 0.6f), CornerRadius(s * 0.12f), style = st)
    drawLine(c, Offset(s * 0.32f, s * 0.27f), Offset(s * 0.38f, s * 0.15f), sw, StrokeCap.Round)
    drawLine(c, Offset(s * 0.38f, s * 0.15f), Offset(s * 0.62f, s * 0.15f), sw, StrokeCap.Round)
    drawLine(c, Offset(s * 0.62f, s * 0.15f), Offset(s * 0.68f, s * 0.27f), sw, StrokeCap.Round)
    drawCircle(c, s * 0.17f, Offset(s * 0.5f, s * 0.57f), style = st)
}

private fun DrawScope.icVideoCam(c: Color, s: Float, sw: Float) {
    val st = strokeOf(sw)
    drawRoundRect(c, Offset(s * 0.08f, s * 0.28f), Size(s * 0.55f, s * 0.44f), CornerRadius(s * 0.1f), style = st)
    val p = Path().apply { moveTo(s * 0.68f, s * 0.46f); lineTo(s * 0.92f, s * 0.3f); lineTo(s * 0.92f, s * 0.7f); lineTo(s * 0.68f, s * 0.54f); close() }
    drawPath(p, c, style = st)
}

private fun DrawScope.icImage(c: Color, s: Float, sw: Float) {
    val st = strokeOf(sw)
    drawRoundRect(c, Offset(s * 0.1f, s * 0.14f), Size(s * 0.8f, s * 0.72f), CornerRadius(s * 0.1f), style = st)
    drawCircle(c, s * 0.07f, Offset(s * 0.34f, s * 0.36f), style = st)
    val p = Path().apply { moveTo(s * 0.12f, s * 0.78f); lineTo(s * 0.38f, s * 0.52f); lineTo(s * 0.56f, s * 0.7f); lineTo(s * 0.7f, s * 0.56f); lineTo(s * 0.88f, s * 0.74f) }
    drawPath(p, c, style = st)
}

private fun DrawScope.icFile(c: Color, s: Float, sw: Float) {
    val p = Path().apply { moveTo(s * 0.24f, s * 0.1f); lineTo(s * 0.6f, s * 0.1f); lineTo(s * 0.8f, s * 0.3f); lineTo(s * 0.8f, s * 0.9f); lineTo(s * 0.24f, s * 0.9f); close() }
    drawPath(p, c, style = strokeOf(sw))
    drawLine(c, Offset(s * 0.6f, s * 0.1f), Offset(s * 0.6f, s * 0.3f), sw, StrokeCap.Round)
    drawLine(c, Offset(s * 0.6f, s * 0.3f), Offset(s * 0.8f, s * 0.3f), sw, StrokeCap.Round)
}

@Composable
private fun SheetHandle() {
    Box(Modifier.width(40.dp).height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f)))
}

@Composable
private fun AttachTile(label: String, modifier: Modifier, onClick: () -> Unit, draw: DrawScope.(Float, Float) -> Unit) {
    Column(
        modifier.glass(RoundedCornerShape(20.dp), 0.9f).clickable(onClick = onClick).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f)), contentAlignment = Alignment.Center) { LineIcon(22.dp, draw) }
        Text(label, color = Ink, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

/** "Add to chat": camera, video recording, gallery (photos + videos) and files. */
@Composable
private fun AttachSheet(onClose: () -> Unit, onPhoto: () -> Unit, onVideo: () -> Unit, onGallery: () -> Unit, onFiles: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().sheet(TopSheetShape).pointerInput(Unit) { detectTapGestures { } }
            .imePadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SheetHandle()
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                LineIcon(18.dp) { s, sw ->
                    drawLine(Ink, Offset(s * 0.2f, s * 0.2f), Offset(s * 0.8f, s * 0.8f), sw, StrokeCap.Round)
                    drawLine(Ink, Offset(s * 0.8f, s * 0.2f), Offset(s * 0.2f, s * 0.8f), sw, StrokeCap.Round)
                }
            }
            Text("إضافة إلى المحادثة", Modifier.weight(1f), color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
            Spacer(Modifier.width(38.dp))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AttachTile("الكاميرا", Modifier.weight(1f), onPhoto) { s, sw -> icCamera(Ink, s, sw) }
            AttachTile("تصوير فيديو", Modifier.weight(1f), onVideo) { s, sw -> icVideoCam(Ink, s, sw) }
            AttachTile("صور وفيديو", Modifier.weight(1f), onGallery) { s, sw -> icImage(Ink, s, sw) }
            AttachTile("ملفات", Modifier.weight(1f), onFiles) { s, sw -> icFile(Ink, s, sw) }
        }
        Spacer(Modifier.height(6.dp))
    }
}

/** Switch between Groq and Gemini and pick the exact model. */
@Composable
private fun ModelSheet(currentProvider: String, currentModel: String, geminiReady: Boolean, onPick: (String, String) -> Unit, onClose: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().heightIn(max = 560.dp).sheet(TopSheetShape).pointerInput(Unit) { detectTapGestures { } }
            .imePadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SheetHandle()
        Text("اختر الذكاء الاصطناعي", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("gemini" to ModelCatalog.gemini, "groq" to ModelCatalog.groq).forEach { (p, ids) ->
                Text(if (p == "gemini") "Gemini (Google)" else "Groq", color = InkDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp, start = 4.dp))
                if (p == "gemini" && !geminiReady) Text("يحتاج مفتاح Gemini المجاني (من الإعدادات).", color = InkDim, fontSize = 11.sp, modifier = Modifier.padding(start = 4.dp))
                ids.forEach { id ->
                    val sel = p == currentProvider && id == currentModel
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .background(if (sel) Color.White.copy(alpha = 0.10f) else Color.Transparent)
                            .clickable { onPick(p, id) }.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(ModelCatalog.label(p, id).removePrefix("Groq \u00b7 "), color = if (sel) Ok else Ink, fontSize = 15.sp, style = TextStyle(textDirection = TextDirection.Ltr))
                            Text(id, color = InkDim, fontSize = 11.sp, style = TextStyle(textDirection = TextDirection.Ltr))
                        }
                        if (sel) Text("\u2713", color = Ok, fontSize = 16.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
    }
}
