package com.aiphoneagent

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Speech recognition that understands (almost) any language.
 * 1. Records one utterance itself (16 kHz, noise suppression / gain control when the phone has them, a 0.4 s pre-roll so the first
 *    word is never cut, an adaptive noise floor so quiet and noisy rooms both work).
 * 2. Sends it to Whisper large-v3 on Groq with automatic language detection (fallback: Gemini audio input).
 * The old Android recognizer in Voice.kt stays as a fallback when there is no key or the service is down.
 */
object Ears {
    class Heard(val text: String, val lang: String)

    /** Language Whisper heard last, in English lower case ("turkish", "english", "arabic"...). Used to pick the voice that answers. */
    @Volatile var lastLang: String = ""
    @Volatile var lastError: String = ""

    private const val SR = 16000
    private const val FRAME = 480            // 30 ms of audio
    private const val FRAME_MS = 30
    private const val GROQ_URL = "https://api.groq.com/openai/v1/audio/transcriptions"

    private fun groqKeys(): List<String> =
        if (AgentController.aiBaseUrl.contains("groq.com")) AgentController.apiKeyList else emptyList()

    fun available(ctx: Context): Boolean =
        ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
            (groqKeys().isNotEmpty() || AgentController.geminiKey.isNotBlank())

    private fun writeShorts(o: ByteArrayOutputStream, b: ShortArray, n: Int = b.size) {
        for (i in 0 until n) { val v = b[i].toInt(); o.write(v and 0xFF); o.write((v shr 8) and 0xFF) }
    }

    /**
     * Records one utterance. Returns 16-bit mono PCM, or null if nobody spoke within [maxWaitMs] (or the mic could not start).
     * [endSilenceMs] of quiet after speech ends the recording.
     */
    @SuppressLint("MissingPermission")
    suspend fun record(maxWaitMs: Int, endSilenceMs: Int, onLevel: (Float) -> Unit, onSpeech: () -> Unit): ByteArray? = withContext(Dispatchers.IO) {
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return@withContext null
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, SR * 2))
        } catch (e: Exception) { return@withContext null }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return@withContext null }
        val fx = ArrayList<AudioEffect>()
        try { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId)?.let { it.setEnabled(true); fx += it } } catch (e: Throwable) {}
        try { if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(rec.audioSessionId)?.let { it.setEnabled(true); fx += it } } catch (e: Throwable) {}
        try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(rec.audioSessionId)?.let { it.setEnabled(true); fx += it } } catch (e: Throwable) {}

        val buf = ShortArray(FRAME)
        val pre = java.util.ArrayDeque<ShortArray>()
        val out = ByteArrayOutputStream()
        var speaking = false
        var voiced = 0; var silenceMs = 0; var loudMs = 0; var waitedMs = 0; var totalMs = 0
        var noise = -1.0
        try {
            rec.startRecording()
            while (isActive) {
                val n = rec.read(buf, 0, FRAME)
                if (n < 0) break
                if (n == 0) continue
                var sum = 0.0
                for (i in 0 until n) { val v = buf[i].toDouble(); sum += v * v }
                val rms = sqrt(sum / n)
                onLevel(rms.toFloat())
                if (noise < 0) noise = min(rms, 400.0)
                val thr = min(max(300.0, noise * 2.8), 2500.0)
                val loud = rms > thr
                if (!speaking) {
                    if (rms < thr) noise = noise * 0.93 + rms * 0.07
                    waitedMs += FRAME_MS
                    pre.addLast(buf.copyOf(n)); while (pre.size > 14) pre.removeFirst()
                    voiced = if (loud) voiced + 1 else 0
                    if (voiced >= 3) {
                        speaking = true; silenceMs = 0; loudMs = voiced * FRAME_MS; totalMs = 0
                        out.reset(); for (p in pre) writeShorts(out, p); pre.clear()
                        onSpeech()
                    } else if (waitedMs >= maxWaitMs) return@withContext null
                } else {
                    writeShorts(out, buf, n); totalMs += FRAME_MS
                    if (loud) { silenceMs = 0; loudMs += FRAME_MS } else if (rms < thr * 0.7) silenceMs += FRAME_MS
                    if (silenceMs >= endSilenceMs || totalMs >= 40_000) {
                        if (loudMs < 300) {
                            // A click or a knock, not speech: forget it and keep waiting.
                            speaking = false; voiced = 0; silenceMs = 0; out.reset()
                            if (waitedMs >= maxWaitMs) return@withContext null
                        } else {
                            val bytes = out.toByteArray()
                            val trim = (max(0, silenceMs - 450) / FRAME_MS) * FRAME * 2
                            return@withContext if (bytes.size - trim > 0) bytes.copyOf(bytes.size - trim) else bytes
                        }
                    }
                }
            }
            null
        } finally {
            try { rec.stop() } catch (e: Exception) {}
            rec.release()
            for (f in fx) try { f.release() } catch (e: Exception) {}
        }
    }

    /** Raises quiet recordings to a good level, then wraps the PCM in a WAV header. */
    private fun toWav(pcm: ByteArray): ByteArray {
        val sh = ShortArray(pcm.size / 2) { i -> ((pcm[2 * i + 1].toInt() shl 8) or (pcm[2 * i].toInt() and 0xFF)).toShort() }
        var peak = 0
        for (s in sh) peak = max(peak, abs(s.toInt()))
        if (peak in 1..14000) {
            val g = min(6f, 22000f / peak)
            for (i in sh.indices) sh[i] = (sh[i] * g).toInt().coerceIn(-32768, 32767).toShort()
        }
        val data = ByteBuffer.allocate(sh.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (s in sh) data.putShort(s)
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt(36 + sh.size * 2).put("WAVE".toByteArray()).put("fmt ".toByteArray())
            .putInt(16).putShort(1).putShort(1).putInt(SR).putInt(SR * 2).putShort(2).putShort(16)
            .put("data".toByteArray()).putInt(sh.size * 2)
        return h.array() + data.array()
    }

    /** Text of the recording in whatever language was spoken. Empty text = no intelligible speech. Throws if every provider failed. */
    suspend fun transcribe(pcm: ByteArray): Heard = withContext(Dispatchers.IO) {
        val wav = toWav(pcm)
        var lastErr: Exception? = null
        val models = listOf(Voice.sttModel, "whisper-large-v3", "whisper-large-v3-turbo").filter { it.isNotBlank() }.distinct()
        for (model in models) for (key in groqKeys()) {
            try { val h = whisper(key, model, wav); lastError = ""; if (h.lang.isNotBlank()) lastLang = h.lang; return@withContext h }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { lastErr = e; lastError = "Whisper: " + (e.message ?: "").take(120) }
        }
        val gk = AgentController.geminiKey
        if (gk.isNotBlank()) {
            for (model in listOf(AgentController.geminiModel, ModelCatalog.GEMINI_LITE, ModelCatalog.GEMINI_FLASH).distinct()) {
                try { val h = gemini(gk, model, wav); lastError = ""; return@withContext h }
                catch (e: CancellationException) { throw e }
                catch (e: Exception) { lastErr = e; lastError = "Gemini: " + (e.message ?: "").take(120) }
            }
        }
        throw lastErr ?: IllegalStateException("no speech-to-text provider")
    }

    private fun whisper(key: String, model: String, wav: ByteArray): Heard {
        val b = "----ears" + System.nanoTime()
        val c = URL(GROQ_URL).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 8_000; c.readTimeout = 30_000; c.doOutput = true
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
        c.setChunkedStreamingMode(0)
        try {
            c.outputStream.use { o ->
                fun part(name: String, v: String) { o.write("--$b\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$v\r\n".toByteArray()) }
                part("model", model); part("response_format", "verbose_json"); part("temperature", "0")
                o.write("--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"speech.wav\"\r\nContent-Type: audio/wav\r\n\r\n".toByteArray())
                o.write(wav)
                o.write("\r\n--$b--\r\n".toByteArray())
            }
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
            if (code !in 200..299) error("HTTP $code ${body.take(160)}")
            return parse(body)
        } finally { c.disconnect() }
    }

    private fun parse(body: String): Heard {
        val j = JSONObject(body)
        val lang = j.optString("language").lowercase()
        val segs: JSONArray? = j.optJSONArray("segments")
        val text = if (segs != null && segs.length() > 0) {
            val sb = StringBuilder()
            for (i in 0 until segs.length()) {
                val s = segs.getJSONObject(i)
                // Whisper's own "this was silence/noise" signals: dropping them removes the famous made-up subtitles.
                if (s.optDouble("no_speech_prob", 0.0) > 0.6 && s.optDouble("avg_logprob", 0.0) < -1.0) continue
                if (s.optDouble("compression_ratio", 1.0) > 2.6) continue
                sb.append(s.optString("text")).append(' ')
            }
            sb.toString()
        } else j.optString("text")
        return Heard(clean(text), lang)
    }

    private val JUNK = listOf(
        "ترجمة نانسي", "شكرا للمشاهدة", "شكرا على المشاهدة", "شكرا لمشاهدتكم", "اشتركوا في القناة", "اشترك في القناة", "لا تنسوا الاشتراك",
        "thanks for watching", "thank you for watching", "subtitles by", "amara.org", "izlediğiniz için teşekkürler"
    )

    private fun clean(t: String): String {
        val x = t.replace(Regex("\\s+"), " ").trim()
        val low = x.lowercase().replace(Regex("[ًٌٍَُِّْ]"), "").replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ة', 'ه')
        if (x.length < 70 && JUNK.any { low.contains(it.replace('ة', 'ه').replace('أ', 'ا')) }) return ""
        return x
    }

    private fun gemini(key: String, model: String, wav: ByteArray): Heard {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 8_000; c.readTimeout = 30_000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        val prompt = "Transcribe the speech in this audio exactly as spoken, in its original language and script (Arabic dialects stay Arabic). " +
            "Output only the transcript, with no comments or translation. If there is no intelligible speech, output exactly: EMPTY"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                .put(JSONObject().put("text", prompt))
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav").put("data", Base64.encodeToString(wav, Base64.NO_WRAP)))))))
            .put("generationConfig", JSONObject().put("temperature", 0))
        try {
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
            if (code !in 200..299) error("HTTP $code ${resp.take(160)}")
            val t = JSONObject(resp).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            val x = clean(t)
            return Heard(if (x.equals("EMPTY", true)) "" else x, "")
        } finally { c.disconnect() }
    }
}
