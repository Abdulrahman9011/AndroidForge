package com.aiphoneagent

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Patterns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * The signed-in user. Accounts live ON THIS PHONE (there is no server): passwords are never stored, only a salted PBKDF2 hash.
 * Two ways in: e-mail + password (created in the app) or Google (Credential Manager when GOOGLE_WEB_CLIENT_ID is set at build time).
 */
object UserProfile {
    private lateinit var sp: SharedPreferences
    var name by mutableStateOf("ضيف")
    var email by mutableStateOf("")
    /** "local" | "google" | "" (guest) */
    var provider by mutableStateOf("")
    /** Bumped when the photo changes, so the avatar reloads. */
    var photoVersion by mutableIntStateOf(0)
    val signedIn get() = email.isNotBlank()
    val subtitle get() = if (signedIn) email else "سجّل الدخول للحفاظ على حسابك"

    private fun users(): JSONObject = runCatching { JSONObject(sp.getString("users", "{}").orEmpty()) }.getOrDefault(JSONObject())
    private fun saveUsers(u: JSONObject) = sp.edit().putString("users", u.toString()).apply()

    fun load(c: Context) {
        if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("accounts", Context.MODE_PRIVATE)
        val cur = sp.getString("current", "").orEmpty()
        val rec = users().optJSONObject(cur)
        if (cur.isNotBlank() && rec != null) { email = cur; name = rec.optString("name", cur.substringBefore('@')); provider = rec.optString("provider", "local") }
    }

    /** The auth screen is shown once at first launch; "continue as guest" also counts as seen. */
    var authSeen: Boolean
        get() = ::sp.isInitialized && sp.getBoolean("authSeen", false)
        set(v) { if (::sp.isInitialized) sp.edit().putBoolean("authSeen", v).apply() }

    private fun hash(pass: String, salt: ByteArray): String {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return Base64.encodeToString(f.generateSecret(PBEKeySpec(pass.toCharArray(), salt, 120_000, 256)).encoded, Base64.NO_WRAP)
    }

    private fun passwordError(p: String): String? = when {
        p.length < 8 -> "كلمة المرور لازم تكون 8 أحرف على الأقل"
        p.none { it.isDigit() } || p.none { it.isLetter() } -> "كلمة المرور لازم تحتوي أحرف وأرقام"
        else -> null
    }

    private fun enter(mail: String, rec: JSONObject) {
        sp.edit().putString("current", mail).apply()
        email = mail; name = rec.optString("name", mail.substringBefore('@')); provider = rec.optString("provider", "local"); photoVersion++
    }

    /** Returns an error message, or null on success. */
    fun register(c: Context, fullName: String, mail0: String, pass: String, confirm: String): String? {
        load(c)
        val mail = mail0.trim().lowercase()
        if (fullName.isBlank()) return "اكتب اسمك"
        if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()) return "البريد الإلكتروني غير صحيح"
        passwordError(pass)?.let { return it }
        if (pass != confirm) return "كلمتا المرور غير متطابقتين"
        val u = users()
        if (u.has(mail)) return "هذا البريد مسجّل مسبقاً، سجّل الدخول"
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val rec = JSONObject().put("name", fullName.trim()).put("provider", "local")
            .put("salt", Base64.encodeToString(salt, Base64.NO_WRAP)).put("hash", hash(pass, salt))
        u.put(mail, rec); saveUsers(u); enter(mail, rec)
        return null
    }

    fun login(c: Context, mail0: String, pass: String): String? {
        load(c)
        val mail = mail0.trim().lowercase()
        val rec = users().optJSONObject(mail) ?: return "ما في حساب بهذا البريد"
        if (rec.optString("provider") == "google") return "هذا الحساب مسجّل عبر Google، استخدم زر Google"
        val salt = Base64.decode(rec.optString("salt"), Base64.NO_WRAP)
        if (!MessageDigest.isEqual(hash(pass, salt).toByteArray(), rec.optString("hash").toByteArray())) return "كلمة المرور غير صحيحة"
        enter(mail, rec)
        return null
    }

    /** Google account (verified by Google through Credential Manager, or picked from the phone's accounts as a fallback). */
    fun signInExternal(c: Context, mail0: String, displayName: String?) {
        load(c)
        val mail = mail0.trim().lowercase()
        val u = users()
        val rec = u.optJSONObject(mail) ?: JSONObject().put("name", displayName?.ifBlank { null } ?: mail.substringBefore('@')).put("provider", "google")
        u.put(mail, rec); saveUsers(u); enter(mail, rec)
    }

    fun updateName(c: Context, n: String): String? {
        load(c)
        if (!signedIn) return "سجّل الدخول أولاً"
        if (n.isBlank()) return "الاسم فاضي"
        val u = users(); val rec = u.optJSONObject(email) ?: return "الحساب غير موجود"
        rec.put("name", n.trim()); saveUsers(u); name = n.trim()
        return null
    }

    fun changePassword(c: Context, old: String, new: String, confirm: String): String? {
        load(c)
        val u = users(); val rec = u.optJSONObject(email) ?: return "سجّل الدخول أولاً"
        if (rec.optString("provider") == "google") return "كلمة مرور حساب Google تُدار من Google"
        val salt = Base64.decode(rec.optString("salt"), Base64.NO_WRAP)
        if (!MessageDigest.isEqual(hash(old, salt).toByteArray(), rec.optString("hash").toByteArray())) return "كلمة المرور الحالية غير صحيحة"
        passwordError(new)?.let { return it }
        if (new != confirm) return "كلمتا المرور الجديدتان غير متطابقتين"
        val ns = ByteArray(16).also { SecureRandom().nextBytes(it) }
        rec.put("salt", Base64.encodeToString(ns, Base64.NO_WRAP)).put("hash", hash(new, ns)); saveUsers(u)
        return null
    }

    fun signOut(c: Context) {
        load(c)
        sp.edit().remove("current").apply()
        email = ""; name = "ضيف"; provider = ""; photoVersion++
    }

    // ---------------- profile photo
    private fun photoFile(c: Context): File? {
        if (!signedIn) return null
        val id = MessageDigest.getInstance("SHA-256").digest(email.toByteArray()).joinToString("") { "%02x".format(it) }.take(16)
        return File(File(c.filesDir, "profile").apply { mkdirs() }, "$id.jpg")
    }
    fun photo(c: Context): File? = photoFile(c)?.takeIf { it.exists() }

    fun setPhoto(c: Context, uri: Uri): Boolean {
        val f = photoFile(c) ?: return false
        return runCatching {
            val bytes = c.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            var ss = 1
            while (minOf(o.outWidth, o.outHeight) / ss > 768 && ss < 64) ss *= 2
            val src = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = ss })!!
            val side = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            f.outputStream().use { sq.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            photoVersion++
            true
        }.getOrDefault(false)
    }
    fun removePhoto(c: Context) { photoFile(c)?.delete(); photoVersion++ }

    // ---------------- Google
    /** null = signed in, "" = cancelled by the user, "NOCLIENT" = no OAuth client configured in this build, anything else = an error message. */
    suspend fun googleSignIn(act: Activity): String? {
        val clientId = BuildConfig.GOOGLE_WEB_CLIENT_ID
        if (clientId.isBlank()) return "NOCLIENT"
        return try {
            val opt = GetGoogleIdOption.Builder().setFilterByAuthorizedAccounts(false).setServerClientId(clientId).build()
            val req = GetCredentialRequest.Builder().addCredentialOption(opt).build()
            val cred = CredentialManager.create(act).getCredential(act, req).credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val g = GoogleIdTokenCredential.createFrom(cred.data)
                signInExternal(act, g.id, g.displayName)
                null
            } else "تعذّر تسجيل الدخول بحساب Google"
        } catch (e: GetCredentialCancellationException) { ""
        } catch (e: Exception) { "فشل تسجيل الدخول بـ Google: ${e.message?.take(120)}" }
    }

    /** Fallback when no OAuth client id is configured: the system picker of the Google accounts already on the phone (not verified by Google). */
    fun chooserIntent(): Intent = android.accounts.AccountManager.newChooseAccountIntent(null, null, arrayOf("com.google"), null, null, null, null)
}
