package com.aiphoneagent

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Reads the Quran from a real text source instead of letting a language model recite it from memory
 * (models garble the words and invent "abridged versions"). A request such as
 * "اقرأ لي سورة القيامة من آية 20 لنهاية السورة" never reaches the model: the verses are fetched
 * (Quran.com, fallback AlQuran.cloud), checked against the official verse count of the surah, cached on the phone
 * and shown word for word.
 */
object Quran {
    class Reply(val text: String, val spoken: String, val memo: String)

    private val NAMES = listOf(
        "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
        "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
        "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
        "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
        "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
        "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
        "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
        "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
        "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
        "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
        "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
        "المسد", "الإخلاص", "الفلق", "الناس"
    )

    /** Official number of verses of each surah: the downloaded text is rejected unless it matches exactly. */
    private val COUNTS = intArrayOf(
        7, 286, 200, 176, 120, 165, 206, 75, 129, 109, 123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
        112, 78, 118, 64, 77, 227, 93, 88, 69, 60, 34, 30, 73, 54, 45, 83, 182, 88, 75, 85,
        54, 53, 89, 59, 37, 35, 38, 29, 18, 45, 60, 49, 62, 55, 78, 96, 29, 22, 24, 13,
        14, 11, 11, 18, 12, 12, 30, 52, 52, 44, 28, 28, 20, 56, 40, 31, 50, 40, 46, 42,
        29, 19, 36, 25, 22, 17, 19, 26, 30, 20, 15, 21, 11, 8, 8, 19, 5, 8, 8, 11,
        11, 8, 3, 9, 5, 4, 7, 3, 6, 3, 5, 4, 5, 6
    )

    private val ALIASES = mapOf("ياسين" to 36, "تبارك" to 67, "بني اسرائيل" to 17, "عمران" to 3, "الاخلاص" to 112)

    /** Spelling-insensitive form: no diacritics/tatweel, one form of alef/ya/ta marbuta/hamza, ASCII digits. */
    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            val c = when (ch) {
                'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                'ة' -> 'ه'
                'ى' -> 'ي'
                'ؤ' -> 'و'
                'ئ' -> 'ي'
                in '٠'..'٩' -> '0' + (ch - '٠')
                in '۰'..'۹' -> '0' + (ch - '۰')
                else -> ch
            }
            if (c in 'ً'..'ٟ' || c == 'ٰ' || c == 'ـ') continue
            sb.append(c)
        }
        return sb.toString().lowercase().trim()
    }

    private val FORMS: List<Pair<String, Int>> by lazy {
        val out = mutableListOf<Pair<String, Int>>()
        NAMES.forEachIndexed { i, nm ->
            val f = norm(nm)
            out += f to (i + 1)
            if (f.startsWith("ال") && f.length > 4) out += f.removePrefix("ال").trim() to (i + 1)
        }
        ALIASES.forEach { (k, v) -> out += norm(k) to v }
        out.filter { it.first.isNotEmpty() }.sortedByDescending { it.first.length }
    }

    private val INTENT = Regex("اقرا|تقرا|اقري|قرا|قراء|اسمعني|اسمعنا|سمعني|عطيني|اعطيني|اعطني|هات|جيب|اكتب|ابغي|اريد|بدي|ابعت|ارسل|اعرض|وريني|ورجيني|read|show")
    private val NOT_READ = Regex("معني|تفسير|فسر|شرح|اشرح|سبب نزول|كم ايه|كم عدد|عدد ايات|فضل|مكيه|مدنيه|ليش|لماذا|meaning|tafsir|why")
    private val TO_END = Regex("نهاي(?:ه|تها)|اخر\\s*السوره|اخرها|لاخر|الي\\s+اخر|حتي\\s+اخر|للاخر")
    private val FROM = Regex("(?:^|\\s)من\\s")

    private class Req(val surah: Int, val from: Int?, val to: Int?, val toEnd: Boolean, val hasFrom: Boolean)

    private fun parse(raw: String): Req? {
        val t = norm(raw)
        if (!INTENT.containsMatchIn(t) || NOT_READ.containsMatchIn(t)) return null
        // آية الكرسي
        if (Regex("ايه\\s+الكرسي").containsMatchIn(t)) return Req(2, 255, 255, false, false)
        val m = Regex("سوره\\s+(.+)", RegexOption.DOT_MATCHES_ALL).find(t) ?: return null
        val rest = m.groupValues[1]
        val hit = FORMS.firstOrNull { (f, _) ->
            rest.startsWith(f) && (rest.length == f.length || !rest[f.length].isLetter())
        } ?: return null
        val tail = rest.substring(hit.first.length)
        val nums = Regex("\\d+").findAll(tail).mapNotNull { it.value.take(4).toIntOrNull() }.toList()
        return Req(hit.second, nums.getOrNull(0), nums.getOrNull(1), TO_END.containsMatchIn(tail), FROM.containsMatchIn(" $tail"))
    }

    private fun arabicDigits(n: Int) = n.toString().map { '٠' + (it - '0') }.joinToString("")

    suspend fun handle(ctx: Context, raw: String): Reply? {
        val r = parse(raw) ?: return null
        val n = r.surah
        val last = COUNTS[n - 1]
        val name = "سورة " + NAMES[n - 1]
        val a: Int? = r.from
        val b: Int? = r.to
        var start = 1; var end = last
        if (a != null) {
            start = a
            end = if (b != null) b else if (r.toEnd || r.hasFrom) last else a
        }
        if (start < 1 || start > last || end < start || end > last)
            return Reply("$name فيها $last آية بس. اكتب الآيات اللي بدك ياها ضمن هالعدد.", "", "[طلب آيات خارج نطاق $name]")
        val note = StringBuilder()
        if (end - start + 1 > MAX_VERSES) {
            end = start + MAX_VERSES - 1
            note.append("\n\nهاي أول $MAX_VERSES آية. للمتابعة اكتب: اقرأ لي $name من آية ${end + 1}")
        }
        val verses = (try { load(ctx, n) } catch (e: CancellationException) { throw e } catch (e: Exception) { null })
            ?: return Reply("ما قدرت أجيب نص القرآن من المصدر هلأ (تأكد من الإنترنت وجرّب مرة ثانية). ما بكتب الآيات من ذاكرتي لأنو الذاكرة بتغلط بالكلمات.", "", "[فشل جلب $name]")
        val picked = (start..end).map { it to verses[it - 1] }
        val head = if (start == 1 && end == last) name else if (start == end) "$name، آية $start" else "$name، الآيات من $start إلى $end"
        val body = picked.joinToString("\n") { (i, v) -> "$v ﴿${arabicDigits(i)}﴾" }
        val text = "$head\n\n$body\n\nالنص من المصحف العثماني (Quran.com) كما هو، بدون أي اختصار.$note"
        val spoken = picked.joinToString("، ") { it.second }
        return Reply(text, spoken, "[قرأت للمستخدم $head من المصحف]")
    }

    private const val MAX_VERSES = 100

    private suspend fun load(ctx: Context, n: Int): List<String>? = withContext(Dispatchers.IO) {
        val want = COUNTS[n - 1]
        val f = File(ctx.filesDir, "quran/$n.json")
        if (f.exists()) {
            try {
                val a = JSONArray(f.readText())
                if (a.length() == want) return@withContext List(want) { a.getString(it) }
            } catch (e: Exception) { f.delete() }
        }
        val got = (try { fromQuranCom(n, want) } catch (e: CancellationException) { throw e } catch (e: Exception) { null })
            ?: (try { fromAlQuranCloud(n, want) } catch (e: CancellationException) { throw e } catch (e: Exception) { null })
        if (got != null && got.size == want) {
            try { f.parentFile?.mkdirs(); f.writeText(JSONArray(got).toString()) } catch (e: Exception) {}
            got
        } else null
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000; c.readTimeout = 20_000
        c.setRequestProperty("Accept", "application/json")
        try {
            if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().readText()
        } finally { c.disconnect() }
    }

    private fun fromQuranCom(n: Int, want: Int): List<String>? {
        val arr = JSONObject(get("https://api.quran.com/api/v4/quran/verses/uthmani?chapter_number=$n")).getJSONArray("verses")
        val out = arrayOfNulls<String>(want)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val num = o.getString("verse_key").substringAfter(':').toIntOrNull() ?: return null
            if (num !in 1..want) return null
            out[num - 1] = o.getString("text_uthmani").trim()
        }
        return if (out.any { it.isNullOrBlank() }) null else out.map { it!! }
    }

    private fun fromAlQuranCloud(n: Int, want: Int): List<String>? {
        val arr = JSONObject(get("https://api.alquran.cloud/v1/surah/$n/quran-uthmani")).getJSONObject("data").getJSONArray("ayahs")
        val out = arrayOfNulls<String>(want)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val num = o.getInt("numberInSurah")
            if (num !in 1..want) return null
            var tx = o.getString("text").trim()
            // This source glues the Basmala to the first verse of every surah except Al-Fatiha: remove it.
            if (num == 1 && n != 1 && n != 9) {
                val w = tx.split(' ')
                if (w.size > 4 && norm(w.take(4).joinToString(" ")) == "بسم الله الرحمن الرحيم") tx = w.drop(4).joinToString(" ")
            }
            out[num - 1] = tx
        }
        return if (out.any { it.isNullOrBlank() }) null else out.map { it!! }
    }
}
