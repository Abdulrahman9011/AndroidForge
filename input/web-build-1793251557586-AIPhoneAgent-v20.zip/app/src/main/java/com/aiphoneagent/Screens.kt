package com.aiphoneagent

import android.app.Activity
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

// ======================================================================= drag the sheet down to close it

/** Makes a bottom sheet follow the finger downwards; releasing past ~110 dp (or a quick fling) closes it, otherwise it springs back. */
@Composable
internal fun Modifier.swipeDown(onDismiss: () -> Unit): Modifier {
    val off = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val th = with(LocalDensity.current) { 110.dp.toPx() }
    val cb by rememberUpdatedState(onDismiss)
    return this.offset { IntOffset(0, off.value.roundToInt()) }.pointerInput(Unit) {
        var last = 0f
        detectVerticalDragGestures(
            onDragStart = { last = 0f },
            onDragEnd = { scope.launch { if (off.value > th || last > 18f) cb() else off.animateTo(0f, tween(180)) } },
            onDragCancel = { scope.launch { off.animateTo(0f, tween(180)) } },
            onVerticalDrag = { c, dy -> c.consume(); last = dy; scope.launch { off.snapTo((off.value + dy).coerceAtLeast(0f)) } }
        )
    }
}

// ======================================================================= message text with copyable code blocks

private class Seg(val code: Boolean, val lang: String, val text: String)

private val FENCE = Regex("```([\\w+#.\\-]*)[ \\t]*\\n?([\\s\\S]*?)(```|$)")

private fun segments(t: String): List<Seg> {
    val out = ArrayList<Seg>()
    var pos = 0
    for (m in FENCE.findAll(t)) {
        if (m.range.first > pos) t.substring(pos, m.range.first).trim('\n').takeIf { it.isNotBlank() }?.let { out += Seg(false, "", it) }
        out += Seg(true, m.groupValues[1], m.groupValues[2].trimEnd('\n'))
        pos = m.range.last + 1
    }
    if (pos < t.length) t.substring(pos).trim('\n').takeIf { it.isNotBlank() }?.let { out += Seg(false, "", it) }
    return out
}

internal fun hasCode(t: String) = t.contains("```")

/** A message body: normal text, and every ``` block as its own box with a copy button (works for any text, not only Python). */
@Composable
internal fun RichText(text: String, color: Color) {
    if (!hasCode(text)) { Text(text, color = color, fontSize = 15.sp, lineHeight = 22.sp); return }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        segments(text).forEach { s ->
            if (s.code) CodeBlock(s.lang, s.text) else Text(s.text, color = color, fontSize = 15.sp, lineHeight = 22.sp)
        }
    }
}

@Composable
private fun CodeBlock(lang: String, body: String) {
    val ctx = LocalContext.current
    var copied by remember(body.length / 40) { mutableStateOf(false) }
    LaunchedEffect(copied) { if (copied) { delay(1600); copied = false } }
    val shape = RoundedCornerShape(14.dp)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.fillMaxWidth().clip(shape).background(Color(0xFF0D0D0F)).border(1.dp, Color.White.copy(alpha = 0.10f), shape)) {
            Row(Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.06f)).padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(lang.ifBlank { "code" }, Modifier.weight(1f), color = InkDim, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Row(
                    Modifier.clickable { ctx.copyText(body); copied = true }.padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    LineIcon(16.dp) { s, sw -> icCopy(if (copied) Ok else InkDim, s, sw) }
                    Text(if (copied) "Copied" else "Copy", color = if (copied) Ok else InkDim, fontSize = 12.sp)
                }
            }
            Box(Modifier.horizontalScroll(rememberScrollState()).padding(12.dp)) {
                SelectionContainer { Text(body, color = Color(0xFFDAD7CF), fontSize = 12.5.sp, lineHeight = 18.sp, fontFamily = FontFamily.Monospace) }
            }
        }
    }
}

// ======================================================================= avatar with the user's photo

@Composable
internal fun UserAvatar(d: Dp) {
    val ctx = LocalContext.current
    val ver = UserProfile.photoVersion
    val mail = UserProfile.email
    val bmp by produceState<ImageBitmap?>(null, ver, mail) {
        value = withContext(Dispatchers.IO) { UserProfile.photo(ctx)?.let { f -> BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap() } }
    }
    val b = bmp
    if (b != null) Image(b, null, Modifier.size(d).clip(CircleShape), contentScale = ContentScale.Crop) else Avatar(d)
}

// ======================================================================= small shared pieces

@Composable
internal fun BackArrow(onClick: () -> Unit) {
    Box(Modifier.size(42.dp).glass(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        // RTL app: the "back" arrow points to the right.
        LineIcon(20.dp) { s, sw ->
            drawLine(Ink, Offset(s * 0.2f, s * 0.5f), Offset(s * 0.8f, s * 0.5f), sw, StrokeCap.Round)
            drawLine(Ink, Offset(s * 0.8f, s * 0.5f), Offset(s * 0.55f, s * 0.25f), sw, StrokeCap.Round)
            drawLine(Ink, Offset(s * 0.8f, s * 0.5f), Offset(s * 0.55f, s * 0.75f), sw, StrokeCap.Round)
        }
    }
}

@Composable
internal fun AppSwitch(checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Switch(checked, onChange, enabled = enabled, colors = SwitchDefaults.colors(
        checkedThumbColor = Ink, checkedTrackColor = Color.White.copy(alpha = 0.28f), checkedBorderColor = Color.Transparent,
        uncheckedThumbColor = InkDim, uncheckedTrackColor = Color.White.copy(alpha = 0.08f), uncheckedBorderColor = Color.White.copy(alpha = 0.2f)))
}

@Composable
private fun SettingSwitch(title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Ink, fontSize = 14.sp, lineHeight = 20.sp)
            if (sub != null) Text(sub, color = InkDim, fontSize = 11.5.sp, lineHeight = 16.sp)
        }
        AppSwitch(checked, onChange = onChange)
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = InkDim, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 6.dp))
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp), 0.8f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
    }
}

@Composable
private fun Hint(t: String, color: Color = InkDim) = Text(t, color = color, fontSize = 11.5.sp, lineHeight = 16.sp)

// ======================================================================= SETTINGS (full page)

@Composable
internal fun SettingsScreen(onClose: () -> Unit, onVoicePicker: () -> Unit, onProfile: () -> Unit) {
    val ctx = LocalContext.current
    val c = AgentController
    @Suppress("UNUSED_VARIABLE") val rv = QuotaTracker.version
    @Suppress("UNUSED_VARIABLE") val tv = TokenBudget.version
    @Suppress("UNUSED_VARIABLE") val ev = Extras.ver

    var aiUrl by remember { mutableStateOf(c.aiBaseUrl) }
    var aiModel by remember { mutableStateOf(c.aiModel) }
    var aiKey by remember { mutableStateOf(c.apiKeys) }
    var useAi by remember { mutableStateOf(c.useAi) }
    var useVision by remember { mutableStateOf(c.useVision) }
    var visionModel by remember { mutableStateOf(c.visionModel) }
    var gemKey by remember { mutableStateOf(c.geminiKey) }
    var harsh by remember { mutableStateOf(c.harshMode) }
    var adult by remember { mutableStateOf(c.adultMode) }
    var qafOn by remember { mutableStateOf(Extras.connectorOn("qaf")) }
    var qafUrl by remember { mutableStateOf(Extras.qafUrl) }
    var qafKey by remember { mutableStateOf(Extras.qafKey) }
    var vAlways by remember { mutableStateOf(Voice.always) }
    var vHands by remember { mutableStateOf(Voice.handsFree) }
    var sttLang by remember { mutableStateOf(Voice.sttLang) }
    var ttsUrl by remember { mutableStateOf(Voice.ttsUrl) }
    var ttsModel by remember { mutableStateOf(Voice.ttsModel) }
    val scope = rememberCoroutineScope()
    var modelMsg by remember { mutableStateOf(if (LlmPlanner.isReady()) "مثبّت (${LlmPlanner.sizeMb()} MB)" else "غير مثبّت") }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { modelMsg = "جارٍ النسخ…"; scope.launch { modelMsg = if (LlmPlanner.importModel(uri)) "مثبّت (${LlmPlanner.sizeMb()} MB)" else "فشل النسخ" } }
    }
    var cookieMsg by remember { mutableStateOf(if (MediaDownloader.hasCookies(ctx)) "مستورد" else "غير موجود") }
    val cookiePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) cookieMsg = if (MediaDownloader.importCookies(ctx, uri)) "مستورد" else "فشل النسخ"
    }

    fun save() {
        c.aiBaseUrl = aiUrl; c.aiModel = aiModel; c.apiKeys = aiKey; c.useAi = useAi; c.useVision = useVision; c.visionModel = visionModel; c.geminiKey = gemKey
        c.harshMode = harsh; c.adultMode = adult
        Extras.setConnector("qaf", qafOn)
        if (qafUrl.isNotBlank() && qafUrl != Extras.qafUrl) Extras.qafUrl = qafUrl
        if (qafKey.isNotBlank() && qafKey != Extras.qafKey) Extras.qafKey = qafKey
        Voice.always = vAlways; Voice.applyHandsFree(vHands)
        Voice.ttsUrl = ttsUrl; Voice.ttsModel = ttsModel; Voice.sttLang = sttLang
    }
    val close = { save(); onClose() }
    BackHandler(true) { close() }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF131315)).pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding().navigationBarsPadding().imePadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BackArrow(close)
            Text("الإعدادات", Modifier.weight(1f), color = Ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text("يُحفظ تلقائياً", color = InkDim, fontSize = 11.sp)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {

            // ---- account
            Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp), 0.8f).clickable { save(); onProfile() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                UserAvatar(52.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(UserProfile.name, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(UserProfile.subtitle, color = InkDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(if (UserProfile.signedIn) "الحساب" else "تسجيل الدخول", color = Ok, fontSize = 13.sp)
            }

            // ---- chat style
            Section("أسلوب الدردشة") {
                SettingSwitch("الرد القاسي والشتم", "مطفأ افتراضياً. وهو مطفأ: ما بشتم ولا برد بقسوة أبداً. إذا فعّلته بيرد بوقاحة وتريقة (بدون المساس بالدين أو العائلة)، والأسئلة الدينية تبقى محترمة دائماً.", harsh) { harsh = it }
                SettingSwitch("وضع البالغين (+18)", "أنا عمري 18 أو أكتر، فعّل الكلام الصريح بالدردشة (نماذج Llama على Groq فقط، وبحدود صارمة).", adult) { adult = it }
            }

            // ---- religious questions
            Section("الأسئلة الدينية (Qaf AI)") {
                SettingSwitch("أجب الأسئلة الدينية من Qaf", "أي سؤال عن حكم أو حديث أو تفسير أو دعاء يُرسل لـ Qaf ويظهر جوابه كما هو بدون تدخل من النموذج.", qafOn) { qafOn = it }
                GlassField("عنوان Qaf API", qafUrl, { qafUrl = it })
                GlassField("مفتاح Qaf", qafKey, { qafKey = it }, secret = true)
                Hint("لو ما اشتغل، افتح لوحة مطوّري Qaf وانسخ عنوان الطلب (Endpoint) الصحيح هنا. المفتاح يُرسل فقط لهذا العنوان.")
            }

            // ---- AI
            Section("الذكاء الاصطناعي") {
                SettingSwitch("استخدم الذكاء الاصطناعي دائماً", "وإلا يُستخدم فقط للأوامر التي لا يفهمها التطبيق بنفسه.", useAi) { useAi = it }
                GlassField("عنوان الخدمة (متوافق مع OpenAI)", aiUrl, { aiUrl = it })
                GlassField("النموذج الذكي (يخطط ويحل المواقف الصعبة)", aiModel, { aiModel = it })
                GlassField("مفاتيح API (مفتاح بكل سطر)", aiKey, { aiKey = it }, secret = true, lines = 4)
                Hint("الحصة المجانية في Groq محسوبة لكل حساب لا لكل مفتاح. المفاتيح تتبدّل تلقائياً عند الوصول للحد.")
                GlassField("مفتاح Gemini المجاني (احتياطي)", gemKey, { gemKey = it }, secret = true)
                Hint("من aistudio.google.com/apikey. يشتغل فوراً لما تخلص حصة Groq.")
                SettingSwitch("الوضع السريع", "نموذج سريع يشوف الصور لكل خطوة، والنموذج الذكي يخطط ويتدخل لما يتعثر.", useVision) { useVision = it }
                if (useVision) GlassField("النموذج السريع", visionModel, { visionModel = it })
            }

            // ---- voice
            Section("الصوت") {
                SettingSwitch("رد صوتي دائماً", "وإلا فقط لما تحكي معه.", vAlways) { vAlways = it }
                SettingSwitch("وضع المحادثة", "يستمع تلقائياً بعد كل رد والتطبيق مفتوح.", vHands) { vHands = it }
                GlassButton("اختيار الصوت وتجربته", Modifier.fillMaxWidth()) { save(); onVoicePicker() }
                Hint("الاستماع عبر Whisper يفهم أغلب لغات العالم واللهجات العربية ويكتشف اللغة لحاله.")
                GlassField("لغة التعرف الاحتياطي", sttLang, { sttLang = it })
                GlassField("عنوان الصوت (TTS)", ttsUrl, { ttsUrl = it })
                GlassField("نموذج الصوت", ttsModel, { ttsModel = it })
                if (Voice.ttsStatus.isNotBlank()) Hint("آخر مشكلة بالصوت الطبيعي: ${Voice.ttsStatus}", Danger)
            }

            // ---- real usage
            Section("الرصيد والاستهلاك (أرقام حقيقية)") {
                Text("المستهلك اليوم على هذا الهاتف: ${QuotaTracker.fmt(TokenBudget.used())} توكن", color = Ink, fontSize = 14.sp)
                Hint("عدّاد دقيق: يُجمع من حقل الاستهلاك الذي يرسله المزوّد مع كل رد. لا يوجد أي رقم تقديري.")
                QuotaTracker.requestsLeftToday()?.let { Text("الطلبات المتبقية اليوم: $it", color = Ink, fontSize = 14.sp); Hint("قيمة فعلية من ترويسات Groq لآخر نموذج استُخدم، مجموعة على كل المفاتيح.") }
                val daily = QuotaTracker.dailyAll()
                daily.forEach { d ->
                    Text("${d.model.substringAfterLast('/')} · مفتاح …${d.keyTail}: المتبقي اليومي ${QuotaTracker.fmt((d.limit - d.used).coerceAtLeast(0))} من ${QuotaTracker.fmt(d.limit)} توكن", color = Danger, fontSize = 12.sp, lineHeight = 17.sp)
                }
                val qs = QuotaTracker.all()
                if (qs.isEmpty() && daily.isEmpty()) Hint("تظهر الأرقام بعد أول طلب للذكاء الاصطناعي.")
                qs.forEach { q ->
                    Text("${q.model.substringAfterLast('/')} · مفتاح …${q.keyTail}: ${QuotaTracker.fmt(q.remTok)} / ${QuotaTracker.fmt(q.limTok)} توكن بالدقيقة" +
                        (if (q.remReq >= 0) " · ${q.remReq} طلب باليوم" else "") + (if (q.resetTok.isNotBlank()) " · يتجدد خلال ${q.resetTok}" else ""),
                        color = if (q.remTok < 1500) Danger else InkDim, fontSize = 12.sp, lineHeight = 17.sp)
                }
                Hint("Groq لا يرسل رصيد التوكنز اليومي الكلي إلا عند الوصول للحد (يظهر بالأحمر أعلاه)، لذلك التطبيق لا يخمّنه. Gemini لا يرسل هذه المعلومات أبداً.")
            }

            // ---- local model & downloads
            Section("النموذج المحلي والتنزيلات") {
                Text("النموذج المحلي (دون إنترنت): $modelMsg", color = Ink, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("اختيار ملف .task") { modelPicker.launch(arrayOf("*/*")) }
                    GlassButton("حذف النموذج") { LlmPlanner.deleteModel(); modelMsg = "غير مثبّت" }
                }
                Text("ملف cookies.txt للتنزيل: $cookieMsg", color = Ink, fontSize = 13.sp)
                Hint("يلزم فقط لمحتوى إنستغرام/فيسبوك الذي يطلب تسجيل دخول.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("استيراد cookies.txt") { cookiePicker.launch(arrayOf("*/*")) }
                    GlassButton("حذفه") { MediaDownloader.deleteCookies(ctx); cookieMsg = "غير موجود" }
                }
            }

            // ---- data
            Section("البيانات") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("مسح المحادثة الحالية") { c.clearHistory() }
                    GlassButton("حذف المفاتيح", tint = Danger) { aiKey = ""; c.apiKeys = ""; gemKey = ""; c.geminiKey = ""; c.backendUrl = ""; c.backendToken = "" }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ======================================================================= AUTH (sign in / create account)

@Composable
internal fun AuthScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }
    var mail by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringExtra(android.accounts.AccountManager.KEY_ACCOUNT_NAME)?.takeIf { it.isNotBlank() }?.let {
            UserProfile.signInExternal(ctx, it, null); UserProfile.authSeen = true; onDone()
        }
    }
    fun finish() { UserProfile.authSeen = true; onDone() }
    BackHandler(true) { finish() }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF131315)).pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding().navigationBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        AgentLogoSmall()
        Text("AI Phone Agent", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        Text(if (tab == 0) "مرحباً بعودتك. سجّل الدخول للمتابعة" else "أنشئ حسابك خلال دقيقة", color = InkDim, fontSize = 14.sp)
        Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp), 0.8f).padding(4.dp)) {
            listOf("تسجيل الدخول", "إنشاء حساب").forEachIndexed { i, t ->
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(if (tab == i) Color.White.copy(alpha = 0.14f) else Color.Transparent)
                        .clickable { tab = i; err = null }.padding(vertical = 10.dp), contentAlignment = Alignment.Center
                ) { Text(t, color = if (tab == i) Ink else InkDim, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
            }
        }
        if (tab == 1) GlassField("الاسم الكامل", name, { name = it })
        GlassField("البريد الإلكتروني", mail, { mail = it })
        GlassField("كلمة المرور", pass, { pass = it }, secret = true)
        if (tab == 1) {
            GlassField("تأكيد كلمة المرور", pass2, { pass2 = it }, secret = true)
            Hint("8 أحرف على الأقل، وتحتوي أحرفاً وأرقاماً.")
        }
        err?.let { Text(it, color = Danger, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.fillMaxWidth()) }
        GlassButton(if (tab == 0) "تسجيل الدخول" else "إنشاء الحساب", Modifier.fillMaxWidth(), enabled = !busy, strong = true) {
            err = if (tab == 0) UserProfile.login(ctx, mail, pass) else UserProfile.register(ctx, name, mail, pass, pass2)
            if (err == null) finish()
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f).height(1.dp).background(Color.White.copy(alpha = 0.12f)))
            Text("أو", color = InkDim, fontSize = 12.sp)
            Box(Modifier.weight(1f).height(1.dp).background(Color.White.copy(alpha = 0.12f)))
        }
        Row(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp), 1.2f).clickable(enabled = !busy) {
                val act = ctx as? Activity ?: return@clickable
                busy = true; err = null
                scope.launch {
                    val r = UserProfile.googleSignIn(act)
                    busy = false
                    when (r) {
                        null -> finish()
                        "" -> {}
                        "NOCLIENT" -> runCatching { picker.launch(UserProfile.chooserIntent()) }.onFailure { err = "ما لقيت حسابات Google على هالهاتف" }
                        else -> err = r
                    }
                }
            }.padding(vertical = 13.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(24.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) { Text("G", color = Color(0xFF4285F4), fontSize = 15.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(10.dp))
            Text("المتابعة باستخدام Google", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
        Text("المتابعة كضيف", color = InkDim, fontSize = 14.sp, modifier = Modifier.clickable { finish() }.padding(12.dp))
        Hint("حسابك يُحفظ على هذا الهاتف فقط، وكلمة المرور تُخزَّن مشفّرة (PBKDF2) ولا تُرسل لأي خادم.")
    }
}

@Composable
private fun AgentLogoSmall() {
    Box(Modifier.size(84.dp).glass(CircleShape, 1.6f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(34.dp)) {
            val u = size.width / 72f * 2f
            val cx = size.width / 2f; val cy = size.height / 2f
            val pts = listOf(-8.5f to -14f, -8.5f to 12f, -2.3f to 6.4f, 1.8f to 15.8f, 6.1f to 13.9f, 2f to 4.6f, 10.1f to 4.6f)
            val p = Path()
            pts.forEachIndexed { i, pt -> val x = cx + pt.first * u; val y = cy + pt.second * u; if (i == 0) p.moveTo(x, y) else p.lineTo(x, y) }
            p.close(); drawPath(p, Ink)
        }
    }
}

// ======================================================================= PROFILE

@Composable
internal fun ProfileScreen(onClose: () -> Unit, onSignedOut: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(UserProfile.name) }
    var old by remember { mutableStateOf("") }
    var new1 by remember { mutableStateOf("") }
    var new2 by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<Pair<Boolean, String>?>(null) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) msg = if (UserProfile.setPhoto(ctx, uri)) true to "تم تغيير الصورة" else false to "تعذّر استخدام هذه الصورة"
    }
    BackHandler(true) { onClose() }
    Column(
        Modifier.fillMaxSize().background(Color(0xFF131315)).pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding().navigationBarsPadding().imePadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BackArrow(onClose)
            Text("حسابي", Modifier.weight(1f), color = Ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.clickable { photoPicker.launch("image/*") }) { UserAvatar(112.dp) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("تغيير الصورة", strong = true) { photoPicker.launch("image/*") }
                if (UserProfile.photo(ctx) != null) GlassButton("إزالة الصورة", tint = Danger) { UserProfile.removePhoto(ctx); msg = true to "تمت إزالة الصورة" }
            }
            Text(UserProfile.email, color = InkDim, fontSize = 13.sp)
            Text(if (UserProfile.provider == "google") "حساب Google" else "حساب بريد إلكتروني", color = InkDim, fontSize = 12.sp)
            msg?.let { (ok, t) -> Text(t, color = if (ok) Ok else Danger, fontSize = 13.sp, textAlign = TextAlign.Center) }

            Section("الاسم") {
                GlassField("الاسم الظاهر", name, { name = it })
                GlassButton("حفظ الاسم", Modifier.fillMaxWidth(), strong = true) {
                    val e = UserProfile.updateName(ctx, name); msg = if (e == null) true to "تم حفظ الاسم" else false to e
                }
            }
            if (UserProfile.provider == "local") Section("تغيير كلمة المرور") {
                GlassField("كلمة المرور الحالية", old, { old = it }, secret = true)
                GlassField("كلمة المرور الجديدة", new1, { new1 = it }, secret = true)
                GlassField("تأكيد كلمة المرور الجديدة", new2, { new2 = it }, secret = true)
                GlassButton("تغيير كلمة المرور", Modifier.fillMaxWidth(), strong = true) {
                    val e = UserProfile.changePassword(ctx, old, new1, new2)
                    msg = if (e == null) { old = ""; new1 = ""; new2 = ""; true to "تم تغيير كلمة المرور" } else false to e
                }
            } else Section("كلمة المرور") { Hint("حسابك مرتبط بـ Google، وكلمة المرور تُدار من حساب Google.") }
            GlassButton("تسجيل الخروج", Modifier.fillMaxWidth(), tint = Danger) { UserProfile.signOut(ctx); onSignedOut() }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ======================================================================= the "+" sheet: tiles + projects / permission / connectors / skills / memory

private fun DrawScope.icFolder(c: Color, s: Float, sw: Float) {
    val p = Path().apply {
        moveTo(s * 0.1f, s * 0.28f); lineTo(s * 0.4f, s * 0.28f); lineTo(s * 0.5f, s * 0.4f); lineTo(s * 0.9f, s * 0.4f)
        lineTo(s * 0.9f, s * 0.82f); lineTo(s * 0.1f, s * 0.82f); close()
    }
    drawPath(p, c, style = strokeOf(sw))
}
private fun DrawScope.icShield(c: Color, s: Float, sw: Float) {
    val p = Path().apply {
        moveTo(s * 0.5f, s * 0.1f); lineTo(s * 0.84f, s * 0.24f); lineTo(s * 0.84f, s * 0.52f)
        cubicTo(s * 0.84f, s * 0.72f, s * 0.68f, s * 0.86f, s * 0.5f, s * 0.92f)
        cubicTo(s * 0.32f, s * 0.86f, s * 0.16f, s * 0.72f, s * 0.16f, s * 0.52f); lineTo(s * 0.16f, s * 0.24f); close()
    }
    drawPath(p, c, style = strokeOf(sw))
    drawLine(c, Offset(s * 0.36f, s * 0.52f), Offset(s * 0.47f, s * 0.64f), sw, StrokeCap.Round)
    drawLine(c, Offset(s * 0.47f, s * 0.64f), Offset(s * 0.66f, s * 0.4f), sw, StrokeCap.Round)
}
private fun DrawScope.icBlocks(c: Color, s: Float, sw: Float) {
    val st = strokeOf(sw)
    drawRoundRect(c, Offset(s * 0.12f, s * 0.46f), Size(s * 0.3f, s * 0.3f), CornerRadius(s * 0.05f), style = st)
    drawRoundRect(c, Offset(s * 0.12f, s * 0.12f), Size(s * 0.3f, s * 0.3f), CornerRadius(s * 0.05f), style = st)
    drawRoundRect(c, Offset(s * 0.46f, s * 0.46f), Size(s * 0.3f, s * 0.3f), CornerRadius(s * 0.05f), style = st)
    drawRoundRect(c, Offset(s * 0.6f, s * 0.12f), Size(s * 0.26f, s * 0.26f), CornerRadius(s * 0.05f), style = st)
}
private fun DrawScope.icSpark(c: Color, s: Float, sw: Float) {
    val p = Path().apply {
        moveTo(s * 0.5f, s * 0.08f); lineTo(s * 0.6f, s * 0.4f); lineTo(s * 0.92f, s * 0.5f); lineTo(s * 0.6f, s * 0.6f)
        lineTo(s * 0.5f, s * 0.92f); lineTo(s * 0.4f, s * 0.6f); lineTo(s * 0.08f, s * 0.5f); lineTo(s * 0.4f, s * 0.4f); close()
    }
    drawPath(p, c, style = strokeOf(sw))
}
private fun DrawScope.icMemory(c: Color, s: Float, sw: Float) {
    drawArc(c, -50f, 290f, false, Offset(s * 0.14f, s * 0.14f), Size(s * 0.72f, s * 0.72f), style = strokeOf(sw))
    drawLine(c, Offset(s * 0.5f, s * 0.3f), Offset(s * 0.5f, s * 0.52f), sw, StrokeCap.Round)
    drawLine(c, Offset(s * 0.5f, s * 0.52f), Offset(s * 0.66f, s * 0.6f), sw, StrokeCap.Round)
}
private fun DrawScope.icBackChevron(c: Color, s: Float, sw: Float) {
    drawLine(c, Offset(s * 0.65f, s * 0.2f), Offset(s * 0.35f, s * 0.5f), sw, StrokeCap.Round)
    drawLine(c, Offset(s * 0.35f, s * 0.5f), Offset(s * 0.65f, s * 0.8f), sw, StrokeCap.Round)
}

@Composable
private fun SheetRow(title: String, value: String?, icon: DrawScope.(Float, Float) -> Unit, trailing: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.8f).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f)), contentAlignment = Alignment.Center) { LineIcon(20.dp, icon) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 16.sp)
            if (value != null) Text(value, color = InkDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (trailing != null) trailing() else LineIcon(14.dp) { s, sw -> icBackChevron(InkDim, s, sw) }
    }
}

@Composable
private fun PageHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onBack), contentAlignment = Alignment.Center) {
            LineIcon(18.dp) { s, sw ->
                drawLine(Ink, Offset(s * 0.2f, s * 0.5f), Offset(s * 0.8f, s * 0.5f), sw, StrokeCap.Round)
                drawLine(Ink, Offset(s * 0.8f, s * 0.5f), Offset(s * 0.55f, s * 0.25f), sw, StrokeCap.Round)
                drawLine(Ink, Offset(s * 0.8f, s * 0.5f), Offset(s * 0.55f, s * 0.75f), sw, StrokeCap.Round)
            }
        }
        Text(title, Modifier.weight(1f), color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ChoiceRow(title: String, sub: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (selected) Color.White.copy(alpha = 0.10f) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = if (selected) Ok else Ink, fontSize = 15.sp)
            if (sub.isNotBlank()) Text(sub, color = InkDim, fontSize = 12.sp, lineHeight = 17.sp)
        }
        if (selected) Text("\u2713", color = Ok, fontSize = 17.sp)
    }
}

/**
 * "+" sheet: camera / photos / files on top, then Projects, Permission, Connectors, Skills and Memory rows.
 * Drag it down (anywhere that is not scrolling) to close it. [page] is hoisted so the system Back button steps out of a sub-page first.
 */
@Composable
internal fun AttachSheetV2(page: String, setPage: (String) -> Unit, onClose: () -> Unit, onPhoto: () -> Unit, onVideo: () -> Unit, onGallery: () -> Unit, onFiles: () -> Unit) {
    @Suppress("UNUSED_VARIABLE") val ev = Extras.ver
    val chatId = AgentController.currentChatId
    val proj = Extras.projectOf(chatId)
    Column(
        Modifier.swipeDown(onClose).fillMaxWidth().heightIn(max = 640.dp).sheet(TopSheetShape).pointerInput(Unit) { detectTapGestures { } }
            .imePadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SheetHandle()
        when (page) {
            "projects" -> ProjectsPage(chatId, { setPage("main") })
            "permission" -> {
                PageHeader("الصلاحيات") { setPage("main") }
                ChoiceRow("يدوي", "يسألك قبل أي إجراء حساس على الهاتف: إرسال، حذف، شراء، تأكيد…", !Extras.permissionAuto) { Extras.permissionAuto = false }
                ChoiceRow("تلقائي", "ينفّذ الإجراءات بدون سؤال، ما عدا الدفع والشراء والحذف والتحويل فتبقى بموافقتك.", Extras.permissionAuto) { Extras.permissionAuto = true }
            }
            "connectors" -> {
                PageHeader("الموصّلات") { setPage("main") }
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Extras.connectors.forEach { cn ->
                        Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.8f).padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(cn.title, color = Ink, fontSize = 15.sp)
                                Text(cn.desc, color = InkDim, fontSize = 12.sp, lineHeight = 17.sp)
                                if (cn.id == "qaf" && Extras.qafKey.isBlank()) Text("لا يوجد مفتاح Qaf: أضفه من الإعدادات.", color = Danger, fontSize = 11.5.sp)
                            }
                            AppSwitch(Extras.connectorOn(cn.id)) { Extras.setConnector(cn.id, it) }
                        }
                    }
                }
            }
            "skills" -> SkillsPage { setPage("main") }
            "memory" -> {
                PageHeader("الذاكرة") { setPage("main") }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("احفظ معلومات عني", Modifier.weight(1f), color = Ink, fontSize = 15.sp)
                    AppSwitch(Extras.memoryOn) { Extras.memoryOn = it }
                }
                Text("اكتب بالدردشة: «تذكّر أن اسمي أحمد» وبحفظها هون وبستخدمها بالأجوبة. لا يُحفظ شي إلا لما تطلب.", color = InkDim, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.fillMaxWidth())
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (Extras.memory.isEmpty()) Text("الذاكرة فاضية.", color = InkDim, fontSize = 13.sp)
                    Extras.memory.toList().forEachIndexed { i, t ->
                        Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp), 0.7f).padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(t, Modifier.weight(1f).padding(vertical = 10.dp), color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                            Box(Modifier.size(40.dp).clip(CircleShape).clickable { Extras.removeMemory(i) }, contentAlignment = Alignment.Center) { Text("×", color = InkDim, fontSize = 20.sp) }
                        }
                    }
                }
                if (Extras.memory.isNotEmpty()) GlassButton("مسح كل الذاكرة", Modifier.fillMaxWidth(), tint = Danger) { Extras.clearMemory() }
            }
            else -> {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                        LineIcon(18.dp) { s, sw ->
                            drawLine(Ink, Offset(s * 0.2f, s * 0.2f), Offset(s * 0.8f, s * 0.8f), sw, StrokeCap.Round)
                            drawLine(Ink, Offset(s * 0.8f, s * 0.2f), Offset(s * 0.2f, s * 0.8f), sw, StrokeCap.Round)
                        }
                    }
                    Text("إضافة إلى الجلسة", Modifier.weight(1f), color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    Spacer(Modifier.width(38.dp))
                }
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AttachTile("الكاميرا", Modifier.weight(1f), onPhoto) { s, sw -> icCamera(Ink, s, sw) }
                        AttachTile("فيديو", Modifier.weight(1f), onVideo) { s, sw -> icVideoCam(Ink, s, sw) }
                        AttachTile("الصور", Modifier.weight(1f), onGallery) { s, sw -> icImage(Ink, s, sw) }
                        AttachTile("الملفات", Modifier.weight(1f), onFiles) { s, sw -> icFile(Ink, s, sw) }
                    }
                    SheetRow("إضافة إلى مشروع", proj?.name ?: "بدون", { s, sw -> icFolder(Ink, s, sw) }) { setPage("projects") }
                    SheetRow("الصلاحيات", if (Extras.permissionAuto) "تلقائي" else "يدوي", { s, sw -> icShield(Ink, s, sw) }) { setPage("permission") }
                    SheetRow("الموصّلات", Extras.connectors.count { Extras.connectorOn(it.id) }.let { "$it مفعّل" }, { s, sw -> icBlocks(Ink, s, sw) }) { setPage("connectors") }
                    SheetRow("المهارات", skillsSummary(), { s, sw -> icSpark(Ink, s, sw) }) { setPage("skills") }
                    SheetRow("الذاكرة", if (Extras.memoryOn) "${Extras.memory.size} معلومة محفوظة" else "متوقفة", { s, sw -> icMemory(Ink, s, sw) },
                        trailing = { AppSwitch(Extras.memoryOn) { Extras.memoryOn = it } }) { setPage("memory") }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
    }
}

private fun skillsSummary(): String { val n = Extras.skills().count { Extras.skillOn(it.id) }; return if (n == 0) "لا شي مفعّل" else "$n مفعّلة" }

@Composable
private fun SkillsPage(onBack: () -> Unit) {
    var adding by remember { mutableStateOf(false) }
    var n by remember { mutableStateOf("") }
    var t by remember { mutableStateOf("") }
    PageHeader("المهارات", onBack)
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Extras.skills().forEach { sk ->
            Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.8f).padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(sk.name, color = Ink, fontSize = 15.sp)
                    Text(sk.text, color = InkDim, fontSize = 12.sp, lineHeight = 17.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
                if (!sk.builtin) Box(Modifier.size(38.dp).clip(CircleShape).clickable { Extras.removeSkill(sk.id) }, contentAlignment = Alignment.Center) { Text("×", color = InkDim, fontSize = 20.sp) }
                AppSwitch(Extras.skillOn(sk.id)) { Extras.setSkill(sk.id, it) }
                Spacer(Modifier.width(4.dp))
            }
        }
        if (adding) {
            GlassField("اسم المهارة", n, { n = it })
            GlassField("التعليمات (كيف يتصرف عندما تكون المهارة مفعّلة)", t, { t = it }, lines = 4)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("إضافة", Modifier.weight(1f), enabled = n.isNotBlank() && t.isNotBlank(), strong = true) { Extras.addSkill(n, t); n = ""; t = ""; adding = false }
                GlassButton("إلغاء", Modifier.weight(1f)) { adding = false }
            }
        } else GlassButton("+ مهارة جديدة", Modifier.fillMaxWidth()) { adding = true }
    }
}

@Composable
private fun ProjectsPage(chatId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<String?>(null) }     // project id, or "new"
    var name by remember { mutableStateOf("") }
    var ins by remember { mutableStateOf("") }
    val current = Extras.projectOf(chatId)
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val id = editing
        if (uri != null && id != null && id != "new") scope.launch {
            val ok = withContext(Dispatchers.IO) { Extras.addProjectFile(ctx, id, uri, displayName(ctx, uri)) }
            if (!ok) android.widget.Toast.makeText(ctx, "الملف لازم يكون نصياً (txt, md, كود, csv, json…)", android.widget.Toast.LENGTH_LONG).show()
        }
    }
    val ed = editing
    if (ed == null) {
        PageHeader("المشاريع", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceRow("بدون مشروع", "محادثة عادية", current == null) { Extras.setChatProject(chatId, null) }
            Extras.projects.toList().forEach { p ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { ChoiceRow(p.name, if (p.files.isEmpty()) p.instructions.take(60) else "${p.files.size} ملف · " + p.instructions.take(40), current?.id == p.id) { Extras.setChatProject(chatId, p.id) } }
                    Box(Modifier.size(42.dp).clip(CircleShape).clickable { editing = p.id; name = p.name; ins = p.instructions }, contentAlignment = Alignment.Center) { LineIcon(18.dp) { s, sw -> icEdit(InkDim, s, sw) } }
                }
            }
            GlassButton("+ مشروع جديد", Modifier.fillMaxWidth()) { editing = "new"; name = ""; ins = "" }
            Text("المشروع = تعليمات وملفات نصية يتذكرها المساعد في هذه المحادثة (مثل مشاريع Claude).", color = InkDim, fontSize = 11.5.sp, lineHeight = 16.sp)
        }
    } else {
        PageHeader(if (ed == "new") "مشروع جديد" else "تعديل المشروع") { editing = null }
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassField("اسم المشروع", name, { name = it })
            GlassField("التعليمات (كيف تريد أن يتصرف في هذا المشروع)", ins, { ins = it }, lines = 5)
            if (ed != "new") {
                Extras.projects.firstOrNull { it.id == ed }?.files?.forEachIndexed { i, f ->
                    Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp), 0.7f).padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(f.first, Modifier.weight(1f).padding(vertical = 10.dp), color = Ink, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Box(Modifier.size(40.dp).clip(CircleShape).clickable { Extras.removeProjectFile(ed, i) }, contentAlignment = Alignment.Center) { Text("×", color = InkDim, fontSize = 20.sp) }
                    }
                }
                GlassButton("إضافة ملف نصي للمشروع", Modifier.fillMaxWidth()) { filePicker.launch(arrayOf("text/*", "application/json", "application/xml", "application/javascript", "application/octet-stream")) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton(if (ed == "new") "إنشاء" else "حفظ", Modifier.weight(1f), enabled = name.isNotBlank(), strong = true) {
                    if (ed == "new") { Extras.addProject(name, ins)?.let { p -> editing = p.id; Extras.setChatProject(chatId, p.id) } }
                    else { Extras.updateProject(ed, name, ins); editing = null }
                }
                if (ed != "new") GlassButton("حذف", Modifier.weight(1f), tint = Danger) { Extras.removeProject(ed); editing = null }
            }
        }
    }
}
