package com.aiphoneagent

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class BuildAtt(val name: String, val bytes: ByteArray)

/**
 * Turns a request / a file into an installable APK without any local toolchain:
 *  1. builds the project files (WebView template for HTML, AI-written Compose project, or the user's own Gradle project),
 *  2. pushes them to a private GitHub repo (one atomic commit),
 *  3. GitHub Actions compiles; the APK (or the build log) comes back,
 *  4. on a failed build the compiler errors go to the model, which returns corrected files; repeat (max 4 builds).
 */
object AppBuilder {
    val log = mutableStateListOf<String>()
    var running by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
        private set
    var apk by mutableStateOf<File?>(null)
        private set
    var lastError by mutableStateOf<String?>(null)
        private set
    var appName by mutableStateOf("")
        private set
    var hasLast by mutableStateOf(false)
        private set

    /** Called on the main thread when a build ends: (apk or null, error or null). The chat uses it to hand over the finished app. */
    var onFinished: ((File?, String?) -> Unit)? = null

    private const val MAX_BUILDS = 5
    private const val REPO_NAME = "ai-app-builds"

    private lateinit var ctx: Context
    private lateinit var prefs: SharedPreferences
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var currentRun = 0L
    private var repo = ""
    private var branch = "main"

    private val files = LinkedHashMap<String, ByteArray>()
    private var mode = "native"      // native | web | gradle
    private var appId = ""

    fun init(c: Context) {
        ctx = c.applicationContext
        prefs = ctx.getSharedPreferences("builder", Context.MODE_PRIVATE)
        loadProject()
    }

    var ghToken: String
        get() = Secure.decrypt(prefs.getString("gh", "").orEmpty())
        set(v) { prefs.edit().putString("gh", Secure.encrypt(v.trim())).apply() }

    // ------------------------------------------------------------------ public API

    fun start(request: String, atts: List<BuildAtt>, continueLast: Boolean) {
        if (running) return
        running = true; lastError = null; apk = null; log.clear()
        JobService.begin(ctx, "بناء تطبيق", "يبدأ…")
        job = scope.launch {
            try {
                run(request.trim(), atts, continueLast && files.isNotEmpty())
            } catch (e: CancellationException) {
                say("أُوقف البناء.")
                if (currentRun != 0L && repo.isNotEmpty()) withContext(NonCancellable) {
                    runCatching { gh("POST", "/repos/$repo/actions/runs/$currentRun/cancel") }
                }
            } catch (e: Exception) {
                lastError = friendly(e); say("✗ " + lastError)
            } finally {
                running = false; currentRun = 0L
                withContext(NonCancellable) { saveProject() }
                JobService.end(ctx)
                if (apk != null) JobService.done(ctx, "✓ التطبيق جاهز", appName.ifBlank { "اضغط للتثبيت" })
                else lastError?.let { JobService.done(ctx, "فشل البناء", it.take(140)) }
                onFinished?.let { cb -> onFinished = null; runCatching { cb(apk, lastError) } }
            }
        }
    }

    fun stop() { job?.cancel() }

    fun install(c: Context) {
        val f = apk ?: return
        if (Build.VERSION.SDK_INT >= 26 && !c.packageManager.canRequestPackageInstalls()) {
            c.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        val uri = FileProvider.getUriForFile(c, c.packageName + ".files", f)
        c.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** The whole generated project (sources, gradle files; without the signing key) as a zip, for the user to keep or open in Android Studio. */
    fun exportProject(): File? {
        if (files.isEmpty()) return null
        return runCatching {
            val dir = File(ctx.cacheDir, "apk").apply { mkdirs() }
            val f = File(dir, (appName.ifBlank { "project" }.replace(Regex("[^\\p{L}\\p{N}_-]"), "_")) + "-source.zip")
            java.util.zip.ZipOutputStream(f.outputStream()).use { z ->
                for ((n, b) in files) { if (n.endsWith(".keystore")) continue; z.putNextEntry(java.util.zip.ZipEntry(n)); z.write(b); z.closeEntry() }
            }
            f
        }.getOrNull()
    }

    fun share(c: Context) {
        val f = apk ?: return
        val uri = FileProvider.getUriForFile(c, c.packageName + ".files", f)
        val send = Intent(Intent.ACTION_SEND).setType("application/vnd.android.package-archive")
            .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(Intent.createChooser(send, "مشاركة APK").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ------------------------------------------------------------------ orchestration

    private fun say(s: String) { log.add(s); if (log.size > 200) log.removeAt(0); status = s; JobService.update(ctx, s) }
    private fun tick(s: String) { status = s; JobService.update(ctx, s) }

    private fun friendly(e: Exception): String {
        val m = e.message.orEmpty()
        return when {
            e is java.net.UnknownHostException || m.contains("Unable to resolve host") -> "ما في إنترنت."
            isRateLimit(m) -> "حصة النماذج المجانية خلصت مؤقتاً. جرّب بعد دقائق أو أضف مفتاح Gemini/Groq بالإعدادات."
            m.isBlank() -> e.javaClass.simpleName
            else -> m.take(400)
        }
    }

    private fun backend(): DirectBackend {
        val c = AgentController
        if (c.apiKeyList.isEmpty() && c.geminiKey.isBlank()) error("أضف مفتاح Gemini أو Groq بالإعدادات: التطبيق يحتاج نموذجاً ليكتب ويصلح الكود.")
        return DirectBackend(c.aiBaseUrl, c.aiModel, c.apiKeyList, "", c.geminiKey, c.provider, c.geminiModel)
    }

    private suspend fun run(request: String, atts: List<BuildAtt>, cont: Boolean) {
        if (ghToken.isBlank()) error("أدخل توكن GitHub أولاً.")
        if (!cont && request.isBlank() && atts.isEmpty()) error("اكتب وصف التطبيق أو أرفق ملفاً.")
        if (cont && request.isBlank()) error("اكتب التعديل المطلوب.")
        say("أتحقق من حساب GitHub…")
        repo = ensureRepo()
        var be: DirectBackend? = null
        fun need(): DirectBackend = be ?: backend().also { be = it }

        if (cont) {
            say("أعدّل «$appName» حسب طلبك…")
            val n = revise(need(), null, request)
            if (n == 0) error("النموذج ما رجّع أي تعديل. وضّح الطلب أكثر.")
            say("عُدّل $n ملف.")
        } else {
            files.clear()
            val zip = atts.firstOrNull { it.name.endsWith(".zip", true) }
            val entries = zip?.let { unzip(it.bytes) } ?: emptyList()
            val gradleRoot = entries.map { it.name }
                .filter { it.substringAfterLast('/') == "settings.gradle" || it.substringAfterLast('/') == "settings.gradle.kts" }
                .minByOrNull { it.length }
            val flat = atts.filter { it !== zip } + entries
            when {
                gradleRoot != null -> {
                    say("وجدت مشروع Gradle جاهز، سأبنيه كما هو.")
                    val pre = gradleRoot.substringBeforeLast('/', "").let { if (it.isEmpty()) "" else "$it/" }
                    mode = "gradle"; appId = ""
                    for (e in entries) {
                        if (!e.name.startsWith(pre)) continue
                        val n = e.name.removePrefix(pre)
                        if (n.isBlank() || ignored(n) || e.bytes.size > 30_000_000) continue
                        files[n] = e.bytes
                    }
                    appName = Regex("rootProject\\.name\\s*=\\s*[\"'](.+?)[\"']").find(files["settings.gradle.kts"]?.let { String(it) } ?: files["settings.gradle"]?.let { String(it) } ?: "")?.groupValues?.get(1) ?: "مشروعك"
                }
                webFiles(flat) != null -> {
                    say("وجدت صفحة ويب، سأغلّفها بتطبيق أندرويد جاهز.")
                    createWeb(webFiles(flat)!!)
                }
                else -> createNative(need(), request, flat)
            }
        }

        buildLoop { need() }
    }

    private suspend fun buildLoop(need: () -> DirectBackend) {
        for (attempt in 1..MAX_BUILDS) {
            bumpVersion()
            if (attempt > 1) say("أرسل الإصلاح للبناء (محاولة $attempt من $MAX_BUILDS)…")
            val (runId, _) = try { forgeBuild() } catch (e: kotlin.coroutines.cancellation.CancellationException) { throw e } catch (e: Exception) { runCatching { cleanupRelease() }; throw e }
            var apkBytes: ByteArray? = null
            var logText = ""
            for (i in 0 until 4) {
                val r = fetchResult(runId)
                apkBytes = r.first; logText = r.second
                if (apkBytes != null || logText.isNotEmpty()) break
                delay(3000)
            }
            cleanupRelease()
            val got = apkBytes
            if (got != null) {
                val dir = File(ctx.cacheDir, "apk").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
                val f = File(dir, "app.apk")
                f.writeBytes(got)
                apk = f
                say("✓ جاهز: ${got.size / 1024 / 1024} MB. اضغط تثبيت.")
                return
            }
            if (logText.isBlank()) logText = runCatching { fetchRunLogs(runId) }.getOrDefault("")
            val errs = errorsOf(logText)
            if (errs.isEmpty() && logText.isBlank()) {
                say("✗ فشل البناء ولم أستطع جلب سجله من GitHub.")
                error("ما قدرت أجيب سجل البناء من GitHub، فما في أخطاء أرسلها للنموذج. افتح تبويب Actions بالمستودع $repo لتشوف سبب الفشل.")
            }
            say("✗ فشل البناء: " + (errs.firstOrNull() ?: tailOf(logText, 1).firstOrNull() ?: "").take(160))
            if (attempt == MAX_BUILDS) error("فشل البناء بعد $MAX_BUILDS محاولات. آخر خطأ: " + (errs.firstOrNull() ?: "غير معروف").take(300))
            say("أرسل الأخطاء للنموذج ليصلحها…")
            val n = revise(need(), errs.ifEmpty { tailOf(logText, 40) }, null)
            if (n == 0) error("النموذج ما قدر يصلح الخطأ: " + (errs.firstOrNull() ?: "").take(300))
            say("أُصلح $n ملف، أعيد البناء.")
        }
    }

    // ------------------------------------------------------------------ project creation

    private fun webFiles(list: List<BuildAtt>): List<BuildAtt>? {
        val htmls = list.filter { it.name.endsWith(".html", true) || it.name.endsWith(".htm", true) }
        if (htmls.isEmpty()) return null
        val idx = htmls.firstOrNull { it.name.substringAfterLast('/').equals("index.html", true) } ?: htmls.minByOrNull { it.name.length }!!
        val pre = idx.name.substringBeforeLast('/', "").let { if (it.isEmpty()) "" else "$it/" }
        return list.filter { it.name.startsWith(pre) }.mapNotNull {
            val n = if (it === idx) "index.html" else it.name.removePrefix(pre)
            if (ignored(n) || it.bytes.size > 30_000_000) null else BuildAtt(n, it.bytes)
        }
    }

    private fun ident(): String = "com.aibuild.app" + (1..6).map { ('a'..'z').random() }.joinToString("")

    private fun cleanName(s: String, fallback: String): String =
        s.replace(Regex("[<>&\"'\\\\@?\\n\\r]"), "").trim().take(30).ifBlank { fallback }

    private fun putBase(perms: List<String>, name: String, native: Boolean, extraDeps: List<String>, components: String = "") {
        files["settings.gradle.kts"] = SETTINGS_GRADLE.toByteArray()
        files["build.gradle.kts"] = ROOT_GRADLE.toByteArray()
        files["gradle.properties"] = GRADLE_PROPS.toByteArray()
        files["app/debug.keystore"] = ctx.assets.open("builder/debug.keystore").use { it.readBytes() }
        val deps = if (native) NATIVE_DEPS + extraDeps.joinToString("") { "    implementation(\"$it\")\n" } else WEB_DEPS
        files["app/build.gradle.kts"] = (if (native) APP_GRADLE_NATIVE else APP_GRADLE_WEB)
            .replace("@@APPID@@", appId).replace("@@DEPS@@", deps).replace("@@VC@@", versionCode().toString()).toByteArray()
        val permXml = (listOf("android.permission.INTERNET") + perms).distinct()
            .filter { Regex("android\\.permission\\.[A-Z_]+").matches(it) }
            .joinToString("\n") { "    <uses-permission android:name=\"$it\" />" }
        files["app/src/main/AndroidManifest.xml"] = MANIFEST.replace("@@PERMS@@", permXml).replace("@@COMPONENTS@@", components).toByteArray()
        files["app/src/main/res/values/strings.xml"] = "<resources>\n    <string name=\"app_name\">$name</string>\n</resources>\n".toByteArray()
        files["app/src/main/res/values/themes.xml"] = THEMES.toByteArray()
    }

    private fun versionCode() = (System.currentTimeMillis() / 60000L).toInt()

    private fun bumpVersion() {
        if (mode == "gradle") return
        val k = "app/build.gradle.kts"
        val t = files[k]?.let { String(it) } ?: return
        files[k] = t.replace(Regex("versionCode = \\d+"), "versionCode = ${versionCode()}").toByteArray()
    }

    private fun createWeb(list: List<BuildAtt>) {
        mode = "web"; appId = ident()
        val html = list.firstOrNull { it.name == "index.html" }?.let { String(it.bytes) }.orEmpty()
        val title = Regex("<title>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1).orEmpty()
        appName = cleanName(title, "تطبيق ويب")
        putBase(emptyList(), appName, false, emptyList())
        files["app/src/main/java/" + appId.replace('.', '/') + "/MainActivity.kt"] = WEB_ACTIVITY.replace("@@PKG@@", appId).toByteArray()
        for (a in list) files["app/src/main/assets/www/" + a.name] = a.bytes
        say("«$appName»: ${list.size} ملف ويب.")
    }

    private suspend fun createNative(be: DirectBackend, request: String, refs: List<BuildAtt>) {
        mode = "native"; appId = ident()
        say("أخطط للتطبيق…")
        val ref = refText(refs)
        val raw = llm(be, PLAN_SYS, "REQUEST:\n$request\n\n$ref", 1500)
        val j = try { JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)) } catch (e: Exception) { error("فشل التخطيط: النموذج ما رجّع خطة مفهومة. أعد المحاولة.") }
        appName = cleanName(j.optString("appName"), "تطبيقي")
        val summary = j.optString("summary") + (j.optJSONArray("features").toList().takeIf { it.isNotEmpty() }?.let { "\nFeatures to implement (ALL of them): " + it.joinToString("; ") } ?: "")
        val perms = j.optJSONArray("permissions").toList()
        val deps = j.optJSONArray("deps").toList().filter { Regex("[\\w.\\-]+:[\\w.\\-]+:[\\w.\\-]+").matches(it) }.take(8)
        val plan = LinkedHashMap<String, String>()
        plan["MainActivity.kt"] = ""
        val fa = j.optJSONArray("files")
        if (fa != null) for (i in 0 until fa.length()) {
            val o = fa.optJSONObject(i) ?: continue
            val n = o.optString("name").substringAfterLast('/')
            if (Regex("[A-Za-z][A-Za-z0-9_]*\\.kt").matches(n) && plan.size < 14) plan[n] = o.optString("purpose")
        }
        if (plan["MainActivity.kt"].isNullOrEmpty()) plan["MainActivity.kt"] = "entry activity and main screen"
        val comps = j.optString("manifestComponents").lines().filter { l -> l.trim().let { it.startsWith("<receiver") || it.startsWith("<service") || it.startsWith("<provider") || it.startsWith("<intent-filter") || it.startsWith("<action") || it.startsWith("<category") || it.startsWith("</") || it.startsWith("<meta-data") } }.joinToString("\n") { "        " + it.trim() }
        putBase(perms, appName, true, deps, comps)
        say("الخطة: «$appName» بـ ${plan.size} ملفات.")
        val planText = "Package: $appId\nApp name: $appName\nSummary: $summary\nExtra permissions: ${perms.joinToString()}\nFiles:\n" +
            plan.entries.joinToString("\n") { "- ${it.key}: ${it.value}" }
        val done = LinkedHashMap<String, String>()
        var i = 0
        for (name in plan.keys) {
            i++
            say("أكتب $name ($i/${plan.size})…")
            val code = genFile(be, request, ref, planText, name, done)
            done[name] = code
            files["app/src/main/java/" + appId.replace('.', '/') + "/" + name] = code.toByteArray()
        }
    }

    private suspend fun genFile(be: DirectBackend, request: String, ref: String, planText: String, name: String, done: Map<String, String>): String {
        val sys = GEN_SYS.replace("@@PKG@@", appId).replace("@@NAME@@", name)
        val sb = StringBuilder()
        sb.append("USER REQUEST:\n").append(request).append("\n\n")
        if (ref.isNotBlank()) sb.append(ref).append("\n\n")
        sb.append("PLAN:\n").append(planText).append("\n\n")
        var budget = 48_000
        if (done.isNotEmpty()) {
            sb.append("ALREADY WRITTEN FILES (use their exact names and signatures):\n")
            for ((n, c) in done) { val t = c.take(12_000); if (budget - t.length < 0) break; budget -= t.length; sb.append("=== FILE: ").append(n).append(" ===\n").append(t).append("\n") }
            sb.append("\n")
        }
        sb.append("Now write the file ").append(name).append(" completely.")
        var feedback = ""
        var code = ""
        for (t in 0..1) {
            val rawOut = llm(be, sys, sb.toString() + feedback, 8000)
            code = extractFile(rawOut)
            val issues = validate(name, code)
            if (issues.isEmpty()) break
            say("$name: ${issues.first()} - أعيد كتابته…")
            feedback = "\n\nYour previous attempt had these problems, fix them all: " + issues.joinToString("; ")
        }
        val lines = code.lines().toMutableList()
        val idx = lines.indexOfFirst { it.trim().startsWith("package ") }
        if (idx in 0..8) lines[idx] = "package $appId" else lines.add(0, "package $appId")
        return lines.joinToString("\n").trim('\n') + "\n"
    }

    // ------------------------------------------------------------------ revise (errors or instruction)

    /** Bigger files are shown to the model as numbered excerpts (imports + the lines around each error) and fixed with search/replace edits. */
    private const val FULL_MAX = 7_000

    private fun excerptOf(path: String, errors: List<String>?, maxChars: Int): String {
        val lines = String(files[path]!!).lines()
        val nums = errors.orEmpty().flatMap { e -> Regex(Regex.escape(path) + ":(\\d+)").findAll(e).map { it.groupValues[1].toInt() }.toList() }.distinct().sorted()
        val keep = java.util.TreeSet<Int>()
        val lastImport = lines.take(300).indexOfLast { it.startsWith("import ") }
        for (i in 0..maxOf(lastImport, 5)) if (i < lines.size) keep.add(i)
        for (n in nums) for (i in (n - 31)..(n + 29)) if (i in lines.indices) keep.add(i)
        if (nums.isEmpty()) for (i in 0 until minOf(lines.size, 150)) keep.add(i)
        val sb = StringBuilder("=== EXCERPT: $path (${lines.size} lines in total; only the numbered lines are shown) ===\n")
        var prev = -2
        for (i in keep) {
            if (prev >= 0 && i != prev + 1) sb.append("   ...\n")
            sb.append(i + 1).append("| ").append(lines[i]).append('\n'); prev = i
        }
        return sb.toString().take(maxChars)
    }

    private fun buildFixPrompt(errors: List<String>?, instruction: String?, budgetIn: Int, errChars: Int): String {
        var budget = budgetIn
        val maxFile = if (errors != null) FULL_MAX else 50_000
        val chosen = LinkedHashSet<String>()
        if (errors != null) {
            val joined = errors.joinToString("\n")
            files.keys.filter { joined.contains(it) }.take(6).forEach { chosen.add(it) }
            if (chosen.isEmpty()) files.keys.filter { it.endsWith("build.gradle.kts") || it.endsWith("build.gradle") || it.endsWith("AndroidManifest.xml") || it.startsWith("settings.gradle") }.forEach { chosen.add(it) }
        }
        val sb = StringBuilder()
        if (errors != null) sb.append("BUILD ERRORS (fix all of them):\n").append(errors.take(25).joinToString("\n").take(errChars)).append("\n\n")
        else sb.append("INSTRUCTION (apply it; return only the files that change):\n").append(instruction).append("\n\n")
        budget -= sb.length
        sb.append("PROJECT FILES:\n")
        for (k in chosen) {
            val sz = files[k]!!.size
            if (errors != null && sz > maxFile) {
                val ex = excerptOf(k, errors, maxOf(2500, budget / 2)); sb.append(ex).append('\n'); budget -= ex.length
            } else {
                sb.append("=== FILE: ").append(k).append(" ===\n").append(String(files[k]!!)).append("\n"); budget -= sz
            }
        }
        for (k in files.keys.filter { isTextSrc(it) && it !in chosen }.sortedBy { files[it]!!.size }) {
            val sz = files[k]!!.size
            if (sz > maxFile || budget - sz < 0) continue
            if (errors != null && !(k.endsWith(".kt") || k.endsWith(".java") || k.endsWith("AndroidManifest.xml"))) continue
            budget -= sz; chosen.add(k)
            sb.append("=== FILE: ").append(k).append(" ===\n").append(String(files[k]!!)).append("\n")
        }
        val others = files.keys.filter { it !in chosen }
        if (others.isNotEmpty()) sb.append("\nOTHER FILES (not shown): ").append(others.take(40).joinToString(", ")).append("\n")
        return sb.toString()
    }

    private suspend fun revise(be: DirectBackend, errors: List<String>?, instruction: String?): Int {
        var budget = if (errors != null) 30_000 else 60_000
        var maxOut = 8000
        var errChars = 4000
        for (attempt in 0 until 3) {
            val prompt = buildFixPrompt(errors, instruction, budget, errChars)
            val out = try { llm(be, FIX_SYS, prompt, maxOut) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                val m = e.message.orEmpty()
                if (attempt < 2 && (m.contains("413") || m.contains("Request too large", true))) {
                    // The model's per-minute limit (TPM) is smaller than the request: send less and ask for a shorter answer.
                    val lim = Regex("Limit (\\d+)").find(m)?.groupValues?.get(1)?.toIntOrNull() ?: 8000
                    maxOut = minOf(maxOut, 3000)
                    budget = ((lim - maxOut - 800) * 3).coerceIn(3000, budget)
                    errChars = minOf(errChars, 1800)
                    say("الطلب أكبر من حدّ النموذج، أصغّره وأعيد المحاولة…")
                    continue
                }
                throw e
            }
            return applyModelOutput(out)
        }
        return 0
    }

    private val SECTION_RE = Regex("(?m)^=== (FILE|EDIT): (.+?) ===[ \\t]*$")
    private val EDIT_BLOCK_RE = Regex("<<<<<<< SEARCH\\r?\\n([\\s\\S]*?)\\r?\\n=======\\r?\\n([\\s\\S]*?)\\r?\\n?>>>>>>> REPLACE")

    /** Applies "=== FILE: p ===" (whole file) and "=== EDIT: p ===" (search/replace blocks) sections. Returns how many files changed. */
    private fun applyModelOutput(raw: String): Int {
        val ms = SECTION_RE.findAll(raw).toList()
        var n = 0
        for ((i, m) in ms.withIndex()) {
            val kind = m.groupValues[1]
            val path = normPath(m.groupValues[2]) ?: continue
            if (path == "app/debug.keystore" || path == "gradlew") continue
            if (mode != "gradle" && path == "settings.gradle.kts") continue
            val body = raw.substring(m.range.last + 1, if (i + 1 < ms.size) ms[i + 1].range.first else raw.length)
            if (kind == "FILE") {
                val c = stripFence(body.replace(Regex("(?m)^=== END ===\\s*$"), ""))
                if (c.isBlank()) continue
                files[path] = (c.trim('\n') + "\n").toByteArray(); n++
            } else {
                val cur = files[path]?.let { String(it) } ?: continue
                var text = cur
                var applied = 0
                for (b in EDIT_BLOCK_RE.findAll(body)) {
                    val search = b.groupValues[1]; val rep = b.groupValues[2]
                    var at = text.indexOf(search)
                    if (at < 0) {   // tolerate trailing-space differences
                        val norm = text.lines().joinToString("\n") { it.trimEnd() }
                        val ns = search.lines().joinToString("\n") { it.trimEnd() }
                        at = norm.indexOf(ns)
                        if (at >= 0 && norm.indexOf(ns, at + 1) < 0) { text = norm.substring(0, at) + rep + norm.substring(at + ns.length); applied++ }
                        continue
                    }
                    if (text.indexOf(search, at + 1) >= 0) continue   // ambiguous: not unique
                    text = text.substring(0, at) + rep + text.substring(at + search.length); applied++
                }
                if (applied > 0 && text != cur) { files[path] = text.toByteArray(); n++ }
            }
        }
        return n
    }

    private fun isTextSrc(p: String): Boolean {
        val e = p.substringAfterLast('.', "").lowercase()
        return e in setOf("kt", "java", "xml", "html", "htm", "js", "css", "json", "kts", "gradle", "properties", "md", "txt") &&
            !p.endsWith("debug.keystore") && !p.contains("/res/drawable") && !p.contains("/res/mipmap")
    }

    // ------------------------------------------------------------------ LLM helpers

    private suspend fun llm(be: DirectBackend, sys: String, user: String, max: Int): String {
        var tries = 0
        while (true) {
            try { return be.ask(sys, user, max) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                val m = e.message.orEmpty()
                val w = retryAfterMs(m) ?: 5000L
                if (isRateLimit(m) && tries < 4 && w <= 90_000L) {
                    tries++; say("حصة النموذج وصلت حدها، أنتظر ${w / 1000 + 1} ثانية…"); delay(w + 1000L)
                } else throw e
            }
        }
    }

    private fun JSONArray?.toList(): List<String> = if (this == null) emptyList() else (0 until length()).map { optString(it).trim() }.filter { it.isNotEmpty() }

    private fun refText(refs: List<BuildAtt>): String {
        val sb = StringBuilder(); var budget = 30_000
        for (a in refs) {
            val e = a.name.substringAfterLast('.', "").lowercase()
            if (e !in setOf("kt", "java", "xml", "json", "md", "txt", "py", "js", "ts", "html", "css", "csv", "gradle", "kts", "properties", "yaml", "yml")) continue
            val t = String(a.bytes).take(8000)
            if (budget - t.length < 0) break
            budget -= t.length
            sb.append("REFERENCE FILE ").append(a.name).append(":\n").append(t).append("\n\n")
        }
        return if (sb.isEmpty()) "" else "REFERENCE MATERIAL FROM THE USER'S FILES:\n$sb"
    }

    private fun stripFence(s: String): String {
        var t = s.trim('\n', '\r')
        if (t.trimStart().startsWith("```")) t = t.trimStart().substringAfter('\n', "")
        if (t.trimEnd().endsWith("```")) t = t.trimEnd().removeSuffix("```")
        return t.trim('\n', '\r')
    }

    private val FILE_RE = Regex("(?m)^=== FILE: (.+?) ===\\s*$")

    private fun parseFiles(raw: String): Map<String, String> {
        val ms = FILE_RE.findAll(raw).toList()
        val out = LinkedHashMap<String, String>()
        for ((i, m) in ms.withIndex()) {
            var body = raw.substring(m.range.last + 1, if (i + 1 < ms.size) ms[i + 1].range.first else raw.length)
            body = body.replace(Regex("(?m)^=== END ===\\s*$"), "")
            out[m.groupValues[1].trim()] = stripFence(body)
        }
        return out
    }

    private fun extractFile(raw: String): String = parseFiles(raw).values.firstOrNull() ?: stripFence(raw)

    private fun normPath(p: String): String? {
        val n = p.trim().replace('\\', '/').removePrefix("./")
        if (n.isBlank() || n.startsWith("/") || n.contains("..") || n.startsWith(".github")) return null
        return n
    }

    private fun ignored(p: String): Boolean {
        val n = p.replace('\\', '/')
        if (n.endsWith("/") || n.endsWith(".DS_Store") || n.startsWith("__MACOSX/") || n.contains("/__MACOSX/")) return true
        if (n == "local.properties" || n.startsWith(".git/") || n.contains("/.git/") || n.startsWith(".gradle/") || n.startsWith(".idea/") || n.startsWith(".github/")) return true
        if (Regex("^([^/]+/)?build/").containsMatchIn(n)) return true
        return n.endsWith(".apk") || n.endsWith(".aab")
    }

    // ------------------------------------------------------------------ local validation

    private fun validate(name: String, code: String): List<String> {
        val out = mutableListOf<String>()
        if (code.trim().length < 40) out += "the file is empty or too short"
        if (Regex("(?i)//\\s*TODO|TODO\\(|rest of (the )?(code|file)|your (code|logic) (goes )?here|implement (this|here)|same as (before|above)|(?m)^\\s*\\.\\.\\.\\s*$").containsMatchIn(code))
            out += "it contains a placeholder / TODO; write the real, complete code"
        if (!balanced(code)) out += "brackets or quotes are unbalanced (the file looks truncated); write the WHOLE file"
        if (name == "MainActivity.kt" && !code.contains("class MainActivity")) out += "MainActivity.kt must declare class MainActivity : ComponentActivity()"
        if (Regex("import androidx\\.compose\\.material\\.(?!icons)").containsMatchIn(code)) out += "uses Material2 imports; use androidx.compose.material3 only"
        return out
    }

    private fun balanced(s: String): Boolean {
        val st = ArrayList<Char>()
        var i = 0; val n = s.length
        var inStr = false; var triple = false
        while (i < n) {
            val c = s[i]
            if (inStr) {
                when {
                    c == '\\' && !triple -> i += 2
                    c == '$' && i + 1 < n && s[i + 1] == '{' -> { st.add(if (triple) 'T' else '$'); inStr = false; i += 2 }
                    triple && s.startsWith("\"\"\"", i) -> { inStr = false; i += 3 }
                    !triple && c == '"' -> { inStr = false; i++ }
                    else -> i++
                }
                continue
            }
            when {
                s.startsWith("//", i) -> { while (i < n && s[i] != '\n') i++ }
                s.startsWith("/*", i) -> { val e = s.indexOf("*/", i + 2); if (e < 0) return false; i = e + 2 }
                s.startsWith("\"\"\"", i) -> { inStr = true; triple = true; i += 3 }
                c == '"' -> { inStr = true; triple = false; i++ }
                c == '\'' -> { i++; if (i < n && s[i] == '\\') i++; i++; while (i < n && s[i] != '\'' && s[i] != '\n') i++; i++ }
                c == '{' -> { st.add('}'); i++ }
                c == '(' -> { st.add(')'); i++ }
                c == '[' -> { st.add(']'); i++ }
                c == '}' || c == ')' || c == ']' -> {
                    if (st.isEmpty()) return false
                    val top = st.removeAt(st.size - 1)
                    if (top == '$' || top == 'T') { if (c != '}') return false; triple = top == 'T'; inStr = true }
                    else if (top != c) return false
                    i++
                }
                else -> i++
            }
        }
        return st.isEmpty() && !inStr
    }

    // ------------------------------------------------------------------ build log -> short error list

    private fun errorsOf(log: String): List<String> {
        if (log.isBlank()) return emptyList()
        val lines = log.lines()
        val out = LinkedHashSet<String>()
        val pre = Regex("(file://)?/home/runner/work/[^/]+/[^/]+/")
        for (l in lines) {
            val t = l.trim()
            if (isNoise(t)) continue          // "##[warning]Node.js 20 is deprecated…" is not a build error
            val compilerError = t.startsWith("e: ") || t.contains(": error:") || t.startsWith("error:") || t.contains("AAPT: error") ||
                (t.contains("error: ") && t.contains(".xml"))
            val gradleError = t.contains("Execution failed for task") || t.contains("Could not resolve") || t.contains("Could not find ") ||
                t.contains("Could not determine the dependencies") || t.contains("Plugin [id:") || t.contains("A problem occurred") ||
                (t.startsWith("> Task ") && t.endsWith(" FAILED")) || t.startsWith("FAILURE:")
            val actionsError = t.startsWith("##[error]") && !t.contains("Process completed with exit code")
            if (compilerError || gradleError || actionsError) out.add(t.removePrefix("##[error]").replace(Regex("(file://)?/home/runner/work/\\S*?/(?=app/src/)"), "").replace(pre, "").take(300))
            if (out.size >= 25) break
        }
        val w = lines.indexOfFirst { it.contains("What went wrong") }
        if (w >= 0) out.add(lines.drop(w + 1).take(6).joinToString(" ").trim().replace(pre, "").take(400))
        return out.toList()
    }

    /** Runner annotations that look like errors but are not (they sit at the end of every job log and hid the real failure). */
    private fun isNoise(t: String) = t.contains("##[warning]") || t.contains("Node.js 20 is deprecated") || t.contains("Node.js 24")

    /** Last meaningful lines of a log (used when no compiler error could be recognised). */
    private fun tailOf(log: String, n: Int): List<String> =
        log.lines().map { it.trim() }.filter { it.isNotEmpty() && !isNoise(it) }.takeLast(n)

    // ------------------------------------------------------------------ GitHub

    private class Resp(val code: Int, val bytes: ByteArray, val loc: String?, val scopes: String?) {
        val text: String get() = String(bytes)
    }

    private suspend fun gh(method: String, path: String, body: JSONObject? = null, auth: Boolean = true, readMs: Int = 60_000): Resp = withContext(Dispatchers.IO) {
        val u = if (path.startsWith("http")) path else "https://api.github.com$path"
        val c = URL(u).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 15_000; c.readTimeout = readMs; c.instanceFollowRedirects = false
        c.setRequestProperty("User-Agent", "AIPhoneAgent")
        if (auth) {
            c.setRequestProperty("Authorization", "Bearer " + ghToken)
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        }
        if (body != null) {
            c.doOutput = true; c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        val code = c.responseCode
        val bytes = (if (code < 400) c.inputStream else c.errorStream)?.use { it.readBytes() } ?: ByteArray(0)
        Resp(code, bytes, c.getHeaderField("Location"), c.getHeaderField("X-OAuth-Scopes"))
    }

    private fun ghMsg(r: Resp): String {
        val m = runCatching { JSONObject(r.text).optString("message") }.getOrDefault("")
        val hint = if (m.contains("workflow", true)) " (التوكن ينقصه صلاحية workflow)" else ""
        return "GitHub ${r.code}: ${m.ifBlank { r.text.take(150) }}$hint"
    }

    // ------------------------------------------------------------------ AndroidForge method
    // Same flow as https://professional-x.github.io/AndroidForge/ : fork Professional-X/AndroidForge once, then per build:
    // create a Release (tag web-build-<ts>) -> upload the project zip as an asset -> workflow_dispatch build-android.yml
    // (zip_source=release-asset, release_tag=<tag>) -> poll the run -> download the AndroidForge-APKs / AndroidForge-logs artifacts.

    private const val FORGE_OWNER = "Professional-X"
    private const val FORGE_REPO = "AndroidForge"
    private const val FORGE_WF = "build-android.yml"
    private var releaseId = 0L
    private var releaseTag = ""

    private suspend fun ensureRepo(): String {
        val me = gh("GET", "/user")
        if (me.code == 401) error("توكن GitHub غير صالح أو منتهي.")
        if (me.code != 200) error(ghMsg(me))
        val sc = me.scopes
        if (!sc.isNullOrBlank()) {
            val set = sc.split(",").map { it.trim() }
            if ("repo" !in set) error("توكن GitHub ينقصه صلاحية repo.")
            if ("workflow" !in set) error("توكن GitHub ينقصه صلاحية workflow.")
        }
        val login = JSONObject(me.text).getString("login")
        val full = "$login/$FORGE_REPO"
        val r = gh("GET", "/repos/$full")
        when (r.code) {
            200 -> {}
            404 -> {
                say("أنسخ مستودع AndroidForge إلى حسابك (مرة وحدة فقط)…")
                val f = gh("POST", "/repos/$FORGE_OWNER/$FORGE_REPO/forks", JSONObject().put("default_branch_only", true))
                if (f.code !in 200..299) error("تعذّر عمل fork لـ AndroidForge: " + ghMsg(f))
            }
            else -> error(ghMsg(r))
        }
        // wait until the fork exists and GitHub has indexed its workflow
        val t0 = System.currentTimeMillis()
        var state = ""
        while (true) {
            val w = gh("GET", "/repos/$full/actions/workflows/$FORGE_WF")
            if (w.code == 200) { state = JSONObject(w.text).optString("state"); break }
            if (System.currentTimeMillis() - t0 > 120_000) error("نسخة AndroidForge ما جهزت بعد. جرّب بعد دقيقة، أو تأكد أن المستودع $full موجود وفيه الملف .github/workflows/$FORGE_WF.")
            delay(4000)
        }
        val repoInfo = gh("GET", "/repos/$full")
        branch = runCatching { JSONObject(repoInfo.text).optString("default_branch", "main") }.getOrDefault("main").ifBlank { "main" }
        // forks start with Actions switched off: enable them (needs admin on the fork, which the token has)
        runCatching { gh("PUT", "/repos/$full/actions/permissions", JSONObject().put("enabled", true).put("allowed_actions", "all")) }
        if (state != "active") runCatching { gh("PUT", "/repos/$full/actions/workflows/$FORGE_WF/enable", JSONObject()) }
        runCatching { gh("POST", "/repos/$full/merge-upstream", JSONObject().put("branch", branch)) }   // pick up upstream fixes, best effort
        return full
    }

    private suspend fun ghUpload(url: String, bytes: ByteArray): Resp = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15_000; c.readTimeout = 180_000; c.doOutput = true
        c.setRequestProperty("User-Agent", "AIPhoneAgent")
        c.setRequestProperty("Authorization", "Bearer " + ghToken)
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("Content-Type", "application/zip")
        c.setFixedLengthStreamingMode(bytes.size)
        c.outputStream.use { it.write(bytes) }
        val code = c.responseCode
        val out = (if (code < 400) c.inputStream else c.errorStream)?.use { it.readBytes() } ?: ByteArray(0)
        Resp(code, out, null, null)
    }

    private fun projectZip(): ByteArray {
        val bo = java.io.ByteArrayOutputStream()
        java.util.zip.ZipOutputStream(bo).use { z ->
            for ((n, b) in files) { z.putNextEntry(java.util.zip.ZipEntry(n)); z.write(b); z.closeEntry() }
        }
        return bo.toByteArray()
    }

    private suspend fun latestRunId(): Long {
        val r = gh("GET", "/repos/$repo/actions/runs?per_page=1")
        return if (r.code == 200) JSONObject(r.text).optJSONArray("workflow_runs")?.optJSONObject(0)?.optLong("id") ?: 0L else 0L
    }

    /** One AndroidForge build of the current project. Returns (run id, conclusion). */
    private suspend fun forgeBuild(): Pair<Long, String> {
        val zip = projectZip()
        val tag = "web-build-" + System.currentTimeMillis()
        say("أرفع المشروع (${files.size} ملف، ${zip.size / 1024} KB) كـ Release على GitHub…")
        val rel = gh("POST", "/repos/$repo/releases", JSONObject().put("tag_name", tag).put("name", tag).put("target_commitish", branch).put("prerelease", true).put("body", "AI Phone Agent build"))
        if (rel.code != 201) error(ghMsg(rel))
        releaseId = JSONObject(rel.text).getLong("id"); releaseTag = tag
        val up = ghUpload("https://uploads.github.com/repos/$repo/releases/$releaseId/assets?name=project.zip", zip)
        if (up.code !in 200..299) error("فشل رفع الملف: " + ghMsg(up))
        val before = latestRunId()
        say("أشغّل AndroidForge على GitHub…")
        val d = gh("POST", "/repos/$repo/actions/workflows/$FORGE_WF/dispatches", JSONObject().put("ref", branch).put("inputs",
            JSONObject().put("zip_source", "release-asset").put("release_tag", tag).put("build_variant", "debug").put("enable_ndk", "false")))
        if (d.code != 204) error("تعذّر تشغيل الـ workflow: " + ghMsg(d))
        val t0 = System.currentTimeMillis()
        var id = 0L
        while (id == 0L) {
            delay(4000)
            val r = gh("GET", "/repos/$repo/actions/workflows/$FORGE_WF/runs?event=workflow_dispatch&per_page=5")
            if (r.code == 200) {
                val a = JSONObject(r.text).optJSONArray("workflow_runs")
                if (a != null) for (i in 0 until a.length()) { val rid = a.getJSONObject(i).getLong("id"); if (rid > before && rid > id) id = rid }
            }
            if (id == 0L && System.currentTimeMillis() - t0 > 150_000) error("ما بدأ البناء على GitHub. افتح تبويب Actions بالمستودع $repo وتأكد أنه مفعّل.")
        }
        currentRun = id
        say("بدأ البناء (run $id). عادةً 5 إلى 15 دقيقة.")
        while (true) {
            val r = gh("GET", "/repos/$repo/actions/runs/$id")
            if (r.code == 200) {
                val j = JSONObject(r.text)
                if (j.optString("status") == "completed") return id to j.optString("conclusion")
                val s = (System.currentTimeMillis() - t0) / 1000
                tick("AndroidForge يبني… %d:%02d".format(s / 60, s % 60))
            }
            if (System.currentTimeMillis() - t0 > 45 * 60_000L) error("البناء طوّل أكثر من 45 دقيقة.")
            delay(8000)
        }
    }

    private suspend fun cleanupRelease() {
        if (releaseId == 0L) return
        runCatching { gh("DELETE", "/repos/$repo/releases/$releaseId") }
        runCatching { gh("DELETE", "/repos/$repo/git/refs/tags/$releaseTag") }
        releaseId = 0L
    }

    private suspend fun downloadArtifact(url: String): ByteArray? {
        var d = gh("GET", url, readMs = 180_000)
        if (d.code in 301..308 && d.loc != null) d = gh("GET", d.loc!!, auth = false, readMs = 180_000)
        return if (d.code == 200) d.bytes else null
    }

    /** (apk bytes or null, build log text). The APK comes from AndroidForge-APKs; the log from AndroidForge-logs (only fetched when there is no APK). */
    private suspend fun fetchResult(runId: Long): Pair<ByteArray?, String> {
        val r = gh("GET", "/repos/$repo/actions/runs/$runId/artifacts?per_page=30")
        if (r.code != 200) return null to ""
        val arr = JSONObject(r.text).optJSONArray("artifacts") ?: return null to ""
        var apkUrl: String? = null; var logUrl: String? = null
        for (i in 0 until arr.length()) {
            val a = arr.getJSONObject(i)
            if (a.optBoolean("expired")) continue
            val n = a.optString("name")
            if (n.startsWith("AndroidForge-APKs")) apkUrl = a.optString("archive_download_url")
            if (n.startsWith("AndroidForge-logs")) logUrl = a.optString("archive_download_url")
        }
        val apk = apkUrl?.let { downloadArtifact(it) }?.let { z ->
            val l = unzip(z).filter { it.name.endsWith(".apk", true) }
            (l.firstOrNull { it.name.contains("debug", true) } ?: l.firstOrNull())?.bytes
        }
        if (apk != null) return apk to ""
        val log = logUrl?.let { downloadArtifact(it) }?.let { z ->
            unzip(z).filter { f -> listOf(".log", ".txt", ".md").any { f.name.endsWith(it, true) } && f.bytes.size < 8_000_000 }
                .joinToString("\n") { String(it.bytes) }.takeLast(600_000)
        } ?: ""
        return null to log
    }

    /** Plain job logs of a run (used when the "result" artifact is missing). */
    private suspend fun fetchRunLogs(runId: Long): String {
        var d = gh("GET", "/repos/$repo/actions/runs/$runId/logs", readMs = 120_000)
        if (d.code in 301..308 && d.loc != null) d = gh("GET", d.loc!!, auth = false, readMs = 120_000)
        if (d.code != 200) return ""
        val ts = Regex("(?m)^\\d{4}-\\d\\d-\\d\\dT[\\d:.]+Z ?")
        return unzip(d.bytes).filter { it.name.endsWith(".txt") }.joinToString("\n") { String(it.bytes).replace(ts, "") }
    }

    private fun unzip(b: ByteArray): List<BuildAtt> {
        val out = ArrayList<BuildAtt>()
        ZipInputStream(ByteArrayInputStream(b)).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory) continue
                val n = e.name.replace('\\', '/')
                if (n.contains("..") || n.startsWith("__MACOSX/") || n.endsWith(".DS_Store")) continue
                out.add(BuildAtt(n, z.readBytes()))
            }
        }
        return out
    }

    // ------------------------------------------------------------------ persistence of the last project (for "edit last app")

    private fun projDir() = File(ctx.filesDir, "builder/last")

    private fun saveProject() {
        if (files.isEmpty()) return
        runCatching {
            val d = projDir(); d.deleteRecursively(); d.mkdirs()
            for ((p, b) in files) File(d, p).apply { parentFile?.mkdirs() }.writeBytes(b)
            prefs.edit().putString("mode", mode).putString("appId", appId).putString("appName", appName).apply()
            hasLast = true
        }
    }

    private fun loadProject() {
        runCatching {
            val d = projDir()
            if (!d.exists()) return
            files.clear()
            d.walkTopDown().filter { it.isFile }.forEach { files[it.relativeTo(d).path.replace('\\', '/')] = it.readBytes() }
            mode = prefs.getString("mode", "native").orEmpty(); appId = prefs.getString("appId", "").orEmpty(); appName = prefs.getString("appName", "").orEmpty()
            hasLast = files.isNotEmpty()
        }
    }

    // ------------------------------------------------------------------ templates and prompts

    private const val SETTINGS_GRADLE = """pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "GeneratedApp"
include(":app")
"""

    private const val ROOT_GRADLE = """plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
}
"""

    private const val GRADLE_PROPS = "org.gradle.jvmargs=-Xmx3g -XX:MaxMetaspaceSize=768m\nandroid.useAndroidX=true\nkotlin.code.style=official\n"

    private const val APP_GRADLE_NATIVE = """plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "@@APPID@@"
    compileSdk = 34
    defaultConfig {
        applicationId = "@@APPID@@"
        minSdk = 26
        targetSdk = 34
        versionCode = @@VC@@
        versionName = "1.0"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android"
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}
dependencies {
@@DEPS@@}
"""

    private const val APP_GRADLE_WEB = """plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "@@APPID@@"
    compileSdk = 34
    defaultConfig {
        applicationId = "@@APPID@@"
        minSdk = 26
        targetSdk = 34
        versionCode = @@VC@@
        versionName = "1.0"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android"
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
@@DEPS@@}
"""

    private const val NATIVE_DEPS = """    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
"""

    private const val WEB_DEPS = "    implementation(\"androidx.core:core-ktx:1.13.1\")\n"

    private const val MANIFEST = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
@@PERMS@@
    <application
        android:allowBackup="false"
        android:supportsRtl="true"
        android:usesCleartextTraffic="true"
        android:label="@string/app_name"
        android:theme="@style/Theme.GeneratedApp">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:windowSoftInputMode="adjustResize"
            android:configChanges="orientation|screenSize|keyboardHidden|smallestScreenSize|screenLayout|uiMode">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
@@COMPONENTS@@
    </application>
</manifest>
"""

    private const val THEMES = """<resources>
    <style name="Theme.GeneratedApp" parent="android:Theme.Material.NoActionBar">
        <item name="android:windowBackground">#FF131315</item>
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:navigationBarColor">@android:color/transparent</item>
    </style>
</resources>
"""

    private const val WEB_ACTIVITY = """package @@PKG@@

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        setContentView(web)
        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl("file:///android_asset/www/index.html")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
"""

    private const val PLAN_SYS = """You are a principal Android engineer planning a COMPLETE, production-quality app that must compile on the first try. Output ONE JSON object only, no markdown, no commentary:
{"appName":"short display name in the user's language","summary":"3-5 sentences: screens, features, data flow","features":["every concrete feature the user asked for, plus the obvious ones a polished app of this kind needs"],"permissions":["android.permission.X"],"deps":[],"manifestComponents":"optional raw XML lines for <receiver>/<service> entries that need the manifest (android:name=\".ClassName\"), empty if none","files":[{"name":"MainActivity.kt","purpose":"..."}]}
Rules:
- Up to 14 files. Every name is a plain file name ending in .kt (no folders). MainActivity.kt is required and contains class MainActivity : ComponentActivity().
- Split by responsibility for big apps: Models.kt, Storage.kt (SharedPreferences), Api.kt (HttpURLConnection + org.json), one file per big screen, Components.kt (shared composables), Theme.kt, and receivers/services as their own files when needed (their class names must match manifestComponents).
- Every feature in "features" must be assigned to a file and really implemented: never plan a feature you will not build. Include settings, empty/error states, offline fallback (cache last result in SharedPreferences) and a polished dark Material3 design.
- UI is Jetpack Compose with Material3 only (single activity, no XML layouts, no Navigation library: switch screens with state).
- Notifications / alarms: use NotificationManager with a channel, AlarmManager.setAndAllowWhileIdle and a BroadcastReceiver declared in manifestComponents; ask POST_NOTIFICATIONS at runtime on API 33+. Location: LocationManager with ACCESS_COARSE_LOCATION asked at runtime, with a manual city entry as fallback.
- deps stays empty unless truly needed; each entry is "group:artifact:version" with a real stable version. Never plan Room, Hilt, Retrofit, kotlinx.serialization or anything that needs a compiler plugin (kapt/ksp): use HttpURLConnection + org.json for network and SharedPreferences for storage. Free keyless APIs are preferred (e.g. Aladhan for prayer times, Open-Meteo for weather).
- permissions: only what the features need (INTERNET is always added)."""

    private const val GEN_SYS = """You write ONE complete Kotlin file of an Android app: Jetpack Compose Material3, Kotlin 2.0, minSdk 26, compileSdk 34, single module.
Output format, exactly: first line "=== FILE: @@NAME@@ ===" then the full file content. No markdown fences, no commentary before or after.
Hard rules:
- The first code line is: package @@PKG@@
- Complete, working code. Never write TODO, placeholders, "rest of code", "..." or stubs. Every function, class and constant you use must exist in this file or in the other planned files, with the exact names and signatures shown in the plan / already written files.
- Write explicit imports for everything used. Use androidx.compose.material3 (never androidx.compose.material). Icons come from androidx.compose.material.icons (Icons.Default / Icons.Filled / Icons.Rounded; material-icons-extended is available).
- Mark experimental Material3 APIs with @OptIn(ExperimentalMaterial3Api::class).
- Available libraries: Compose BOM 2024.09 (ui, foundation, material3, animation), activity-compose 1.9.2, core-ktx, lifecycle-runtime-compose and lifecycle-viewmodel-compose 2.8.6, kotlinx-coroutines-android, plus the extra dependencies named in the plan. Nothing else exists.
- No R.drawable, R.mipmap or R.layout references. R.string.app_name exists.
- Network: java.net.HttpURLConnection on Dispatchers.IO with org.json. Storage: SharedPreferences. Never block the main thread.
- If the user writes Arabic, every UI text is Arabic and the root composable wraps its content in CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl).
- UI quality: dark theme by default (darkColorScheme), generous spacing, large touch targets, loading / empty / error states, Modifier.systemBarsPadding() at the root.
- MainActivity: class MainActivity : ComponentActivity() that calls enableEdgeToEdge() and then setContent { ... }.
- Write the COMPLETE file even when it is long (hundreds of lines is fine). BroadcastReceiver / Service classes extend the framework classes and use exactly the names declared in the plan."""

    private const val FIX_SYS = """You fix and update files of an Android Gradle project (Kotlin, Compose Material3, Compose BOM 2024.09, activity-compose 1.9.2, core-ktx, lifecycle 2.8.6, coroutines 1.8.1).
You receive build errors (or an instruction) and the current content of the relevant files.
Return ONLY what must change, in one of these two formats (no markdown fences, no commentary):
1) For a file shown in full: a line "=== FILE: path ===" (path as shown) followed by the COMPLETE new content of that file.
2) For a file shown as "=== EXCERPT: path ===" (numbered lines, only part of the file): never return the whole file. Return a line "=== EDIT: path ===" followed by one or more blocks:
<<<<<<< SEARCH
existing lines copied exactly (WITHOUT the line numbers), enough to be unique in the file
=======
the replacement lines
>>>>>>> REPLACE
To add an import, SEARCH one existing import line and REPLACE it with that same line plus the new import line. Keep SEARCH blocks short.
- Fix the root cause. Do not delete features just to silence an error. Keep package names and file paths.
- Use only APIs from the libraries listed above plus what the project already declares. If an error is an unresolved reference to something defined in another file, make the definition and the usage match.
- Keep code complete: no TODO, no placeholders."""
}
