package com.aiphoneagent

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Speech in and out.
 * - Listening: Android SpeechRecognizer (Arabic dialect set in Settings).
 * - Speaking: a neural voice through an OpenAI-compatible /audio/speech endpoint (default: Groq Orpheus Arabic, same API key),
 *   cached on disk; falls back to the phone's own TextToSpeech if the key/network/quota is missing.
 */
object Voice {
    var listening by mutableStateOf(false)
    var speaking by mutableStateOf(false)
    var partial by mutableStateOf("")
    var level by mutableFloatStateOf(0f)
    var handsFree by mutableStateOf(false)
    var failStreak = 0
    /** Subtitle feed for the voice screen: the sentence being spoken, how long it lasts, and a tick bumped when its audio starts. */
    var subText by mutableStateOf("")
    var subMs by mutableLongStateOf(0L)
    var subTick by mutableIntStateOf(0)
    fun markStart(text: String, ms: Long) { subText = text; subMs = ms.coerceAtLeast(600L); subTick++ }
    /** Why the natural voice was not used the last time (empty = it worked). Shown in Settings. */
    var ttsStatus by mutableStateOf("")

    private lateinit var appCtx: Context
    private lateinit var sp: SharedPreferences
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private class Item(val text: String, val done: () -> Unit)
    private val queue = Channel<Item>(Channel.UNLIMITED)
    private var pending = 0
    private var current: Job? = null
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    var voiceName: String
        get() = sp.getString("voice", "noura").orEmpty()
        set(v) { sp.edit().putString("voice", v.trim()).apply() }
    /** True once the user went through the voice picker (shown the first time the mic is pressed). */
    var voiceChosen: Boolean
        get() = sp.getBoolean("voicechosen", false)
        set(x) { sp.edit().putBoolean("voicechosen", x).apply() }
    var always: Boolean
        get() = sp.getBoolean("always", false)
        set(v) { sp.edit().putBoolean("always", v).apply() }
    var ttsUrl: String
        get() = sp.getString("ttsurl", "https://api.groq.com/openai/v1/audio/speech").orEmpty()
        set(v) { sp.edit().putString("ttsurl", v.trim()).apply() }
    var ttsModel: String
        get() = sp.getString("ttsmodel", "canopylabs/orpheus-arabic-saudi").orEmpty()
        set(v) { sp.edit().putString("ttsmodel", v.trim()).apply() }
    var sttLang: String
        get() = sp.getString("stt", "ar-SY").orEmpty()
        set(v) { sp.edit().putString("stt", v.trim()).apply() }
    /** Speech-to-text model (Groq Whisper). Understands about 99 languages and detects which one is spoken. */
    var sttModel: String
        get() = sp.getString("sttmodel", "whisper-large-v3").orEmpty()
        set(v) { sp.edit().putString("sttmodel", v.trim()).apply() }
    fun applyHandsFree(v: Boolean) { handsFree = v; sp.edit().putBoolean("hands", v).apply() }

    fun init(c: Context) {
        if (::sp.isInitialized) return
        appCtx = c.applicationContext
        sp = appCtx.getSharedPreferences("voice", Context.MODE_PRIVATE)
        handsFree = sp.getBoolean("hands", false)
        scope.launch {
            for (item in queue) {
                speaking = true
                val j = launch { runCatching { play(item.text) } }
                current = j
                j.join()
                pending = (pending - 1).coerceAtLeast(0)
                if (pending == 0) speaking = false
                if (!j.isCancelled) item.done()
            }
        }
    }

    // ---------- speaking ----------

    /** One in-flight download per sentence, shared by the prefetch started in speak() and by play(), so audio is ready when its turn comes. */
    private val inflight = java.util.concurrent.ConcurrentHashMap<String, Deferred<File?>>()
    private fun fetchShared(text: String): Deferred<File?> = inflight.getOrPut(text) {
        scope.async(Dispatchers.IO) { try { fetchWav(text) } finally { inflight.remove(text) } }
    }

    private fun clean(t: String): String = t
        .replace(Regex("[✓✗✔✘⋮▲▼•*_`#>]"), " ")
        .replace(Regex("[\\p{So}\\p{Cs}]"), " ")
        .replace(Regex("\\s+"), " ").trim()

    private fun chunks(t: String): List<String> {
        if (t.isEmpty()) return emptyList()
        val out = mutableListOf<String>(); val sb = StringBuilder()
        for (part in t.split(Regex("(?<=[.!?؟،,\\n])\\s*"))) {
            if (sb.isNotEmpty() && sb.length + part.length > 170) { out += sb.toString().trim(); sb.clear() }
            sb.append(part).append(' ')
            while (sb.length > 190) { out += sb.substring(0, 180).trim(); sb.delete(0, 180) }
        }
        if (sb.isNotBlank()) out += sb.toString().trim()
        return out.filter { it.isNotBlank() }
    }

    /** Queue text to be spoken; [onDone] runs after the last piece finishes (not if stopped). */
    fun speak(text: String, onDone: () -> Unit = {}) {
        if (!::sp.isInitialized) { onDone(); return }
        val parts = chunks(clean(text))
        if (parts.isEmpty()) { onDone(); return }
        if (!voiceName.startsWith("sys:")) parts.take(4).filter { localeFor(it) == null }.forEach { fetchShared(it) }
        parts.forEachIndexed { i, p ->
            pending++
            queue.trySend(Item(p, if (i == parts.lastIndex) onDone else ({})))
        }
    }

    /** Downloads the audio of [text] now, so a later speak() starts instantly and without gaps between sentences (used before recording a voice note). */
    suspend fun prefetch(text: String) {
        if (!::sp.isInitialized || voiceName.startsWith("sys:")) return
        for (p in chunks(clean(text))) fetchWav(p)
    }

    private fun ensureTts() {
        if (tts == null) tts = TextToSpeech(appCtx) { s ->
            ttsReady = s == TextToSpeech.SUCCESS
            if (ttsReady) tts?.setLanguage(Locale("ar"))
        }
    }

    /** Arabic voices installed on the phone as (id, label). Empty until the engine is ready: call again after a moment. */
    fun systemVoices(): List<Pair<String, String>> {
        if (!::sp.isInitialized) return emptyList()
        ensureTts()
        if (!ttsReady) return emptyList()
        return runCatching {
            tts!!.voices.filter { it.locale.language == "ar" }.sortedBy { it.name }.take(8)
                .mapIndexed { i, vc -> vc.name to "صوت الهاتف ${i + 1}" + vc.locale.displayCountry.let { c -> if (c.isBlank()) "" else " ($c)" } }
        }.getOrDefault(emptyList())
    }

    /** Speak a short sample with [id] right now (the current voice follows the last previewed one until the picker is confirmed). */
    fun preview(id: String) {
        stopSpeaking()
        voiceName = id
        speak("أهلاً، أنا جاهز. شو بدك أعمل؟")
    }

    fun stopSpeaking() {
        while (queue.tryReceive().isSuccess) pending = (pending - 1).coerceAtLeast(0)
        current?.cancel()
        runCatching { tts?.stop() }
        if (pending == 0) speaking = false
    }

    private val WHISPER_LANGS = mapOf(
        "english" to "en", "turkish" to "tr", "french" to "fr", "german" to "de", "spanish" to "es", "italian" to "it", "portuguese" to "pt",
        "dutch" to "nl", "russian" to "ru", "ukrainian" to "uk", "polish" to "pl", "persian" to "fa", "urdu" to "ur", "hindi" to "hi",
        "chinese" to "zh", "japanese" to "ja", "korean" to "ko", "indonesian" to "id", "swedish" to "sv", "greek" to "el", "hebrew" to "iw",
        "romanian" to "ro", "czech" to "cs", "hungarian" to "hu", "bulgarian" to "bg", "vietnamese" to "vi", "thai" to "th"
    )

    /**
     * null = the text is Arabic (neural Arabic voice). Anything else gets the phone's own voice in the right language, because the Arabic
     * model reads English/Turkish/... badly. For Latin text the language the user just spoke (detected by Whisper) decides.
     */
    private fun localeFor(text: String): Locale? {
        var ar = 0; var lat = 0; var cyr = 0; var han = 0; var kana = 0; var hang = 0; var dev = 0
        for (ch in text) when (Character.UnicodeScript.of(ch.code)) {
            Character.UnicodeScript.ARABIC -> ar++
            Character.UnicodeScript.LATIN -> lat++
            Character.UnicodeScript.CYRILLIC -> cyr++
            Character.UnicodeScript.HAN -> han++
            Character.UnicodeScript.HIRAGANA, Character.UnicodeScript.KATAKANA -> kana++
            Character.UnicodeScript.HANGUL -> hang++
            Character.UnicodeScript.DEVANAGARI -> dev++
            else -> {}
        }
        val others = lat + cyr + han + kana + hang + dev
        if (others == 0 || ar >= others) return null
        val said = WHISPER_LANGS[Ears.lastLang]
        return when {
            kana > 0 -> Locale.JAPANESE
            hang > 0 -> Locale.KOREAN
            han > 0 -> Locale.CHINESE
            dev > 0 -> Locale("hi")
            cyr >= lat -> Locale(if (said == "uk") "uk" else "ru")
            Regex("[ğşıİĞŞ]").containsMatchIn(text) -> Locale("tr")
            said != null && said != "ar" -> Locale(said)
            else -> Locale.ENGLISH
        }
    }

    private suspend fun play(text: String) {
        val loc = localeFor(text)
        if (loc != null) { speakFallback(text, loc); return }
        val f = if (voiceName.startsWith("sys:")) null else fetchShared(text).await()
        if (f == null) { speakFallback(text); return }
        // Never stay silent: PCM player first, then MediaPlayer, then the phone's own voice.
        if (playPcm(f, text) || playFile(f, text)) return
        runCatching { f.delete() }
        speakFallback(text)
    }

    private fun le16(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun le32(b: ByteArray, o: Int): Long = (le16(b, o).toLong()) or (le16(b, o + 2).toLong() shl 16)

    /** Plays a 16-bit PCM WAV directly. Handles streaming-style headers (unknown data length) that MediaPlayer chokes on. */
    private suspend fun playPcm(f: File, text: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val b = f.readBytes()
            if (b.size < 44 || String(b, 0, 4, Charsets.ISO_8859_1) != "RIFF") return@withContext false
            var pos = 12; var ch = 1; var sr = 24000; var bits = 16; var dStart = -1; var dLen = 0
            while (pos + 8 <= b.size) {
                val id = String(b, pos, 4, Charsets.ISO_8859_1)
                val sz = le32(b, pos + 4)
                if (id == "fmt ") { ch = le16(b, pos + 10); sr = le32(b, pos + 12).toInt(); bits = le16(b, pos + 22) }
                else if (id == "data") {
                    dStart = pos + 8
                    dLen = if (sz <= 0L || sz > (b.size - dStart).toLong()) b.size - dStart else sz.toInt()
                    break
                }
                if (sz > b.size.toLong()) break
                pos += 8 + sz.toInt() + (sz.toInt() and 1)
            }
            if (dStart < 0 || bits != 16 || ch !in 1..2 || sr < 8000 || dLen <= 0) return@withContext false
            val cfg = if (ch == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
            val minBuf = AudioTrack.getMinBufferSize(sr, cfg, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(cfg).build())
                .setBufferSizeInBytes(maxOf(minBuf, 16384)).setTransferMode(AudioTrack.MODE_STREAM).build()
            try {
                markStart(text, dLen * 1000L / (sr.toLong() * 2L * ch))
                track.play()
                var off = dStart; val end = dStart + dLen
                while (off < end) {
                    ensureActive()
                    val n = track.write(b, off, minOf(8192, end - off))
                    if (n <= 0) break
                    off += n
                }
                val frames = dLen / (2 * ch)
                var waited = 0L; val maxWait = frames * 1000L / sr + 2000L
                while (track.playbackHeadPosition < frames && waited < maxWait) { delay(50); waited += 50 }
            } finally {
                runCatching { track.pause(); track.flush() }
                runCatching { track.stop() }
                track.release()
            }
            true
        } catch (e: CancellationException) { throw e
        } catch (e: Exception) { ttsStatus = "فشل تشغيل الصوت: " + (e.message ?: e.javaClass.simpleName).take(80); false }
    }

    private suspend fun fetchWav(text: String): File? = withContext(Dispatchers.IO) {
        val keys = AgentController.apiKeyList
        val url = ttsUrl
        if (voiceName.startsWith("sys:")) return@withContext null   // phone voice chosen: no network
        if (keys.isEmpty() || !url.startsWith("https://")) { ttsStatus = "لا يوجد مفتاح أو العنوان غير صحيح"; return@withContext null }
        val dir = File(appCtx.cacheDir, "tts"); dir.mkdirs()
        val f = File(dir, Integer.toHexString((ttsModel + voiceName + text).hashCode()) + ".wav")
        if (f.exists() && f.length() > 2000) return@withContext f
        // Try every key: the voice quota is per account too, and one limited key must not drop us to the robotic phone voice.
        for (key in keys) {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 30000; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer $key")
                c.outputStream.use {
                    it.write(JSONObject().put("model", ttsModel).put("voice", voiceName).put("input", text)
                        .put("response_format", "wav").toString().toByteArray())
                }
                val code = c.responseCode
                if (code !in 200..299) {
                    val err = runCatching { c.errorStream?.bufferedReader()?.readText().orEmpty() }.getOrDefault("")
                    c.disconnect()
                    ttsStatus = when {
                        err.contains("terms", true) -> "لازم توافق على شروط نموذج الصوت في Groq Playground (حساب المفتاح ${key.takeLast(4)})"
                        code == 429 -> "حد الصوت المجاني خلص لهذا المفتاح، جرّبت التالي"
                        code == 401 || code == 403 -> "مفتاح غير صالح (${key.takeLast(4)})"
                        else -> "فشل الصوت: HTTP $code " + err.take(120)
                    }
                    continue
                }
                val bytes = c.inputStream.use { it.readBytes() }
                c.disconnect()
                if (bytes.size >= 2000) { f.writeBytes(bytes); ttsStatus = ""; return@withContext f }
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { ttsStatus = "فشل الاتصال بخدمة الصوت: " + (e.message ?: "").take(80) }
        }
        null
    }

    private suspend fun playFile(f: File, text: String): Boolean {
        val mp = MediaPlayer()
        var ok = false
        try {
            suspendCancellableCoroutine<Unit> { cont ->
                try {
                    mp.setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    mp.setDataSource(f.absolutePath)
                    mp.setOnCompletionListener { ok = true; if (cont.isActive) cont.resume(Unit) }
                    mp.setOnErrorListener { _, _, _ -> if (cont.isActive) cont.resume(Unit); true }
                    mp.prepare(); markStart(text, mp.duration.toLong()); mp.start()
                } catch (e: Exception) { if (cont.isActive) cont.resume(Unit) }
                cont.invokeOnCancellation { runCatching { mp.stop() } }
            }
        } finally { runCatching { mp.release() } }
        if (!ok) ttsStatus = "تعذّر تشغيل ملف الصوت على هذا الهاتف"
        return ok
    }

    private suspend fun speakFallback(t: String, loc: Locale? = null) {
        ensureTts()
        var w = 0
        while (!ttsReady && w < 25) { delay(150); w++ }
        if (!ttsReady) return
        markStart(t, t.length * 65L)
        if (loc != null) {
            runCatching { tts?.setLanguage(loc) }
        } else if (voiceName.startsWith("sys:")) {
            val want = voiceName.removePrefix("sys:")
            runCatching { tts?.voices?.firstOrNull { it.name == want }?.let { tts?.voice = it } }
        } else {
            runCatching { tts?.setLanguage(Locale("ar")) }
        }
        suspendCancellableCoroutine<Unit> { cont ->
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(u: String?) {}
                override fun onDone(u: String?) { if (cont.isActive) cont.resume(Unit) }
                @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
                override fun onError(u: String?) { if (cont.isActive) cont.resume(Unit) }
            })
            tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u${System.nanoTime()}")
            cont.invokeOnCancellation { runCatching { tts?.stop() } }
        }
    }

    // ---------- listening ----------

    private fun errText(e: Int) = when (e) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "ما سمعت شي، جرّب مرة ثانية."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "لازم تسمح بالميكروفون."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "التعرف على الصوت يحتاج إنترنت."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "المايك مشغول، جرّب بعد لحظة."
        else -> "ما قدرت أسمعك (خطأ $e)."
    }

    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var tailTimer: Runnable? = null
    private var heard = ""
    private var sess = 0

    /**
     * [continueMs] > 0 (voice screen): after the engine decides you finished, keep listening that long; if you go on talking the
     * new words are appended to the same sentence, and only after that silence is the whole sentence sent.
     */
    fun listen(ctx: Context, onFinal: (String) -> Unit, onFail: (String) -> Unit, continueMs: Long = 0L) {
        if (listening) return
        val whisper = Ears.available(ctx) && System.currentTimeMillis() > whisperDownUntil
        if (!whisper && !SpeechRecognizer.isRecognitionAvailable(ctx)) { onFail("خدمة التعرف على الصوت غير متوفرة على هذا الهاتف."); return }
        stopSpeaking()
        heard = ""; partial = ""; level = 0f; listening = true
        if (whisper) whisperSession(onFinal, onFail, continueMs) else session(ctx, onFinal, onFail, continueMs)
    }

    private var listenJob: Job? = null
    /** After Whisper failed (no network / quota) the old Android recognizer takes over for a short while. */
    private var whisperDownUntil = 0L

    /** Records one sentence (voice-activity detection) and sends it to Whisper, which understands any language. */
    private fun whisperSession(onFinal: (String) -> Unit, onFail: (String) -> Unit, continueMs: Long) {
        val my = ++sess
        listenJob?.cancel()
        listenJob = scope.launch {
            try {
                val pcm = Ears.record(
                    maxWaitMs = if (continueMs > 0L) 25_000 else 9_000,
                    endSilenceMs = if (continueMs > 0L) 1_400 else 1_000,
                    onLevel = { rms -> val v = (rms / 3000f * 12f).coerceIn(0f, 12f); handler.post { if (my == sess) level = v } },
                    onSpeech = {})
                if (my != sess) return@launch
                if (pcm == null) { endListening(); onFail(errText(SpeechRecognizer.ERROR_NO_MATCH)); return@launch }
                level = 0f
                val h = try { Ears.transcribe(pcm) } catch (e: CancellationException) { throw e } catch (e: Exception) {
                    if (my != sess) return@launch
                    whisperDownUntil = System.currentTimeMillis() + 90_000L
                    endListening(); onFail("ما قدرت أفهم الصوت (" + Ears.lastError.ifBlank { "تحقق من الإنترنت" } + "). جرّب مرة ثانية."); return@launch
                }
                if (my != sess) return@launch
                endListening()
                if (h.text.isBlank()) onFail(errText(SpeechRecognizer.ERROR_NO_MATCH)) else onFinal(h.text)
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { if (my == sess) { endListening(); onFail("ما قدرت أسمعك: " + (e.message ?: "").take(80)) } }
        }
    }

    private fun session(ctx: Context, onFinal: (String) -> Unit, onFail: (String) -> Unit, continueMs: Long) {
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        val my = ++sess
        fun deliver() {
            val t = heard.trim(); endListening()
            if (t.isBlank()) onFail(errText(SpeechRecognizer.ERROR_NO_MATCH)) else onFinal(t)
        }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {
                if (my != sess) return
                tailTimer?.let { handler.removeCallbacks(it) }; tailTimer = null
            }
            override fun onRmsChanged(v: Float) { if (my == sess) level = v }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {
                if (my != sess) return
                val p = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                partial = (heard + " " + p).trim()
            }
            override fun onError(e: Int) {
                if (my != sess) return
                if (heard.isNotBlank()) deliver() else { endListening(); onFail(errText(e)) }
            }
            override fun onResults(b: Bundle?) {
                if (my != sess) return
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                if (t.isNotBlank()) heard = (heard + " " + t).trim()
                if (heard.isBlank()) { endListening(); onFail(errText(SpeechRecognizer.ERROR_NO_MATCH)); return }
                if (continueMs > 0L) {
                    partial = heard
                    runCatching { r.destroy() }; rec = null
                    tailTimer?.let { handler.removeCallbacks(it) }
                    val tt = Runnable { if (listening) deliver() }
                    tailTimer = tt
                    handler.postDelayed(tt, continueMs)
                    session(ctx, onFinal, onFail, continueMs)
                } else deliver()
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, sttLang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        if (continueMs > 0L) intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1300L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1100L)
        r.startListening(intent)
    }

    fun stopListening() { listenJob?.cancel(); listenJob = null; runCatching { rec?.cancel() }; endListening() }

    private fun endListening() {
        sess++
        tailTimer?.let { handler.removeCallbacks(it) }; tailTimer = null
        heard = ""; listening = false; partial = ""
        runCatching { rec?.destroy() }
        rec = null
    }
}
